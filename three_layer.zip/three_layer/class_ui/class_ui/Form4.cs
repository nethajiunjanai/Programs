﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using businesslogic;

namespace class_ui
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

       

        private void Form4_Load(object sender, EventArgs e)
        {
            buslog b = new buslog();
            textBox1.Text = b.createnewbranch();
            textBox1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string branchno;
            string street;
            string city;
            string postcode;

            branchno = textBox1.Text;
            street=textBox2.Text;
            city=textBox3.Text;
            postcode = textBox4.Text;

            buslog b = new buslog();
           int tot= b.insertdata(branchno,street,city,postcode);
           if (tot > 0)
           {
               MessageBox.Show("inserted");
           }
            
        }
    }
}
