﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myfirstLibrary1
{
    public class Class1
    {
        public string displaywelcome()
        {
            return "welcome user";
        }
    }
}
