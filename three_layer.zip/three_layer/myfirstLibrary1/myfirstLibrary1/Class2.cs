﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace myfirstLibrary1
{
   public class dbclass
    {
       public DataSet showrecord()
       {
       string constring = "server=PC251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
       String qry = "select * from Dream_Home.propertyforrent";
       SqlConnection con = new SqlConnection(constring);
       con.Open();
       SqlCommand cmd = new SqlCommand(qry, con);
       SqlDataAdapter da = new SqlDataAdapter(cmd);
       DataSet ds = new DataSet();
       da.Fill(ds);
       return ds;
       }
    }
}
