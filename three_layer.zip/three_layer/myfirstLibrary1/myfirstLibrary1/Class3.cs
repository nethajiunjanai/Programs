﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace myfirstLibrary1
{
    public class lib
    {
    //    string branchno=null;
    //    string street=null;
    //    string city=null;
    //    string postcode=null;
       // string newno;
        public string getmaxbranchno()
        {
            string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
            string qry = "select max(branchno) from Dream_Home.branch";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);

            object o = cmd.ExecuteScalar();
            string s = o.ToString();
           // s = newno;
            return s;
        }

        public int insertbranch(string branchno, string street, string city,string postcode)
        {
           
            string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
            string qry="insert into Dream_Home.branch values (@branchno,@street,@city,@postcode)";

            SqlConnection con = new SqlConnection(constring);       
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
           /// cmd.CommandType = CommandType.Text;
           // cmd.CommandText = qry;
            SqlParameter p1 = cmd.Parameters.Add("@branchno", SqlDbType.VarChar, 20);
            p1.Value = branchno;

            SqlParameter p2 = cmd.Parameters.Add("@street", SqlDbType.VarChar, 20);
            p2.Value = street;

            SqlParameter p3 = cmd.Parameters.Add("@city", SqlDbType.VarChar, 20);
            p3.Value = city;

            SqlParameter p4 = cmd.Parameters.Add("@postcode", SqlDbType.VarChar, 20);
            p4.Value = postcode;
           //dml manipulation and it returns integer 
           
           return cmd.ExecuteNonQuery();
          
            
           

        }
    }
}


