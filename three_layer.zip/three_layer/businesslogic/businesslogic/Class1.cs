﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using myfirstLibrary1;
using System.Data;

namespace businesslogic
{
    public class buslog
    {
        public string createnewbranch()
        {
            lib l = new lib();
            string s;
            string str=null;
            s = l.getmaxbranchno();
            string s1 = s.Substring(1, 3);
            int i = int.Parse(s1);
            i++;
            if (i < 10)
            {
                 str = string.Concat("B00", i.ToString());
               
            }
            else if (i < 100)
            {
                str = string.Concat("B0", i.ToString());
               
            }
            return str;
        }
      public int insertdata(string bno,string st,string ct,string pc)
       {
          
         lib b=new lib();      
         int i=b.insertbranch(bno,st,ct,pc);
          int y=b.i
         return i;
       }
   }
}


