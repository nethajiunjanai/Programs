﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
//    //properties

//{
//    class marker
//    {
//        private string color;
//        public string COLOR
//        {
//            get
//            {
//                return color;
//            }
//            set
//            {
//                color = value;
//            }
//        }
//    }
//    class callmarker
//    {
//        public static void Main()
//        {
//            marker m = new marker();
//            m.COLOR="blue";
//            Console.WriteLine(m.COLOR);
            
//        }
//    }
//}
