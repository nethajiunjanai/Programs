﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
//    //interface
//{
//    interface i1
//    {
//        void method1();
//    }

//    class inter:i1
//    {
//        public void method1()
//        {
//            Console.WriteLine("interface concept");
//        }
//        public static void Main()
//        {
//            inter a = new inter();
//            a.method1();
//        }
//    }
//}
