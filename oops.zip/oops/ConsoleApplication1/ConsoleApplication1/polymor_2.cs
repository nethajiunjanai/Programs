﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
//{
//    //polymorphism2
//    //CALLER TO CALLED
//    class area
//    {
//        //void manipulate(int x, int y)
//        //    //called
//        //{
//        //    int res = x + y;
//        //    Console.WriteLine("the output is:" +res);
//        //}
//        //void manipulate(int a, int b,int c)
//        //    //called
//        //{
//        //    int resl = a * b*c;
//        //    Console.WriteLine("the output is:" +resl);
//        //}
//        //public static void Main()
//        //    //caller
//        //{
//        //    area a = new area();
//        //    a.manipulate(5, 3);
//        //    a.manipulate(3, 3);

//        //}
//        //CALLED TO CALLER
//        int manipulate(int x, int y)
//        //called
//        {
//            return x + y;
//           // Console.WriteLine("the output is:" + res);
            
//        }
//        int manipulate(int a, int b, int c)
//        //called
//        {
//            return a * b * c;
//        }
//        public static void Main()
//        //caller
//        {
//            area a = new area();
//         int val1=  a.manipulate(5, 3);
//         Console.WriteLine("op is:"+val1);
//          int val2=  a.manipulate(3, 3,3);
//          Console.WriteLine("op is:" + val2);
//        }
//    }
//    }
