﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
//{
//    class Class2
//        //polymorphism1
//    {
//        int p,q;
//        public void accept(int i, int j)
//        {
//            p = i;
//            q = j;
//        }
//        public void produce()
//        {
//            Console.WriteLine("the values are:{0} and{1}",p,q);
//        }
//        public static void Main()
//        {
//            Class2 ob = new Class2();
//            ob.accept(10, 20);
//            ob.produce();
//        }
//    }
//}
