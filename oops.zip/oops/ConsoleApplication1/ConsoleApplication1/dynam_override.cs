﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
//{
//    class mammal
//    {
//        public virtual void move()
//        {
//            Console.WriteLine("mammals can move");
//        }
//    }
//        class human : mammal
//        {
//            public override void move()
//            {
//                Console.WriteLine("humans move using legs");
//            }
//        }
//    class whale:mammal
//    {
//        public override void move()
//        {
//            Console.WriteLine("limb");
//        }
//            public static void Main()
//            {
//                mammal m = new mammal();
//                m.move();
//                m = new human();
//                m.move();
//                m = new whale();
//                m.move();
//            }
//    }     
//}   
