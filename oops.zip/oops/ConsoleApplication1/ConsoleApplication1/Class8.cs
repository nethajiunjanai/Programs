﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
//{
//    //class match
//    //{ 
//    //    string tw,td;
//    //    void toss( string tw,string td)
//    //    {
//    //        this.tw = tw;
//    //        this.td = td;
//    //    }
//    //    public void disp()
//    //    {
//    //        Console.WriteLine("toss won by {0} decided to {1}",tw,td);
//    //    }
//    //    public static void Main()
//    //    {
//    //        match m1= new match();
//    //        m1.toss("kkr", "batting");
//    //        m1.disp();
//    //    }
//    //}
//    class match
//    {
//        string tw, td;
//        public void data()
//        {
//            tw = Console.ReadLine();
//            td = Console.ReadLine();
//            show();
//        }
//        public void show()
//        {
//            Console.WriteLine("{0},{1}",td,tw);
//        }
//        public static void Main()
//        {
//            match m = new match();
//            m.data();
//        }
//    }
//}
