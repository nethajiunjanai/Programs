﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
//{
//    //this keyword
//    class class4
       
//    {
//        public int sid;
//        public string sname;
//        public void accept(int sid, string sname)
//        {
//            this.sid = sid;
//            this.sname = sname;
//        }
//            public void display()
//            {
//                Console.WriteLine("the student id is"+sid);
//                Console.WriteLine("the student id is"+sname);
//            }
//        public static void Main()
//       { 
//            class4 c=new class4();
//            c.accept(5,"ram");
//            c.display();
//        }
        
//    }
//}

