﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
//{
// class Program
//    {
//        public int x; 
//        int y;
//      public  void accept()
//    {
            
//        x=30;
//        y = 20;
//        add();
//    }
//      public  void add()
//        {
//            int total;
//            total = x + y;
//            Console.WriteLine("the output is :" + total);
//        }
//        static void Main(string[] args)
//        {
//            Program p = new Program();
//            p.accept();
//            student s = new student();
//            s.store();
//            s.display();
//            //   p.add();
//        }
//    }
//    class student
//    {
//       public int sid;
//       protected string sname;
//       public void store()
//        {
//            sid = 10;
//            sname = "chn17id001";
//        }
//       public void display()
//        {
//            Console.WriteLine("the student id is" +sid);
//            Console.WriteLine("the student name is" + sname);
//        }
//    }
//}
