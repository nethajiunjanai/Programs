﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
////abstract class
//{
//    public abstract class shape
//    {
//        public abstract void area();
//        public void show()
//        {
//            Console.WriteLine("from nonabstarct method");
//        }
       
//    }
//    class square : shape
//    {
//        public override void area()
//        {
//            Console.WriteLine("the area is");
//        }
//        public void next()
//        {
//            Console.WriteLine("understood");
//        }
//        public static void Main()
//        {
//           // shape s = new square();
//            square s=new square();
//            s.show();
//            s.area();
//            s.next();
//        }

//    }

//}

