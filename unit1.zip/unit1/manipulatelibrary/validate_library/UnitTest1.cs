﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using manipulatelibrary;
using System.Collections.Generic;

namespace validate_library
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            manipulate m = new manipulate();//arrange
            int result = m.addition(5, 6);//act
            Assert.AreEqual(11, result);//assert
        }
         [TestMethod]
        public void TestMethod2()
        {
            manipulate m = new manipulate();
            bool b = m.showresult();
             Assert.AreEqual(true,b);
        }
         [TestMethod]
         public void testmethod3()
         {
             //List<string> l1 = new List<string>();
             //l1.Add("A");
             //List<string> l2 = new List<string>();
             //l2.Add("B");
             //CollectionAssert.AreEqual(l1,l2);
             List<string> l3 = new List<string>() {"aa","bb","cc","dd" };
            // CollectionAssert.AllItemsAreUnique(l3);
             CollectionAssert.AllItemsAreNotNull(l3);
             // CollectionAssert.Contains(l3, "acc");
         }
    }
}
