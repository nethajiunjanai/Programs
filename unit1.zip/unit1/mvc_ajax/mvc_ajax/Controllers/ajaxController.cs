﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvc_ajax.Models;
namespace mvc_ajax.Controllers
{
    public class ajaxController : Controller
    {
        //
        // GET: /ajax/
        dreamhomeEntities de = new dreamhomeEntities();

        public ActionResult Index()
        {
            return View();
        }


        public ActionResult All()
        {
            System.Threading.Thread.Sleep(2000);
            List<tblStudent> li = de.tblStudents.ToList();
            return PartialView("_student", li);
        }
        public ActionResult Top3()
        {
            System.Threading.Thread.Sleep(2000);
            List<tblStudent> li = de.tblStudents.OrderByDescending(c => c.TotalMarks).Take(3).ToList();
            return PartialView("_student", li);
        }
        public ActionResult Bottom3()
        {
            System.Threading.Thread.Sleep(2000);
            List<tblStudent> li = de.tblStudents.OrderBy(c => c.TotalMarks).Take(3).ToList();
            return View("_student", li);
        }
    }
       
}
