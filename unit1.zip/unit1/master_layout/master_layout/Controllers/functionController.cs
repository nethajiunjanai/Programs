﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace master_layout.Controllers
{
    public class functionController : Controller
    {
        //
        // GET: /function/

        public ActionResult home()
        {
            return View("home");
        }

        public ActionResult fb()
        {
            return View("fb");
        }


        public ActionResult twitter()
        {
            return View("twitter");
        }


        public ActionResult aboutus()
        {
            return View("aboutus");
        }


        public ActionResult contactus()
        {
            return View("contactus");
        }

    }
}
