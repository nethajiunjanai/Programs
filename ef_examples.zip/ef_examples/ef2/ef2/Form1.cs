﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace ef2
{
    public partial class Form1 : Form
    {
        chn17id001Entities ch;
        public Form1()
        {
            InitializeComponent();
            ch = new chn17id001Entities();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
             //ch = new chn17id001Entities();\
            var info=ch.products;
            MessageBox.Show(info.ToString());//query translation-automatically creates query structure
            int total = ch.products.Count();
            if (total > 0)
            {
               // var res = (from s in ch.products orderby s.prod_id descending select s).First();
                 var res = ch.products.OrderBy(a => a.prod_id).First();
                 textBox1.Text = res.prod_id.ToString();
                 textBox2.Text = res.prod_name.ToString();
                 textBox3.Text = res.mfg_date.ToString();
                 textBox4.Text = res.exp_date.ToString();
                 textBox5.Text = res.price.ToString();
                 textBox6.Text = res.company.ToString();
            }
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var res = ch.products.OrderBy(a => a.prod_id).First();
            textBox1.Text = res.prod_id.ToString();
            textBox2.Text = res.prod_name.ToString();
            textBox3.Text = res.mfg_date.ToString();
            textBox4.Text = res.exp_date.ToString();
            textBox5.Text = res.price.ToString();
            textBox6.Text = res.company.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var res = (from s in ch.products orderby s.prod_id descending select s).First();
           // var res = ch.products.OrderBy(a => a.prod_id).First();
            textBox1.Text = res.prod_id.ToString();
            textBox2.Text = res.prod_name.ToString();
            textBox3.Text = res.mfg_date.ToString();
            textBox4.Text = res.exp_date.ToString();
            textBox5.Text = res.price.ToString();
            textBox6.Text = res.company.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int val = Int32.Parse(textBox1.Text);
            if (textBox1.Text != ch.products.Max(o => o.prod_id).ToString())
            {
                var data = ch.products.Where(o => o.prod_id > val).OrderBy(b => b.prod_id).First();
                textBox1.Text = data.prod_id.ToString();
                textBox2.Text = data.prod_name.ToString();
                textBox3.Text = data.mfg_date.ToString();
                textBox4.Text = data.exp_date.ToString();
                textBox5.Text = data.price.ToString();
                textBox6.Text = data.company.ToString();
            }
            else
            {
                MessageBox.Show("end of table");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int val = Int32.Parse(textBox1.Text);
            if (textBox1.Text != ch.products.Min(o => o.prod_id).ToString())
                
            {
                var data = ch.products.Where(o => o.prod_id < val).OrderByDescending(b => b.prod_id).First();
                textBox1.Text = data.prod_id.ToString();
                textBox2.Text = data.prod_name.ToString();
                textBox3.Text = data.mfg_date.ToString();
                textBox4.Text = data.exp_date.ToString();
                textBox5.Text = data.price.ToString();
                textBox6.Text = data.company.ToString();
            }
        }
   
    }
}
