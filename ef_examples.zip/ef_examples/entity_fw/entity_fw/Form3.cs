﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace entity_fw
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dreamhomeEntities2 dh = new dreamhomeEntities2();
            var data = (from s in dh.staffs
                       join r in dh.registrations on s.staffNo equals r.staffNo
                       select new { s.fname, s.oPosition, r.dateJoined }).ToList();
            var d = dh.staffs.Join(dh.registrations, first => first.staffNo, second => second.staffNo, (stf, reg) => new { s = stf, r = reg }).Select
                (c => new { c.s.fname, c.s.oPosition, c.r.dateJoined }).ToList();
                
            dataGrid1.DataSource = d;
        }
    }
}
