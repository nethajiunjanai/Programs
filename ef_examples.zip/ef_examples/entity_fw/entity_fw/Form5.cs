﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;


namespace entity_fw
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dreamhomeEntities2 dh = new dreamhomeEntities2();
            string data = textBox1.Text;
            var res = dh.disp_branch_bno(data).FirstOrDefault();
            if (res != null)
            {

                textBox2.Text = res.street;
                textBox3.Text = res.city;
                textBox4.Text = res.postcode;
            }
            else
                MessageBox.Show("invalid");
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
