﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;
using System.Data.Objects;

namespace entity_fw
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dreamhomeEntities2 dh = new dreamhomeEntities2();
            string data = textBox1.Text;
            ObjectParameter p1 = new ObjectParameter("cnt", typeof(int));         
            dh.disp_staff_branch(data, p1);
            MessageBox.Show(p1.Value.ToString());
           
          
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }
          
    }
}
 