﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace entity_fw
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        { 
            //dreamhomeEntities d = new dreamhomeEntities();
            //dataGrid1.DataSource = d.branches.ToList();
            dreamhomeEntities2 dh = new dreamhomeEntities2();
          //  dataGrid1.DataSource = (from s in d.staffs select s).ToList();
            //dataGrid1.DataSource=dh.staffs.Select(d=>new{  d.staffNo,d.fName,d.lName,d.oPosition}).ToList();
            //dataGrid1.DataSource = (from s in dh.staffs select new { s.staffNo,s.fName,s.lName,s.oPosition}).ToList();

          //disp staffname,staffno,salary,noof registration
         // dataGrid1.DataSource=(from s in dh.staffs select new{staffnum=
        dataGrid1.DataSource=dh.staffs.Select(d=> new{staffnum=d.staffNo,staffname=d.fname,amount=d.salary,reg_count=d.registrations.Count()}).ToList();

         //disp staff no ,city,fname of staff
          //dataGrid1.DataSource=dh.staffs.Select(d=>new{d.staffNo,d.fname,d.branch.city}).ToList();

            //staff fname,position,datejoined from registration table
        }
    }
}
