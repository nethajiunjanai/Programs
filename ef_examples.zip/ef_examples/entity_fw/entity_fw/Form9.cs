﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace entity_fw
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dreamhomeEntities2 dh = new dreamhomeEntities2();
            string str = textBox1.Text;
            var res = (from s in dh.branches where s.branchNo==textBox1.Text select s).FirstOrDefault();
            if (res != null)
            {

                textBox2.Text = res.street;
                textBox3.Text = res.city;
                textBox4.Text = res.postcode;
            }
            else
                MessageBox.Show("no such branchno exists");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            dreamhomeEntities2 dh = new dreamhomeEntities2();
            dh.branches.Remove(dh.branches.Remove(dh.branches.Where(o => o.branchNo == textBox1.Text).First()));
            int res1 = dh.SaveChanges();
            MessageBox.Show("updating");
            branch b = new branch();
            // textBox1.Text=b.branchNo ;
            // textBox2.Text=b.street ;
            //textBox3.Text= b.city;
            //textBox4.Text= b.postcode ;
            b.branchNo = textBox1.Text;
            b.city = textBox3.Text;
            b.street = textBox2.Text;
            b.postcode = textBox4.Text;
            dh.branches.Add(b);
            int res= dh.SaveChanges();
            MessageBox.Show(res + "rows updated");
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }
    }
}
