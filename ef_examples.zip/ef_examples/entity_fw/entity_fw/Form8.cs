﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace entity_fw
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dreamhomeEntities2 dh = new dreamhomeEntities2();
           
           int cou = dh.branches.Where(o => o.branchNo == textBox1.Text).Count();
           if (cou > 0)
           {
               dh.branches.Remove(dh.branches.Remove(dh.branches.Where(o=>o.branchNo==textBox1.Text).First()));
           
              //dh.branches.Remove((from s in dh.branches where s.branchNo==textBox1.Text select s).FirstOrDefault()); 

              int res= dh.SaveChanges();
              MessageBox.Show(res.ToString() + "rows deleted");
           }
           else
               MessageBox.Show("invalid");
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }
    }
}
