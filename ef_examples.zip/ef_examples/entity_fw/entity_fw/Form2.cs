﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace entity_fw
{
    public partial class Form2 : Form
    {
        dreamhomeEntities2 dh;
        public Form2()
        {
            InitializeComponent();
            dh = new dreamhomeEntities2();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sfno = comboBox1.Text;
            dataGrid1.DataSource = dh.branches.Where(c => c.branchNo == sfno).Select(n=>new
                {n.branchNo,n.city,n.street,n.postcode}).
                ToList();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            var data = dh.branches.Select(c => c.branchNo);
            foreach (var v in data)
            {
                comboBox1.Items.Add(v); 
            }
        }
    }
}
