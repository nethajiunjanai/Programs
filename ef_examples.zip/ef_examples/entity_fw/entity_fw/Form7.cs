﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace entity_fw
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            dreamhomeEntities2 dh = new dreamhomeEntities2();
            var data = (from s in dh.branches orderby s.branchNo descending select s).First();
            textBox1.Text = data.branchNo;
            string str = textBox1.Text.ToString();
            str = str.Substring(1, 3);
            int i = int.Parse(str);
            i++;
            if (i < 10)
            {
                str = string.Concat("B00", i);
                textBox1.Text = str;
            }
            else if (i < 100)
            {
                str = string.Concat("B0", i);
                textBox1.Text = str;
            }
            else
            {
                str = string.Concat("B00", i);
                textBox1.Text = str;
            }
            textBox1.Enabled = false;
          //  MessageBox.Show(str);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dreamhomeEntities2 dh = new dreamhomeEntities2();
            branch b = new branch();
            b.branchNo = textBox1.Text;
            b.city = textBox3.Text;
            b.street=textBox2.Text;
            b.postcode=textBox4.Text;
            dh.branches.Attach(b);
            dh.branches.Add(b);
            int res=dh.SaveChanges();
            MessageBox.Show(res.ToString() + "rows inserted");
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }
    }
}
