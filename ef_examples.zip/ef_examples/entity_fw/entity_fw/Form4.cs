﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace entity_fw
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dreamhomeEntities2 dh = new dreamhomeEntities2();
            var v = textBox1.Text;
            var data = (from s in dh.staffs where v==s.staffNo select new {  s.fname, s.lname, s.oPosition, s.sex, s.salary }).FirstOrDefault();
            if (data !=null)
            {
               
                textBox2.Text = data.fname;
                textBox3.Text = data.lname;               
                textBox4.Text = data.oPosition;
                textBox5.Text = data.sex;
                textBox6.Text = data.salary.ToString();
                textBox2.Enabled = false;
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                textBox6.Enabled = false; 
            }
            else
            {
                MessageBox.Show("invalid");
            }
        }
    }
}
