﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace unittest_mvc.Controllers
{
    public class studentController : Controller
    {
        //
        // GET: /student/

        public ActionResult changedata(int type)
        {
            if (type == 1)
            {
                return View("be");
            }
            else if (type == 2)
            {
                return View("mca");
            }
            else
            {
                return Content("not valid choice");
            }
        }

    }
}
