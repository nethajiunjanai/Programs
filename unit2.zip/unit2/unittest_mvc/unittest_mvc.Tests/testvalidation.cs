﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using unittest_mvc.Controllers;
using System.Web.Mvc;
namespace unittest_mvc.Tests
{
    [TestClass]
   public class testvalidation
    {
        [TestMethod]
        public void testmethod1()
        {
            studentController sc = new studentController();
            var res = sc.changedata(2) as ViewResult;
            Assert.AreEqual("mca", res.ViewName);
        }
        
        
    }
}
