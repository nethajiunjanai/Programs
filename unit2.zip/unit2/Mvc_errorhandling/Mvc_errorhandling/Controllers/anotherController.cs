﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc_errorhandling.Controllers
{
    public class anotherController : Controller
    {
        //
        // GET: /another/
        [HandleError]
        public ActionResult Index()
        {
            throw new Exception("some problem Happened");
        }

        public ActionResult Index1()
        {
            throw new Exception("some problem Happened");
        }
    }
}
