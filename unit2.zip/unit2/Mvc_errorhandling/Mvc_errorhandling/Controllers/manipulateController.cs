﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc_errorhandling.Controllers
{
    public class manipulateController : Controller
    {
        //
        // GET: /manipulate/

        public ActionResult Index()
        {
            int z;
            try
            {
                int x = 20;
                int y = 0;
                z = x / y;
            }
            catch(Exception e)
            {
                return Content("Error is :"+e.Message.ToString());
            }
            return Content("the op is" +z);
        }

    }
}
