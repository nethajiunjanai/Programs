create table matchdetails
(matchid varchar(20),
team1 varchar(20),
team2 varchar(20),
venue varchar(20),
umpireid1 varchar(20),
umpireid2 varchar(20),
umpireid3 varchar(20),
--constraint mat_pk primary key(matchid),
constraint masum_fk foreign key(matchid) references matchsummary(matchid),
constraint masum_fka foreign key(venue) references venue(venue),
constraint mteam1_fk foreign key(team1) references team(team),
constraint mteam2_fk foreign key(team2) references team(team),
constraint uid1_fk foreign key(umpireid1) references umpire(umpid),
constraint uid2_fk foreign key(umpireid2) references umpire(umpid),
constraint uid3_fk foreign key(umpireid3) references umpire(umpid)
);

create table matchsummary
(
matchid varchar(20) primary key,
tosswinner varchar(20),
tossdecision varchar(20),
winner varchar(20),
pom varchar(20),
--constraint masum_fk foreign key(matchid) references matchdetails(matchid)
);

create table venue
(venueid varchar(20), 
cityname varchar(20),
venue varchar(20) primary key,
--constraint venue_pk primary key(venueid)
);

create table team
(teamid varchar(20),
team varchar(20),
constraint team_px primary key(team),
);

drop table matchdetails
create table umpire
(umpid varchar(20),
umpirename varchar(20),
constraint u_pk primary key(umpid));
