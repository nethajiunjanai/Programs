select * from product;
select * from supplier;
select * from customer;
select * from emptable

create schema dreamhome;

--drop table dreamhome.registration;
create table registration
(
clientNo             varchar(7) NOT NULL,
branchNo             char(4)NOT NULL,
staffNo                    varchar(5)NOT NULL,
dateJoined           date NOT NULL,
constraint regis_pk primary key(clientNo,branchNo),
constraint stno_fk foreign key(staffNo) references staff(staffNO)
);

create table staff
(
staffNo                    varchar(5) NOT NULL,
fname                varchar(15) NOT NULL,
lname                varchar(15) NOT NULL,
oPosition            varchar(10) NOT NULL,
sex                        char(1) NOT NULL,
DOB                        date NOT NULL,
salary               decimal(9,2) NOT NULL,
branchNo                   char(4) NOT NULL,
constraint staff_pk primary key(staffNo),
constraint branch_fk foreign key(branchNo) references branch(branchNo)  
);

create table privateowner
(
ownerNo                    varchar(7) NOT NULL,
fname                varchar(15) NOT NULL,
lname                varchar(15) NOT NULL,
addres               varchar(50) NOT NULL,
telNo                varchar(13) NOT NULL,
constraint owner_pk primary key(ownerNo)
);

create table viewing
(
clientNo             varchar(7) NOT NULL,
propertyNo           varchar(8) NOT NULL,
ViewDate             date NOT NULL,
comments             varchar(50),
constraint view_pk primary key(clientNo,propertyNo) 
);

create table propertyforrent
(
propertyNo           varchar(8) NOT NULL,
street               varchar(25) NOT NULL,
city                 varchar(15) NOT NULL,
postcode             varchar(8) NOT NULL,
propertyType varchar(10) NOT NULL,
rooms         smallint NOT NULL,
rent          decimal(5,1) NOT NULL,
ownerNo              varchar(07) NOT NULL,
staffNo              varchar(05),
branchNo      char(04) NOT NULL,
constraint propertyrent_pk primary key(propertyNo),
constraint owner_fk foreign key(ownerNo) references privateowner(ownerNo)
);


create table branch
(
branchNo      char(04) not null,
street        varchar(25) not null,
city          varchar(15) not null,
postcode      varchar(08) not null,
constraint branch_pk primary key(branchNo)
);

create table client
(      
clientNo             varchar(7) NOT NULL,
fname                varchar(15) NOT NULL,
lname                varchar(15) NOT NULL,
telNo                varchar(13) NOT NULL,
prefType             varchar(10) NOT NULL,
maxRent                    decimal(5,1) NOT NULL,
constraint client_pk primary key(clientNo) 
);


--Insertion of records

INSERT [Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B002      ', N'56 Clover Dr', N'London    ', N'NW10 6EU  ');
INSERT [Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B003      ', N'163 Main St', N'Glasgow   ', N'G11 9QX   ');
INSERT [Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B004      ', N'32 Manse Rd', N'Bristol   ', N'BS99 1NZ  ');
INSERT [Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B005      ', N'22 Deer RD', N'London    ', N'SW1 4EH   ');
INSERT [Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B007      ', N'16 Argyll St', N'Aberdeen  ', N'AB2 3SU   ');
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT [Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR56      ', N'Aline     ', N'Stewart   ', N'0141-848-1825       ', N'Flat      ', 350);
INSERT [Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR62      ', N'Mary      ', N'Tregear   ', N'01224-196720        ', N'Flat      ', 600);
INSERT [Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR74      ', N'Mike      ', N'Ritchie   ', N'01475-392178        ', N'House     ', 750);
INSERT [Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR76      ', N'John      ', N'Kay       ', N'0207-774-5632       ', N'Flat      ', 425);

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT [PrivateOwner] ([ownerNo], [fName], [lName], [addres], [telNo]) VALUES (N'CO40      ', N'Tina      ', N'Murphy    ', N'63 Well St, Glasgow G42', N'0141-943-1728       ');
INSERT [PrivateOwner] ([ownerNo], [fName], [lName], [addres], [telNo]) VALUES (N'CO46      ', N'Joe       ', N'Keogh     ', N'2 Fergus Dr, Aberdeen AB2 7SX', N'01224-861212        ');
INSERT [PrivateOwner] ([ownerNo], [fName], [lName], [addres], [telNo]) VALUES (N'CO87      ', N'Carol     ', N'Farrel    ', N'6 Achray St, Glasgow G32 9DX', N'0141-357-7419       ');
INSERT [PrivateOwner] ([ownerNo], [fName], [lName], [addres], [telNo]) VALUES (N'CO93      ', N'Tony      ', N'Shaw      ', N'12 Park P, Glasgow G4 0QR', N'0141-225-7025       ');

------------------------------------------------------------------------------------------------------

INSERT [PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PA14      ', N'16 Holhead', N'Aberdeen  ', N'AB7 5SU   ', N'House     ', 6, 650, N'CO46      ', N'SA9       ', N'B007      ');
INSERT [PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PL94      ', N'6 Argyll St', N'London    ', N'NW2       ', N'Flat      ', 4, 400, N'CO87      ', N'SL41      ', N'B005      ');
INSERT [PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG4       ', N'6 Lawrence St', N'Glasgow   ', N'G11 9QX   ', N'Flat      ', 3, 350, N'CO40      ', NULL, N'B003      ');
INSERT [PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG36      ', N'2 Manor Rd', N'Glasgow   ', N'G32 4QX   ', N'Flat      ', 3, 375, N'CO93      ', N'SG37      ', N'B003      ');
INSERT [PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG21      ', N'18 Dale Rd', N'Glasgow   ', N'G12       ', N'House     ', 5, 600, N'CO87      ', N'SG37      ', N'B003      ');
INSERT [PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG16      ', N'5 Novar Dr', N'Glasgow   ', N'G12 0Ax   ', N'Flat      ', 4, 450, N'CO93      ', N'SG14      ', N'B003      ');

-------------------------------------------------------------------------------------------------------

INSERT [Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SA9       ', N'MAry      ', N'Howe      ', N'Assistant ', N'F', CAST(N'1970-02-10' AS Date), 9000, N'B007      ');
INSERT [Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SG14      ', N'David     ', N'Ford      ', N'Supervisor', N'M', CAST(N'1958-03-24' AS Date), 18000, N'B003      ');
INSERT [Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SG37      ', N'Ann       ', N'Beech     ', N'Assistant ', N'F', CAST(N'1960-11-10' AS Date), 12000, N'B003      ');
INSERT [Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SG5       ', N'Susan     ', N'Brand     ', N'Manager   ', N'F', CAST(N'1940-06-03' AS Date), 24000, N'B003      ');
INSERT [Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SL21      ', N'John      ', N'White     ', N'Manager   ', N'M', CAST(N'1945-10-01' AS Date), 30000, N'B005      ');
INSERT [Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SL41      ', N'Julie     ', N'Lee       ', N'Assistant ', N'F', CAST(N'1965-06-13' AS Date), 9000, N'B005      ');

---------------------------------------------------------------------------------------------------------

INSERT [Viewing] ([clientNo], [propertyNo], [viewDate], [comments]) VALUES (N'CR56      ', N'PA14      ', CAST(N'2004-05-24' AS Date), N'too small');
INSERT [Viewing] ([clientNo], [propertyNo], [viewDate], [commentS]) VALUES (N'CR76      ', N'PG4       ', CAST(N'2004-04-20' AS Date), N'too remote');
INSERT [Viewing] ([clientNo], [propertyNo], [viewDate], [commentS]) VALUES (N'CR56      ', N'PG4       ', CAST(N'2004-05-26' AS Date), N'');
INSERT [Viewing] ([clientNo], [propertyNo], [viewDate], [commentS]) VALUES (N'CR62      ', N'PA14      ', CAST(N'2004-05-14' AS Date), N'no dining room');
INSERT [Viewing] ([clientNo], [propertyNo], [viewDate], [commentS]) VALUES (N'CR56      ', N'PG36      ', CAST(N'2004-04-28' AS Date), NULL);

--------------------------------------------------------------------------------------------------
INSERT INTO Registration VALUES ('CR76', 'B005', 'SL41', '2001-01-02');
INSERT INTO Registration VALUES ('CR56', 'B003', 'SG37', '2000-04-11');
INSERT INTO Registration VALUES ('CR74', 'B003', 'SG37', '1999-11-16');
INSERT INTO Registration VALUES ('CR62', 'B007', 'SA9',  '2000-03-07');

--------------------------------------------------------------------------------------------------
select * from staff;
select * from branch;
select * from client;
select * from privateowner;
select * from propertyforrent;
select * from registration;

select * from viewing;