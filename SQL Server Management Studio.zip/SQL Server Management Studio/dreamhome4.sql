subquery
1. List the staff who work in the branch at �163 Main St�.
2. List all staff whose salary is greater than the average salary, and show by how much their salary is greater than the average.
3. List the properties that are handled by staff who work in the branch at �163 Main St�.
4. Find all staff whose salary is larger than the salary of at least one member of staff at branch B003.
5. Find all staff whose salary is larger than the salary of every member of staff at branch B003.
6. Find all staff who work in a London branch office. (Try with Exists/Not Exists Operator).

--1--
select * from Dream_Home.staff where branchno=(select branchno from Dream_Home.branch where street='163 Main st');
--2--
select *,salary-(select avg(salary) from Dream_Home.staff) from Dream_Home.staff 
where salary>(select avg(salary) from Dream_Home.staff);
--3--
select * from Dream_Home.propertyforrent where branchno=(select branchno from Dream_Home.branch where street='163 Main st');
--4--
select * from Dream_Home.staff where salary> any(select salary from Dream_Home.staff where branchno='B003');
--5--
select * from Dream_Home.staff where salary> all(select salary from Dream_Home.staff where branchno='B003');
--6--
select * from Dream_Home.staff where  branchno in (select branchno from Dream_Home.branch where city='london');
select * from Dream_Home.staff where  exists  
 (select branchno from Dream_Home.branch where city='london');
