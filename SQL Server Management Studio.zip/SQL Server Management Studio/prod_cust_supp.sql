use chn17id001;
create schema nethaji;
create table nethaji.product_table
(prodid int identity(100,1),
prodname varchar(25) not null,
manufacturedate date,
expirydate date,
price numeric(5,2),
company varchar(25),
constraint prod_pk primary key(prodid),
constraint prod_md_chk check(manufacturedate <=getdate()),
constraint prod_pri_chk check(price >0)
);


drop table nethaji.product_table;
create table nethaji.supplier_table
(supplierid int identity(1,1),
suppliername varchar(20) not null,
prodid int,
location varchar(20),
constraint sup_pk primary key(supplierid),
constraint sup_loc_chk check(location in ('chennai', 'hyderabad' ,'bangalore'))
);
drop table nethaji.supplier_table;
create table nethaji.supplier_table
(supplierid int,
suppliername varchar(20) not null,
prodid int,
location varchar(20),
constraint sup_pk primary key(supplierid),
constraint sup_loc_chk check(location in ('chennai', 'hyderabad' ,'bangalore')),
constraint sup_pid_fk foreign key(prodid) references nethaji.product_table(prodid)
);
--for dropping a column---
alter table nethaji.product_table drop column expirydate;
--for adding a column---
alter table nethaji.product_table add expirydate date;
--rename a column---------
sp_rename 'nethaji.product_table.expirydate','expdate','column';
sp_rename 'nethaji.product_table.expdate','expirydate','column';
--modify datatype-----
alter table nethaji.product_table alter column prodname varchar(50);
create table nethaji.customer_table
(
cusid int identity(10,1) ,
custname varchar(25),
dob date,
bloodgroup varchar(20),
mobileno bigint,
addres varchar(200),
prodid int,
quantity int,
total int,
constraint cus_pk primary key(cusid),
constraint cus_fk foreign key(prodid) references nethaji.product_table(prodid),
constraint mobnum_chk  check(len(mobileno)=10)
);
drop table nethaji.customer_table;
--insert values to table
insert into nethaji.product_table
(prodname,manufacturedate,expirydate,price,company)
values 
('hamam','2016-04-04','2017-06-05',35,'hindustanlever');
('pears','2016-05-03','2017-07-05',41,'pear'),
('cinthol','2016-06-03','2017-08-05',33,'amway'),
('santoor','2016-07-03','2017-09-05',30,'hindustanlever'),
('lifebuoy','2016-08-03','2017-10-05',27,'itc'),
('dettol','2016-09-03','2017-11-05',34,'dettol');

 select * from nethaji.product_table;
 --update value in table
 update nethaji.product_table set price=50 where company='dettol';
 --delete value in table
 delete from nethaji.product_table  where prodid=106;
 --rename table
 sp_rename 'nethaji.product_table','producttable';
 --insert into suppliertable
 insert into nethaji.supplier_table
 (supplierid,suppliername,prodid,location)
 values
 (1,'vikky',102,'chennai'),
 (2,'bahu',104,'hyderabad'),
 (3,'bal',105,'bangalore');
 select * from nethaji.supplier_table;
 select * from nethaji.customer_table;
  insert into nethaji.customer_table
  (custname,dob,bloodgroup,mobileno,addres,prodid,quantity,total)
  values 
  ('vignesh','1994-11-21','b+ve',9898438323,'chennai-28',101,2,82),
  ('jinesh','1994-11-20','b+ve',9898438323,'hyderabad-28',102,2,66),
  ('siva','1994-11-22','b+ve',9898438323,'banglore',103,2,60),
  ('kiran','1994-11-23','b+ve',9898438323,'chennai-28',101,2,82),
  ('vignesh','1994-11-24','b+ve',9898438323,'bangalore',105,2,100),
  ('bahubali','1994-11-24','b+ve',9898438323,'hyderabad-28',102,2,66),
  ('saravana','1994-11-25','b+ve',9898438323,'hyderabad-28',101,2,82),
  ('sanju','1994-11-26','b+ve',9898438323,'chennai-28',102,2,66),
  ('anto','1994-11-27','b+ve',9898438323,'hyderabad-28',104,2,54),
  ('ajay','1994-11-28','b+ve',9898438323,'chennai-28',107,2,70);

  --truncate--
  create table t
  (
  id int,
  name varchar(10)
  );
  insert into t
  values(1,'bahu');
   select * from t
  truncate table t;
  select * from t
  truncate table nethaji.product_table;
   truncate table nethaji.supplier_table;
    truncate table nethaji.customer_table;
	drop table nethaji.product_table;
   drop table nethaji.supplier_table;
   drop table nethaji.customer_table;


	create table product
(
	prod_id int identity(1,1),
	prod_name varchar(25) NOT NULL,
	mfg_date date,
	exp_date date,
	price numeric(5,2),
	company varchar(25),
	constraint prod_pk primary key(prod_id),
	constraint prod_mfg_check check(mfg_date<=getdate()),
	constraint prod_price_check check(price>0),
);



insert into product(prod_name,mfg_date,exp_date,price,company) values ('chocolate','2017-05-26','2017-12-15','520.01','itc');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('biscuit','2016-05-26','2017-12-15','250','itc');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('cake','2017-06-01','2017-06-30','520.01','ibacco');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('mobile','2017-05-26','2020-12-15','999.01','redmi');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('pc','2016-05-26','2020-12-15','999','lenovo');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('medicine','2017-06-01','2017-12-30','420.01','pharma');
insert into product(prod_name,mfg_date,exp_date,price,company) values ('shirt','2017-06-01','2025-12-30','500','derby');




create table supplier
(
	supp_id int  identity(1,1),
	Supp_name varchar(20) not null,
	prod_id int,
	location varchar(20),
	constraint supp_pk primary key(supp_id),
	constraint supp_loc_check check(location in('chn','bge','hyd')),
	constraint sup_pid_fk foreign key(prod_id) references product(prod_id)
);


insert into supplier values('wsretail','1','chn');
insert into supplier values('infy','5','bge');
insert into supplier values('cloudtail','6','hyd');





create table customer
(
cust_id int identity(1,1),
cust_name varchar(25),
dob date,
blood_group varchar(20),
mobileno bigint,
addres varchar(200),
prod_id int,
qty int,
constraint cus_pk primary key(cust_id),
constraint cus_pid_fk foreign key(prod_id) references product(prod_id)
);

insert into customer values('vivek','1995-01-01','o+ve',9843608701,'bangalore',1,3);
insert into customer values('ganesh','1995-01-01','o+ve',9843608701,'bangalore',1,3);
insert into customer values('alex','1995-02-01','o+ve',9843608701,'chennai',2,4);
insert into customer values('lavanya','1994-11-25','a+ve',9843608701,'pune',5,2);
insert into customer values('moani','1994-05-01','ab+ve',9843608701,'chennai',6,3);
insert into customer values('sundar','1995-02-11','o-ve',9843608701,'coimbatore',7,3);
insert into customer values('dev','1995-12-10','o+ve',9843608701,'bangalore',4,1);
insert into customer values('netha','1995-11-13','o+ve',9843608701,'bangalore',1,4);
insert into customer values('mano','1995-12-10','ab+ve',9843608701,'coimbatore',4,2);
insert into customer values('vicky','1995-11-13','o-ve',9843608701,'chennai',1,4);

insert into customer values('kavin','1995-11-13','b-ve',9843608701,null,2,4);
insert into customer values('kavin','1995-11-13','b-ve',9843608701,'chennaai',null,4);


--display all records from product,supplier,customer tables-----
select * from product;
select * from supplier;
select * from customer;
--display product name and price
select prod_name,price from product;
--manufcdate expirydate prodid--
select prod_id,mfg_date,exp_date from product;
--disply custid,mob,addr
select cust_id,mobileno,addres from customer;



--based on condition--
--comparison operators =,!=,<,>,<=,>=--
--display the biscuit product--
select * from product where prod_name='biscuit';
--display the customers who purchased more than 4 qty
select * from customer where qty>='4';
--display customer from bangalore
select * from customer where addres='bangalore';
--dispaly customer from those who dont have any addrs
select * from customer where addres is null;
--morethan one condition we have to use And or Not
--dispaly all customer who are bangalore and o+ve bloodgroup
select * from customer where addres='bangalore' and blood_group='o+ve';
--display all products whose products belongs to itc and mfg is after 2016;
select * from product where company='itc' and mfg_date>'2016-12-12'
--display the company name from the product table
select company from product;

--display the company name from the product table without duplicates--> use distinct
select distinct company from product;

--alias--
--display the product name price company for all products chanage the alias name to amount
select prod_name,price'amount', company'vendor' from product;
--display product name company 10% deduction of price
select prod_name,company,price,price*0.1'discount' from product; 
--display cuust from bang and hyd
select * from customer where addres='bangalore' or addres='pune'
----in and between----
select * from customer where addres in ('bangalore','pune');
--disp the products biscuit cake mobile
select * from product where prod_name in ('cake','mobile','biscuit');
--supplier supplying products of 5 and 6
select * from supplier where prod_id in(5,6);
--display the customer
select * from customer where qty in(2,3,4);
select * from customer where qty between 2 and 4;



--pattern matching--
--char and varchar--
--we use like , _ -->one character occurance and % -->0 or any character occurance--
--all products who are having 5 letter company name 
select * from product where company like '_____';
--products company starting with r
select * from product where company like 'r____';
--name starts with r
select * from product where company like 'r%';
--all customer contains second ltr a
select * from customer where cust_name like '_a%';
--last letter before contain e
select * from customer where cust_name like '%e_';
--contains letter a
select * from customer where cust_name like '%a%';



--sorting--
--products in the ascending order of the product name
select * from product order by prod_name asc;
select * from product order by prod_name desc;
--ascnd order of customer based on qty
select * from customer order by qty asc;
--asc of qty and dsc of name
select * from customer order by qty asc,cust_name desc;

----join---------------------------------------------
--to display product name price customer name and the total--
--theta model----------------------
select prod_name,price,cust_name,qty from product,customer where product.prod_id=customer.prod_id;
-----join keyword-----------------------------
select prod_name,price,cust_name,qty from product join customer on product.prod_id=customer.prod_id;
---display prodid,pname,sid,sname,location
select product.prod_id,prod_name,supp_id,Supp_name,location from product join supplier on product.prod_id=customer.prod_id;
 
select product.prod_id,prod_name,supp_id,Supp_name,location
from product join supplier
on product.prod_id=supplier.prod_id; 
--display cusid,cusname,product name,price where cust belongs to chennai and coim
select cust_id,cust_name,prod_name,price from product join customer 
on product.prod_id=customer.prod_id where addres in('chennai','coimbatore');
select cust_id,cust_name,prod_name,price from product join customer 
on product.prod_id=customer.prod_id and addres in('chennai','coimbatore');
---to display proid prodname custid custname suppid supplier name
select product.prod_id,prod_name,cust_id,cust_name,supp_id,Supp_name from product join supplier on
product.prod_id =supplier.prod_id join 
customer on supplier.prod_id=customer.prod_id;
---dispaly cusid csname supname location
select cust_id,cust_name,Supp_name,location from customer join supplier on supplier.prod_id=customer.prod_id;


create table productgrade
(
grade char(1),
minprice numeric(5),
maxprice numeric(5),
tolerance numeric(5,3)
);
select * from productgrade
----display pid,pname,price,company,grade--
select product.prod_id,prod_name,company,grade from product,productgrade where price between minprice and maxprice; 
create table emptable
(
emp_id int,
empname varchar(20),
city varchar(20),
designation varchar(20),
manager_id int,
sal numeric(5,2)
);
--display empid empname desig sal and managername of all emp

select a.emp_id,a.empname,a.designation,a.sal,b.empname as[Manger_name]
 from emptable a left join emptable b
 on a.manager_id=b.emp_id;
---self join-------------
select emp.emp_id,emp.empname,emp.designation,emp.sal,mgr.empname 'managername' from emptable emp join
emptable mgr on emp.manager_id=mgr.emp_id;
select * from emptable;
--cross join--
--cartesian product--
select product.prod_id,prod_name,cust_id,cust_name from product,customer;
select product.prod_id,prod_name,cust_id,cust_name from product cross join customer;
--natural join-----
select * from product,customer where product.prod_id=customer.prod_id;
select * from product join customer on product.prod_id=customer.prod_id;
select * from product  natural join customer;
--display custname productname
select cust_name,prod_name from product join customer on product.prod_id=customer.prod_id;
--display all customer name 
--left,right,full join---------------------
select cust_name,prod_name from customer left outer join
 product on product.prod_id=customer.prod_id;
 select cust_name,prod_name from customer full join
 product on product.prod_id=customer.prod_id;

 ---aggregate function---
 ---max,min,avg,count,sum-------------
select max(price) from product;
select min(price) from product;
select count(prod_id) from product;
select count(cust_id) from customer;
select count(addres) from customer;
select count(distinct addres) count from customer;
select sum(price) sum from product;
select avg(price) from product;
 
select * from product;
select * from supplier;
select * from customer;

select isnull(price,0) from product order by price;
select avg(isnull(price,0)) from product;

--display no of customer in each bloodgrp---
---each key for group by-----------
select count(cust_id) as count,blood_group from customer group by blood_group;

--disp no of cust in each address--
select count(cust_id),addres from customer group by addres;

--disp noof cust in each addres who are purchased more than two quantity
select count(cust_id)count,addres from customer  where qty>2 group by addres;  

--disp the no of cust available based on the year of dob
select count(cust_id),year(dob) from customer group by year(dob);

---mulitple grouping---
select year(dob),count(cust_id),blood_group from customer group by year(dob),blood_group;

--disp the addres wise number of people purchase the product---
select addres,count(prod_id) from customer group by addres;
select addres,count(prod_id),prod_id from customer group by addres,prod_id;

---disp the productid and how many num of people purchased--
select prod_id,count(prod_id) count from customer group by prod_id;

---disp prod name no of customer purchased the product
select prod_name,count(c.prod_id) from customer c join product p  on p.prod_id=c.prod_id group by prod_name;

--disp customername num of products he purchased
select cust_name,count(prod_id) from customer group by cust_name;

--disp productname no of product which is purchased more than 2..
select prod_name,count(c.cust_id) val from product p join customer c on c.prod_id=p.prod_id
 group by prod_name having count(c.cust_id)>2;

 --disp supp name, prod name,no of customer purchased product
 select Supp_name,prod_name,count(cust_id) from supplier s join product p on s.prod_id=p.prod_id join customer c on c.prod_id=p.prod_id
 group by Supp_name,prod_name;

 --alias name cannot be used in where group by having and can be used in order by-------------

 ----------------------------------------SUBQUERY-------------------------------------
 --Query contains another query----
 --subquery can be nested with 32 level---------
 --sqlserver 2014 can go any level ---------
 ----two types:single row subquery AND multi row subquery-----------
 ---single row subquery--if it contains operator =,!=,>,<,>=,<=
 ---disp all customers who are coming in the same addres of where mr.alex comes---
 select addres from customer where cust_name='alex';
 select * from customer where addres='chennai';
  select * from customer where addres=(select addres from customer where cust_name='alex');

  ---disp all customer who purchse same qty of ,mano purcahsed---
  select * from customer where qty=(select qty from customer where cust_name='mano');

  --disp all customer who have same blood grup of dev and exclude dev in list
  select * from customer where blood_group=(select blood_group from customer where cust_name='dev') and cust_name!='dev';

  --disp all product of which was produced in same year of mobile
  select * from product where year(mfg_date)=(select year(mfg_date) from product
   where prod_name='mobile');  
   --disp highest price product
   select * from product where price=(select max(price) from product);

   --disp second highest costly 
   select * from product where price=(select max(price) from product where 
   price<(select max(price) from product))

   select max(price) from product where price!=(select max(price) from product)

   select * from product where price=( select max(price) from product where price!=(select max(price) from product))
---select top two
select top 2 * from product order by price desc;
select * from product where row_number(5)\
--disp all products who are having morethan price of where mr.cloudtail who supply the product
select * from product where price >
(select (price) from product join supplier on product.prod_id=supplier.prod_id where Supp_name='cloudtail');

select * from product where price>(select price from product where prod_id=(select prod_id from supplier where 
Supp_name='cloudtail'));


--disp all products who are having more than the price of product id 8--
select * from product where price>(select price from product where prod_id='8');

--disp all products who are having more price of biscuit along with mfg yr of cake
select * from product where price>(select price from product where prod_name='biscuit') and year(mfg_date)=
(select year(mfg_date) from product where prod_name='cake');

--disp all products which was purchased by more than four or more
select * from product where prod_id=(
select c.prod_id from customer c join product p on c.prod_id=p.prod_id 
group by p.prod_name,c.prod_id having count(c.prod_id)>=4);

select * from product where prod_id=(select prod_id from customer  group by prod_id having count(prod_id)>=4);

--disp all products which was purchased by more than 3 or more than 3 qty
--multi row sub query we have to use in,any,all
select * from product where prod_id in (select prod_id from customer where qty>=3);


--disp all prod which are more than price of itc
select * from product where price > all
(select price from product where company='itc');
--all...checking the all data---max
select * from product where price >
(select max(price) from product where company='itc')
---any..> any --greater than any one of the result...< any --lesser than any one of the result

--to disp all produc which is greater than price of any itc
select * from product where price > any
-- > all---act like max,< all act like 
(select price from product where company='itc');

--exists opertor------
select * from product where  exists (select prod_id from customer where qty>3);

--disp all products who price is greater than avg price of all products
select * from product where price>
(select avg(price) from product

--disp all employ who are getting more than salary of all emp avg salary
select * from emptable where sal>(select avg(sal) from emptable); 
--disp all emp who are getting morethan or equal to their dept avg salary
--to solve this correlated sub query is used--\--
--it is advised to give alias name for outer query
select * from emptable e where e.sal>=(select avg(sal) from emptable where designation=e.designation);

--dip all emply who are getting highest salary in each city
select * from emptable e where e.sal=(select max(sal) from emptable where city=e.city);

--disp all customer who bought max quantity in each product
select * from customer c where qty=(select max(qty) from customer where c.prod_id=prod_id );


--disp company no of products produced by the company and number of customer purcahsd the cmpny product
-----using subquery in from------------
---derived table------
 select a.company,a.tproduct,b.tcustomer from(
(select company,count(prod_id) tproduct from product group by company) a
 join
 (select count(cust_id) tcustomer,company from customer c join product p on p.prod_id=c.prod_id group by company) b 
 on a.company=b.company);

--disp cust id cust name product name price no of cust purchase the prdct
select b.cust_id,b.cust_name,a.prod_name,a.price,a.tpro from
(
 (select prod_name,price,count(p.prod_id) tpro,p.prod_id tpro1 from product p join customer c on p.prod_id=c.prod_id
  group by prod_name,price,p.prod_id)a
 join
(select cust_id,cust_name,count(p.prod_id) tcust_id,p.prod_id from customer c join product p
on p.prod_id=c.prod_id group by cust_id,cust_name,p.prod_id)b
on tpro1=b.prod_id) ;


select cust_id,cust_name,prod_name,price,tab3.totalcust from product p join customer c on p.prod_id=c.prod_id join  
(select prod_id,count(cust_ID) [totalcust] from customer group by prod_id) tab3 on tab3.prod_id=p.prod_id; 

--------view-----------------------
---virtual table-------------------
---end user dont know the table name and entire table format---
--mechanism to retrive data--
--providing neccessary details---
--add another table details--
--hiding the complexity---
--security--
--it doesnt have any value--
create view v1 as 
select prod_id,prod_name,price from product;

select * from v1;
--create a view to disp prod name,suppname,price
create view v2 as
select prod_name,Supp_name,price from product p join supplier c on c.prod_id=p.prod_id;

alter view v2 with encryption as 
select prod_name,Supp_name,price from product p join supplier c on c.prod_id=p.prod_id;

select  * from v2;
--to view the definition of any object---
sp_helptext 'dbo.v2'; 
select * from sys.objects;
--two types of views----
--simple and complex view--
--view fetches data from one table is simple and morethan one table is complex view--

select * from product where prod_id=2000;
select * into dup from product where  1=2;--untruthful condition--structure alone
select * into dup from product;--strucuture and data
drop table dup
select * from dup
create view v3 as
select prod_id,prod_name from dup;
select * from v3;
drop table dup;
drop view v3
create view v3 with schemabinding as--while using schemabinding we cannot use select *
select prod_id,prod_name from dbo.dup;--dbo schema is must--
---we can create view from another view-----
--select,insert,delete dml operations can be done for simple view but not for complex view---
--dml is not always success because of constraints---