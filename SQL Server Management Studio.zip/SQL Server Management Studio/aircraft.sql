select * from aircraft;
select * from flights;
select * from pilots;
select * from certified;


1. Find the names of aircraft such that all pilots certified to operate them have salaries more than $80,000.
2. For each pilot who is certified for more than three aircraft, find the eid and the maximum cruisingrange of the aircraft for which she or he is certified.
3. Find the names of pilots whose salary is less than the price of the cheapest route from Los Angeles to Honolulu.
4. For all aircraft with cruisingrange over 1000 miles, find the name of the aircraft and the average salary of all pilots certified for this aircraft.
5. Find the names of pilots certified for some Boeing aircraft.
6. Find the aids of all aircraft that can be used on routes from Los Angeles to Chicago.
7. Identify the routes that can be piloted by every pilot who makes more than $100,000.
8. Print the enames of pilots who can operate planes with cruisingrange greater than 3000 miles but are not certified on any Boeing aircraft.
9. A customer wants to travel from Madison to New York with no more than two changes of flight. List the choice of departure times from Madison if the customer wants to arrive in New York by 6 p.m.
10. Compute the difference between the average salary of a pilot and the average salary of all employees (including pilots).
11. Print the name and salary of every nonpilot whose salary is more than the average salary for pilots.
12. Print the names of employees who are certified only on aircrafts with cruising range longer than 1000 miles.
13. Print the names of employees who are certified only on aircrafts with cruising range longer than 1000 miles, but on at least two such aircrafts.
14. Print the names of employees who are certified only on aircrafts with cruising range longer than 1000 miles and who are certified on some Boeing aircraft.


--1
select aname from aircraft where aid in
(select distinct aid from certified where eid in (select eid from pilots where salary>80000));
--2
select certified.eid,max(crusingrange) from certified join aircraft
on certified.aid = aircraft.aid where eid in 
(select eid from certified group by eid having count(aid) > 3) 
group by certified.eid; 



--3
select ename from pilots where salary<(select min(price) from flights where origin='Los Angeles' and destination='Honolulu');
--4
select aname, avg(salary) from certified
join pilots on certified.eid = pilots.eid 
join aircraft on certified.aid = aircraft.aid
where crusingrange > 1000 group by certified.aid,aname; 

--5
select ename from pilots where eid = any(select distinct eid from certified where aid = any 
(select aid from aircraft where aname like 'Boeing%'));
--6
select aid from aircraft where crusingrange>(select distance from flights where origin='Los Angeles' and destination='Chicago');
--7
select origin,destination from flights where distance > any(
select crusingrange from aircraft where aid = any(
select distinct aid from certified where eid= any
(select eid from pilots where salary>100000)));
--8.Print the enames of pilots who can operate planes with cruisingrange greater than 3000 miles 
--but are not certified on any Boeing aircraft.
declare @ename varchar(20);
select ename from pilots where eid = any(
select distinct eid from certified where aid in
(select aid from aircraft where aid = any(select aid from certified) and aname not like 'Boeing%'));
print(@ename);
--9--
--10--
select ( (select avg (salary) d from pilots where eid in (select eid from certified))-avg(salary)) from pilots;
--11
select ename,salary from pilots where eid not in (select eid from certified);
--12 Print the names of employees who are certified only on aircrafts with cruising range longer than 1000 miles.
select ename from pilots where eid in (select eid from certified where aid in
(select aid from aircraft where crusingrange>1000));
--13 Print the names of employees who are certified only on aircrafts with cruising range longer than 1000 miles,
-- but on at least two such aircrafts.
select ename from pilots where eid in
(select eid from certified where eid in (select eid from aircraft where crusingrange>1000) and eid in
(select eid from certified group by eid having count(eid)>2));
--14  Print the names of employees who are certified only on aircrafts with cruising range longer than 1000 miles and 
--who are certified on some Boeing aircraft.
select ename from pilots where eid in
(select eid from certified where eid in (select eid from aircraft where crusingrange>1000) and aid in
(select aid from aircraft where aname like 'Boeing%'));

