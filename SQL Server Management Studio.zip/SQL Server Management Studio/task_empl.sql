1. Print the names and ages of each employee who works in both the Hardware department and the Software department.
2. For each department with more than 20 full-time-equivalent employees (i.e., where the part-time and
 full-time employees add up to at least that many full-time
employees), print the did together with the number of employees that work in that department.
3. Print the name of each employee whose salary exceeds the budget of all of the departments that he or she works in.
4. Find the managerids of managers who manage only departments with budgets greater than $1 million.
5. Find the enames of managers who manage the departments with the largest budgets.
6. If a manager manages more than one department, he or she controls the sum of all the budgets for those departments. Find the managerids of managers who control more than $5 million.
7. Find the managerids of managers who control the largest amounts.
8. Find the enames of managers who manage only departments with budgets larger than $1 million, but at least one department with budget less than $5 million.

1---
select ename,age from emp where eid= any(
select eid from works where did = any
(select did from dept where dname='hardware' or dname='software'));
--2
--3
select ename from emp where salary> (select max(budget) from dept);
--4
select managerid from dept where budget>1000000;
--5
select ename from emp where eid= any
(
select managerid from dept where budget=(select max(budget) from dept));
--6
select managerid from dept group by managerid having sum(budget)=(
(select sum(budget) from dept where managerid=
(select managerid from dept group by managerid having count(managerid)>1 and sum(budget)>500000)));
--7
select managerid from dept where budget=(select max(budget) from dept);
--8
select ename from emp where eid= any
(select managerid from dept where budget>1000000 and budget>5000000);
