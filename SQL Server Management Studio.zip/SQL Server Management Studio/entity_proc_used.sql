create procedure disp_branch_bno @bno varchar(20) as
select street,city,postcode from branch where branchNo=@bno;
exec disp_branch_bno 'B003'

select branchno,count(staffno) from staff group by branchno;
select count(staffno) from staff where branchno='b003';

alter procedure disp_staff_branch @bno varchar(20),@cnt int out as
select count(staffno) from staff 
where branchno=@bno;

declare @a varchar(20);
exec disp_staff_branch 'b005',@a output;
print(@a);