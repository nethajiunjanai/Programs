
create database Dream_Home;
create schema Dream_Home;
create table Dream_Home.registration
(
clientNo varchar(07) not null,
branchNo char(04) not null,
staffNo varchar(05) not null,
dateJoined Date not null,
constraint regis_pk primary key(clientNo,branchNo)
);

create table Dream_Home.staff
(
staffNo		 varchar(05) not null,
fName		 varchar(15) not null,
lName	     varchar(15) not null,
oPosition	 varchar(10) not null,
sex			 char(1),
DOB			 date,
salary		 decimal(9,2) not null,
branchNo char(04) not null,
constraint staff_pk primary key(staffNo),
--constraint staff_fk foreign key(branchNo) references Dream_Home.registration(branchNo)
);

create table Dream_Home.privateowner
(
ownerNo	 varchar(07) not null,
fName	 Varchar(15) not null,
lName	 Varchar(15) not null,
address	 Varchar(50) not null,
telNo	 varchar(13) not null,
constraint pri_owner_pk primary key(ownerNo),
);
DROP TABLE 


create table Dream_Home.viewing
(
clientNo	 varchar(07) not null,
propertyNo	 varchar(08) not null,
viewDate	 date		 not null,
comments	 varchar(50),
constraint view_pk primary key(clientNo,propertyNo)
);

create table Dream_Home.propertyforrent
(
propertyNo	 varchar(08) not null,
street		 varchar(25) not null,
city		 varchar(15) not null,
postcode	 varchar(08) not null, 
propertyType varchar(10) not null,
rooms		 smallint not null,
rent		 decimal(5,1) not null,
ownerNo		 varchar(07) not null,
staffNo		 varchar(05),
branchNo	 char(04) not null,
constraint propertyrent_pk primary key(propertyNo)
);

create table Dream_Home.branch
(
branchNo	 char(04) not null,
street		 varchar(25) not null,
city		 varchar(15) not null,
postcode	 varchar(08) not null,
constraint branch_pk primary key(branchNo)
);

CREATE TABLE Dream_Home.CLIENT
(
clientNo varchar(07) not null,
fName	 Varchar(15) not null,
lName	 Varchar(15) not null,
telNo	 varchar(13) not null,
prefType varchar(10) not null,
maxrent  decimal(5,1) not null,
constraint client_pk primary key(clientNo)
);

-------------------------------------
INSERT [Dream_Home].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B002      ', N'56 Clover Dr', N'London    ', N'NW10 6EU  ');
INSERT [Dream_Home].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B003      ', N'163 Main St', N'Glasgow   ', N'G11 9QX   ');
INSERT [Dream_Home].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B004      ', N'32 Manse Rd', N'Bristol   ', N'BS99 1NZ  ');
INSERT [Dream_Home].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B005      ', N'22 Deer RD', N'London    ', N'SW1 4EH   ');
INSERT [Dream_Home].[Branch] ([branchNo], [street], [city], [postcode]) VALUES (N'B007      ', N'16 Argyll St', N'Aberdeen  ', N'AB2 3SU   ');

----------------------------------------------------------------------------------

INSERT [Dream_Home].[Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR56      ', N'Aline     ', N'Stewart   ', N'0141-848-1825       ', N'Flat      ', 350);
INSERT [Dream_Home].[Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR62      ', N'Mary      ', N'Tregear   ', N'01224-196720        ', N'Flat      ', 600);
INSERT [Dream_Home].[Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR74      ', N'Mike      ', N'Ritchie   ', N'01475-392178        ', N'House     ', 750);
INSERT [Dream_Home].[Client] ([clientNo], [fName], [lName], [telNo], [prefType], [maxRent]) VALUES (N'CR76      ', N'John      ', N'Kay       ', N'0207-774-5632       ', N'Flat      ', 425);


------------------------------------------------------------------------------------------------------------

INSERT [Dream_Home].[PrivateOwner] ([ownerNo], [fName], [lName], [address], [telNo]) VALUES (N'CO40      ', N'Tina      ', N'Murphy    ', N'63 Well St, Glasgow G42', N'0141-943-1728       ');
INSERT [Dream_Home].[PrivateOwner] ([ownerNo], [fName], [lName], [address], [telNo]) VALUES (N'CO46      ', N'Joe       ', N'Keogh     ', N'2 Fergus Dr, Aberdeen AB2 7SX', N'01224-861212        ');
INSERT [Dream_Home].[PrivateOwner] ([ownerNo], [fName], [lName], [address], [telNo]) VALUES (N'CO87      ', N'Carol     ', N'Farrel    ', N'6 Achray St, Glasgow G32 9DX', N'0141-357-7419       ');
INSERT [Dream_Home].[PrivateOwner] ([ownerNo], [fName], [lName], [address], [telNo]) VALUES (N'CO93      ', N'Tony      ', N'Shaw      ', N'12 Park P, Glasgow G4 0QR', N'0141-225-7025       ');

------------------------------------------------------------------------------------------------------

INSERT [Dream_Home].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PA14      ', N'16 Holhead', N'Aberdeen  ', N'AB7 5SU   ', N'House     ', 6, 650, N'CO46      ', N'SA9       ', N'B007      ');
INSERT [Dream_Home].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PL94      ', N'6 Argyll St', N'London    ', N'NW2       ', N'Flat      ', 4, 400, N'CO87      ', N'SL41      ', N'B005      ');
INSERT [Dream_Home].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG4       ', N'6 Lawrence St', N'Glasgow   ', N'G11 9QX   ', N'Flat      ', 3, 350, N'CO40      ', NULL, N'B003      ');
INSERT [Dream_Home].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG36      ', N'2 Manor Rd', N'Glasgow   ', N'G32 4QX   ', N'Flat      ', 3, 375, N'CO93      ', N'SG37      ', N'B003      ');
INSERT [Dream_Home].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG21      ', N'18 Dale Rd', N'Glasgow   ', N'G12       ', N'House     ', 5, 600, N'CO87      ', N'SG37      ', N'B003      ');
INSERT [Dream_Home].[PropertyForRent] ([propertyNo], [street], [city], [postcode], [PROPERTYtype], [rooms], [rent], [ownerNo], [staffNo], [branchNo]) VALUES (N'PG16      ', N'5 Novar Dr', N'Glasgow   ', N'G12 0Ax   ', N'Flat      ', 4, 450, N'CO93      ', N'SG14      ', N'B003      ');

-------------------------------------------------------------------------------------------------------

INSERT [Dream_Home].[Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SA9       ', N'MAry      ', N'Howe      ', N'Assistant ', N'F', CAST(N'1970-02-10' AS Date), 9000, N'B007      ');
INSERT [Dream_Home].[Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SG14      ', N'David     ', N'Ford      ', N'Supervisor', N'M', CAST(N'1958-03-24' AS Date), 18000, N'B003      ');
INSERT [Dream_Home].[Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SG37      ', N'Ann       ', N'Beech     ', N'Assistant ', N'F', CAST(N'1960-11-10' AS Date), 12000, N'B003      ');
INSERT [Dream_Home].[Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SG5       ', N'Susan     ', N'Brand     ', N'Manager   ', N'F', CAST(N'1940-06-03' AS Date), 24000, N'B003      ');
INSERT [Dream_Home].[Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SL21      ', N'John      ', N'White     ', N'Manager   ', N'M', CAST(N'1945-10-01' AS Date), 30000, N'B005      ');
INSERT [Dream_Home].[Staff] ([staffNo], [fName], [lName], [Oposition], [sex], [DOB], [salary], [branchNo]) VALUES (N'SL41      ', N'Julie     ', N'Lee       ', N'Assistant ', N'F', CAST(N'1965-06-13' AS Date), 9000, N'B005      ');

---------------------------------------------------------------------------------------------------------

INSERT [Dream_Home].[Viewing] ([clientNo], [propertyNo], [viewDate], [comments]) VALUES (N'CR56      ', N'PA14      ', CAST(N'2004-05-24' AS Date), N'too small');
INSERT [Dream_Home].[Viewing] ([clientNo], [propertyNo], [viewDate], [commentS]) VALUES (N'CR76      ', N'PG4       ', CAST(N'2004-04-20' AS Date), N'too remote');
INSERT [Dream_Home].[Viewing] ([clientNo], [propertyNo], [viewDate], [commentS]) VALUES (N'CR56      ', N'PG4       ', CAST(N'2004-05-26' AS Date), N'');
INSERT [Dream_Home].[Viewing] ([clientNo], [propertyNo], [viewDate], [commentS]) VALUES (N'CR62      ', N'PA14      ', CAST(N'2004-05-14' AS Date), N'no dining room');
INSERT [Dream_Home].[Viewing] ([clientNo], [propertyNo], [viewDate], [commentS]) VALUES (N'CR56      ', N'PG36      ', CAST(N'2004-04-28' AS Date), NULL);

--------------------------------------------------------------------------------------------------
INSERT INTO Dream_Home.Registration VALUES ('CR76', 'B005', 'SL41', '2001-01-02');
INSERT INTO Dream_Home.Registration VALUES ('CR56', 'B003', 'SG37', '2000-04-11');
INSERT INTO Dream_Home.Registration VALUES ('CR74', 'B003', 'SG37', '1999-11-16');
INSERT INTO Dream_Home.Registration VALUES ('CR62', 'B007', 'SA9',  '2000-03-07');


----------------------------------------
select * from Dream_Home.registration;
------task--------------
use case_study;
--1. List full details of all staff
select * from Dream_Home.staff;
--2. Produce a list of salaries for all staff, showing only the staff number, the first and last names, and the salary details.
select staffNo,fName,lName,salary from Dream_Home.staff;
--3. List the property numbers of all properties that have been viewed.
select p.propertyNo from Dream_Home.propertyforrent p 
join Dream_Home.viewing v on p.propertyNo= v.propertyNo ;
--4. Produce a list of yearly salaries for all staff, showing the staff number, the first and lastnames, and the salary details.
select staffNo,fName,lName,salary from Dream_Home.staff;
--5. List all staff with a salary greater than 10,000.
select * from Dream_Home.staff where salary>10000;
--6. List the addresses of all branch offices in London or Glasgow.
select branchNo,street,postcode,city from Dream_Home.branch where city in('london','glasgow');
--7. List all staff with a salary between �20,000 and �30,000.
select * from Dream_Home.staff where salary between 20000 and 30000;
--8. List all managers and supervisors.
select * from Dream_Home.staff where oPosition in('manager','supervisor');
--9.  Find all owners with the string �Glasgow� in their address
select * from Dream_Home.privateowner where address like '%Glasgow%';
