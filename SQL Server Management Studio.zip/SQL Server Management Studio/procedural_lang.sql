--------------------procedural language--------
declare @name varchar(20);
set @name='jini';
--select @name;
print 'name is '+@name;

declare @age int;
set @age=25;
--print @age;
---use cast function--
print 'age is '+cast(@age as varchar(10));

--storing from table to variable name-----
begin
declare @pname varchar(20);
select @pname=prod_name from product where prod_id=1;
print 'product name is'+@pname;
end

--disp product name and price of the product for the pid 3
begin
declare @pname varchar(20);
declare @price numeric(5,2);
select @pname=prod_name,@price=price from product where prod_id=3;
print('name is '+@pname);
--print('name is '+@pname+'price is'+cast(@price as varchar(10));
print('product price is' +cast(@price as varchar(20)));
end

--disp price of cake and category of the cake if price>500 high and if not low--
begin
declare @price numeric(5,2);
select @price=price from product where prod_name='cake';
if (@price>500)
begin
print('product price is' +cast(@price as varchar(20))+'and the category  is highcost');
end
else
begin
print('product price is' +cast(@price as varchar(20))+'and the category  is lowcost');
end
end

------------STORED PROCEDURE--------------------------
---create procedure-------
create procedure prc1 as 
select * from product;

---alter-----
alter procedure prc1 as 
select prod_id,prod_name,price from product;

--------execute------------
execute prc1;
or exec prc1;
or prc1;

--create stored procedure that should displaay all emp who are clerk
create procedure prc2 as
select * from emptable where designation='hr';

alter procedure prc2 as
select * from emptable where designation='pt'

exec prc2;

--static and dynamic are the types of stored procedure--

--dynamic type--
--adding parameter to procedure---
create procedure prc3 @job varchar(20) as
select * from emptable where designation=@job;

exec prc3 'hr';

--create store procedure displa all products greater than given qty..
alter procedure prc4 @quan int as
select * from customer where qty>@quan;

exec prc4 3;
exec prc4 2;
--strp to disp all emp who are getting highest salary in the given city ..city supp at run time
create procedure prc5 @city varchar(20) as
select * from emptable where sal=(select max(sal) from emptable where city=@city);
exec prc5 'chennai';
 

 --to disp supp id suppliername,prod id,prod_name which are supplied by supplier--
 create procedure prc6 as
 select supp_id,Supp_name,product.prod_id,prod_name from supplier join product on product.prod_id=supplier.prod_id;
 exec prc6;

 --to disp accept prod_id runtime and disp the pname,price..if the price is greater than 500 sho highcost-----
alter procedure prc8 @id int as
declare @price numeric(5,2),@name varchar(20);
select @name=prod_name,@price=price from product where prod_id=@id
if (@id not in (select prod_id from product))
begin
print('invalid');
end 
else
 begin
 if(@price>500)
 begin
 print('high'+cast(@price as varchar(20)));
 end
 else
 begin
 print('low'+cast(@price as varchar(20)));
 end
 end

 exec prc8 10;
 
 --that allow user to store supplier details while accepting table value in run time---
 create procedure prc9  @sdetail varchar(20),@proid int,@location varchar(20) as
 insert into supplier values(@sdetail,@proid,@location);
 exec prc9 'jinish',7,'chn';
 select @@identity

 --out------
 create procedure pr1 @num1 int,@num2 int,@tot int output as
 set @tot=@num1+@num2;

declare @result int;
exec pr1 5,3,@result output;
print @result;

select @@servername
--disp prod_id prod_name price number of customers purchased the product 
select product.prod_id,prod_name,price,count(cust_id) from product join customer on customer.prod_id=product.prod_id
 group by customer.prod_id,product.prod_id,product.prod_name,product.price;
select count(cust_id) from customer group by prod_id;

select * from customer;
select * from product;