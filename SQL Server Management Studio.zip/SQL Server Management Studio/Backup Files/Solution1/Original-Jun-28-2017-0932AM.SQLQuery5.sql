select * from product;
select * from supplier;
select * from customer;
select * from emptable

create database task
