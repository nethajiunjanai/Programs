--1. Find the minimum, maximum, and average staff salary.
--2. How many properties cost more than 350 per month to rent?
--3. How many different properties were viewed in May 2004?
--4. Find the total number of Managers and the sum of their salaries.
--5. Find the number of staff working in each branch and the sum of their salaries.
--6. For each branch office with more than one member of staff, find the number of staff working in each branch and the sum of their salaries.

---1--
select max(salary) max,min(salary) min,avg(salary) avg from Dream_Home.staff;
--2--
select count(propertyNo) prop from Dream_Home.propertyforrent where rent>350;
--3--
select count(propertyno) from Dream_home.viewing where month(viewdate)='5'
--4--
select count(oPosition),sum(salary) from Dream_Home.staff where oPosition='manager';
--5--
select count(staffNo),sum(salary),s.branchno from Dream_Home.staff s join Dream_Home.branch b on
 s.branchno=b.branchno group by s.branchno;
--6--
select count(staffNo),sum(salary),s.branchno from Dream_Home.staff s join Dream_Home.branch b on
 s.branchno=b.branchno group by s.branchno having count(staffNo)>1;
