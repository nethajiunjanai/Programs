--1. List the names of all clients who have viewed a property along with any comment supplied.
select fname+lname as [Client Name],comments 
from Dream_Home.CLIENT c join Dream_Home.viewing v
on c.clientNo=v.clientNo where v.comments is not null and v.comments like '_%';

--2. For each branch office, list the numbers and names of staff who manage properties and the properties that they manage.
select s.branchNo,s.staffNo,fname+lName as[Name],propertyno
from Dream_Home.staff s join Dream_Home.propertyforrent p
on s.staffNo=p.staffNo;


--3. For each branch, list the numbers and names of staff who manage properties,
--   including the city in which the branch is located and the properties that the staff manage.
   select s.staffNo,fname+lName as[Name],b.city,p.propertyno
   from  Dream_Home.staff s join Dream_Home.propertyforrent p 
   on s.staffNo=p.staffNo join Dream_Home.branch b on b.branchNo=s.branchNo ;
--4. Find the number of properties handled by each staff member.
select s.staffno,COUNT(p.staffno)
 from Dream_Home.staff s left outer join Dream_Home.propertyforrent p
 on s.staffno=p.staffno
 group by s.staffno;  
--5. List all branch offices and any properties that are in the same city.
 select b.branchno,p.propertyno,b.city 
 from Dream_Home.branch b join Dream_Home.propertyforrent p
 on b.branchNo=p.branchNo;
 --6. List all properties and any branch offices that are in the same city.
 select p.propertyno,b.branchno,b.city 
 from Dream_Home.branch b join Dream_Home.propertyforrent p
 on b.branchNo=p.branchNo; 
