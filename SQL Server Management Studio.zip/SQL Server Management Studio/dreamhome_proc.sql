1. Create a stored procedure named sp_disp_staff to display staffno, fname, DOB, salary for all the staff.
2. Create a stored procedure named sp_disp_client_property to list the client fname, telephone no, maxrent, property type, street, room and rent details for the corresponding property
3. Create a stored procedure name sp_disp_staff_position where the procedure should display the fname and salary 
for all the staff whose position value substitute at runtime. 
4. Create a stored procedure that should display owner fname, address and telephoneno, property type, rent for all the ownerno which is supplied at runtime

--1
create procedure sp_disp_staff as
select staffno,fname,DOB,salary from Dream_home.staff;
exec sp_disp_staff;
--2
create procedure sp_disp_client_property as 
select fname, telno,maxrent,propertytype,street, rooms,rent from Dream_Home.CLIENT c join
Dream_Home.propertyforrent p on p.propertyType=c.prefType where c.maxrent>=p.rent;
exec sp_disp_client_property; 

--3
create procedure sp_disp_staff_position @dstaff varchar(30) as
select fname,salary from Dream_Home.staff where oPosition=@dstaff;
exec sp_disp_staff_position manager;

--4
create procedure p1 @no varchar(20) as
select fname,address,telno,propertytype,rent from Dream_Home.privateowner  a join
Dream_Home.propertyforrent  b  on a.ownerNo=b.ownerNo where a.ownerNo=@no;
exec p1 CO40;
5. Create a stored procedure that should accept property type as parameter and it should display how many properties available
 in the given type.
The output should display like
The Total number of Flat [Flat is a property type] available is 6.

If the given property not exist then it should display like
No such property type exist.

create procedure p2 @ptype varchar(30) as 
declare @c int;
select @c=count(propertyType) from Dream_Home.propertyforrent group by propertyType having propertyType=@ptype
--if(@ptype not in(select distinct propertyType from Dream_Home.propertyforrent))
if(@c>=1)
begin
print('total number of '+@ptype +'available is'+cast(@c as varchar(20)));
end
else
begin
print('no such propety exists');
end
exec p2 'housee';


6. Create a stored procedure that should accept branch no as parameter and display the city details in the form of output parameter.
The output should like below format:
The City is London

create procedure p3 @branc varchar(20) as
declare @c varchar(20);
select @c=city from Dream_Home.branch where branchNo=@branc;
print('the city is '+@c);

exec p3 'B003';

7. Create a stored procedure that will calculate the average of given two numbers at run time. You have to accept two input parameters and one output parameter for display the average as output. This procedure will pass these two input information to another procedure which will calculate the total and pass the total as output parameter.
Procedure 1: val1, val2, average output
Procedure 2: val1, val2, total output
The output should be like below 

alter procedure p4 @n1 int,@n2 int,@tot int output as
set @tot=@n1+@n2;

declare @tot1 int;
exec p4 1,2,@tot1 output;
print(@tot1);

create procedure p6 @n1 int,@n2 int,@avg int output as
set @avg=avg(@n1+@n2)/2;

declare @a int;
exec p6 2,1,@a output;
print(@a);