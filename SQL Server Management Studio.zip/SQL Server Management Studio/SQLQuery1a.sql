select * from Dream_Home.branch
select * from Dream_Home.CLIENT


select * from Dream_Home.registration
select * from Dream_Home.staff
select * from Dream_Home.privateowner
select * from Dream_Home.propertyforrent;
select * from Dream_Home.CLIENT;
select * from Dream_Home.viewing