create table flights(
	flno numeric(4,0) primary key,
	origin varchar(20),
	destination varchar(20),
	distance numeric(6,0),
	departs date,
	arrives date,
	price numeric(7,2)
	);

create table aircraft(
	aid numeric(9,0) primary key,
	aname varchar(30),
	crusingrange numeric(6,0)
	);

create table pilots(
	eid numeric(9,0) primary key,
	ename varchar(30),
	salary numeric(10,2)
	);

create table certified(
	eid numeric(9,0),
	aid numeric(9,0),
	primary key(eid,aid),
	foreign key(eid) references pilots,
	foreign key(aid) references aircraft
	);

insert into flights
values

(99,'Los Angeles','Washington D.C.',2308,'2005/04/12 09:30','2005/04/12 21:40',235.98),
(13,'Los Angeles','Chicago',1749,'2005/04/12 08:45','2005/04/12 20:45',220.98),
(346,'Los Angeles','Dallas',1251,'2005/04/12 11:50','2005/04/12 19:05',225.43),
(387,'Los Angeles','Boston',2606,'2005/04/12 07:03','2005/04/12 17:03',261.56),
(7,'Los Angeles','Sydney',7487,'2005/04/12 22:30','2005/04/14 6:10',1278.56),
(2,'Los Angeles','Tokyo',5478,'2005/04/12 12:30','2005/04/13 15:55',780.99),
(33,'Los Angeles','Honolulu',2551,'2005/04/12 09:15','2005/04/12 11:15',375.23),
(34,'Los Angeles','Honolulu',2551,'2005/04/12 12:45','2005/04/12 15:18',425.98),
(76,'Chicago','Los Angeles',1749,'2005/04/12 08:32','2005/04/12 10:03',220.98),
(68,'Chicago','New York',802,'2005/04/12 09:00','2005/04/12 12:02',202.45),
(7789,'Madison','Detroit',319,'2005/04/12 06:15','2005/04/12 08:19',120.33),
(701,'Detroit','New York',470,'2005/04/12 08:55','2005/04/12 10:26',180.56),
(702,'Madison','New York',789,'2005/04/12 07:05','2005/04/12 10:12',202.34),
(4884,'Madison','Chicago',84,'2005/04/12 22:12','2005/04/12 23:02',112.45),
(2223,'Madison','Pittsburgh',517,'2005/04/12 08:02','2005/04/12 10:01',189.98),
(5694,'Madison','Minneapolis',247,'2005/04/12 08:32','2005/04/12 09:33',120.11),
(304,'Minneapolis','New York',991,'2005/04/12 10:00','2005/04/12 1:39',101.56),
(149,'Pittsburgh','New York',303,'2005/04/12 09:42','2005/04/12 12:09',116.50)

;
drop table pilots;
drop table certified;
 insert into pilots 
 values
 (242518965,'James Smith',120433),
(141582651,'Mary Johnson',178345),
(11564812,'John Williams',153972),
(567354612,'Lisa Walker',256481),
(552455318,'Larry West',101745),
(550156548,'Karen Scott',205187),
(390487451,'Lawrence Sperry',212156),
(274878974,'Michael Miller',99890),
(254099823,'Patricia Jones',24450),
(356187925,'Robert Brown',44740),
(355548984,'Angela Martinez',212156), 
(310454876,'Joseph Thompson',212156),
(489456522,'Linda Davis',127984),
(489221823,'Richard Jackson',23980),
(548977562,'William Ward',84476),
(310454877,'Chad Stewart',33546),
(142519864,'Betty Adams',227489),
(269734834,'George Wright',289950),
(287321212,'Michael Miller',48090),
(552455348,'Dorthy Lewis',92013),
(248965255,'Barbara Wilson',43723),
(159542516,'William Moore',48250),
(348121549,'Haywood Kelly',32899),
(090873519,'Elizabeth Taylor',32021),
(486512566,'David Anderson',743001),
(619023588,'Jennifer Thomas',54921),
(015645489,'Donald King',18050),
(556784565,'Mark Young',205187),
(573284895,'Eric Cooper',114323),
(574489456,'William Jones',105743),
(574489457,'Milo Brooks',20);



INSERT INTO aircraft VALUES (1,'Boeing 747-400',8430);
INSERT INTO aircraft VALUES (2,'Boeing 737-800',3383);
INSERT INTO aircraft VALUES (3,'Airbus A340-300',7120);
INSERT INTO aircraft VALUES (4,'British Aerospace Jetstream 41',1502);
INSERT INTO aircraft VALUES (5,'Embraer ERJ-145',1530);
INSERT INTO aircraft VALUES (6,'SAAB 340',2128);
INSERT INTO aircraft VALUES (7,'Piper Archer III',520);
INSERT INTO aircraft VALUES (8,'Tupolev 154',4103);
INSERT INTO aircraft VALUES (16,'Schwitzer 2-33',30);
INSERT INTO aircraft VALUES (9,'Lockheed L1011',6900);
INSERT INTO aircraft VALUES (10,'Boeing 757-300',4010);
INSERT INTO aircraft VALUES (11,'Boeing 777-300',6441);
INSERT INTO aircraft VALUES (12,'Boeing 767-400ER',6475);
INSERT INTO aircraft VALUES (13,'Airbus A320',2605);
INSERT INTO aircraft VALUES (14,'Airbus A319',1805);
INSERT INTO aircraft VALUES (15,'Boeing 727',1504);





INSERT INTO certified VALUES (567354612,1);
INSERT INTO certified VALUES (567354612,2);
INSERT INTO certified VALUES (567354612,10);
INSERT INTO certified VALUES (567354612,11);
INSERT INTO certified VALUES (567354612,12);
INSERT INTO certified VALUES (567354612,15);
INSERT INTO certified VALUES (567354612,7);
INSERT INTO certified VALUES (567354612,9);
INSERT INTO certified VALUES (567354612,3);
INSERT INTO certified VALUES (567354612,4);
INSERT INTO certified VALUES (567354612,5);
INSERT INTO certified VALUES (552455318,2);
INSERT INTO certified VALUES (552455318,14);
INSERT INTO certified VALUES (550156548,1);
INSERT INTO certified VALUES (550156548,12);
INSERT INTO certified VALUES (390487451,3);
INSERT INTO certified VALUES (390487451,13);
INSERT INTO certified VALUES (390487451,14);
INSERT INTO certified VALUES (274878974,10);
INSERT INTO certified VALUES (274878974,12);
INSERT INTO certified VALUES (355548984,8);
INSERT INTO certified VALUES (355548984,9);
INSERT INTO certified VALUES (310454876,8);
INSERT INTO certified VALUES (310454876,9);
INSERT INTO certified VALUES (548977562,7);
INSERT INTO certified VALUES (142519864,1);
INSERT INTO certified VALUES (142519864,11);
INSERT INTO certified VALUES (142519864,12);
INSERT INTO certified VALUES (142519864,10);
INSERT INTO certified VALUES (142519864,3);
INSERT INTO certified VALUES (142519864,2);
INSERT INTO certified VALUES (142519864,13);
INSERT INTO certified VALUES (142519864,7);
INSERT INTO certified VALUES (269734834,1);
INSERT INTO certified VALUES (269734834,2);
INSERT INTO certified VALUES (269734834,3);
INSERT INTO certified VALUES (269734834,4);
INSERT INTO certified VALUES (269734834,5);
INSERT INTO certified VALUES (269734834,6);
INSERT INTO certified VALUES (269734834,7);
INSERT INTO certified VALUES (269734834,8);
INSERT INTO certified VALUES (269734834,9);
INSERT INTO certified VALUES (269734834,10);
INSERT INTO certified VALUES (269734834,11);
INSERT INTO certified VALUES (269734834,12);
INSERT INTO certified VALUES (269734834,13);
INSERT INTO certified VALUES (269734834,14);
INSERT INTO certified VALUES (269734834,15);
INSERT INTO certified VALUES (552455318,7);
INSERT INTO certified VALUES (556784565,5);
INSERT INTO certified VALUES (556784565,2);
INSERT INTO certified VALUES (556784565,3);
INSERT INTO certified VALUES (573284895,3);
INSERT INTO certified VALUES (573284895,4);
INSERT INTO certified VALUES (573284895,5);
INSERT INTO certified VALUES (574489456,8);
INSERT INTO certified VALUES (574489456,6);
INSERT INTO certified VALUES (574489457,7);
INSERT INTO certified VALUES (242518965,2);
INSERT INTO certified VALUES (242518965,10);
INSERT INTO certified VALUES (141582651,2);
INSERT INTO certified VALUES (141582651,10);
INSERT INTO certified VALUES (141582651,12);
INSERT INTO certified VALUES (011564812,2);
INSERT INTO certified VALUES (011564812,10);
INSERT INTO certified VALUES (356187925,6);
INSERT INTO certified VALUES (159542516,5);
INSERT INTO certified VALUES (159542516,7);
INSERT INTO certified VALUES (090873519,6);


select * from aircraft;
select * from flights;
select * from pilots;
select * from certified;


