﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AcronymFinder.Models;

namespace AcronymFinder.Controllers
{
   
    public class DatabaseManipulationController : Controller
    {
        //
        // GET: /DatabaseManipulation/
        public AcronymFinderLibrary libraryobject = new AcronymFinderLibrary();
        public AcronymDBManipulationRepository acronymData = new AcronymDBManipulationRepository();
        /// <summary>
        /// For deleting Acronym from database
        /// </summary>
        /// <param name="acronymID"></param>
        /// <returns></returns>
        public ActionResult DeleteAcronymInDataBase(string acronymID)
        {
            bool checkDelete=false;
            int  convertedAcronymID = int.Parse(acronymID);
            checkDelete= libraryobject.deleteAcronym(convertedAcronymID);
            return Json(checkDelete);
        }

        /// <summary>
        /// To Edit the existing acronym in database
        /// </summary>
        /// <param name="acronymID"></param>
        /// <param name="categoryCode"></param>
        /// <param name="acronym"></param>
        /// <param name="acronymDefiniton"></param>
        /// <param name="comments"></param>
        /// <returns></returns>
        public ActionResult EditAcronymInDataBase(string acronymID,List<string> categoryCode,string acronym,string acronymDefiniton,string comments )
        {         
           acronymData=new AcronymDBManipulationRepository(){acronymID=int.Parse(acronymID),acronym=acronym,acronymDefinition=acronymDefiniton,
           categoryName=categoryCode,comments=comments};
           libraryobject.editAcronym(acronymData);           
           return Json("");
        }

        /// <summary>
        /// To create a new acronym in database
        /// </summary>
        /// <param name="acronymID"></param>
        /// <param name="categoryCode"></param>
        /// <param name="acronym"></param>
        /// <param name="acronymDefiniton"></param>
        /// <param name="comments"></param>
        /// <returns></returns>

        public ActionResult CreateAcronymInDataBase(string acronymID,List<string> categoryCode, string acronym, string acronymDefiniton, string comments)
        {       
            bool checkOldAcronym = libraryobject.CheckOldAcronym(acronymDefiniton);
            if (checkOldAcronym == false)
            {

                acronymData = new AcronymDBManipulationRepository()
                {
                    acronymID = int.Parse(acronymID),
                    acronym = acronym, 
                    acronymDefinition = acronymDefiniton,
                    categoryName = categoryCode,
                    comments = comments
                  
                };
                libraryobject.addAcronym(acronymData);
                return Json(true);
            }
            else
            {
                return Json(false);
            }
            
        }


        /// <summary>
        /// To add a new category in database
        /// </summary>
        /// <param name="categoryCode"></param>
        /// <param name="categoryName"></param>
        /// <returns></returns>
        public JsonResult AddCategory(string categoryCode,string categoryName)
        {
            AddCategoryRepository categoryData = new AddCategoryRepository() { categoryCode=categoryCode,categoryName=categoryName};
            libraryobject.addCategory(categoryData);
            return Json("");
        }

       
    }
}
