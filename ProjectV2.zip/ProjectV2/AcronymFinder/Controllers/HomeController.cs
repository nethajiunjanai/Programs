﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AcronymFinder.Models;
using System.Web.Optimization;

namespace AcronymFinder.Controllers
{

    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public AcronymFinderLibrary libraryobject = new AcronymFinderLibrary();

        /// <summary>
        /// Index will load the Homepage of the application
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// For Autosuggesting the list of acronym based on key
        /// </summary>
        /// <param name="acronym"></param>
        /// <returns></returns>
        public JsonResult AutoCompleteAcronym(string acronym)
        {
            List<string> acronymsList = libraryobject.AutoSuggestForAcronyms(acronym);
            return Json(acronymsList);
        }


        /// <summary>
        /// For Autosuggesting the list of category based on key
        /// </summary>
        /// <param name="categoryCode"></param>
        /// <returns></returns>
        public JsonResult AutoCompleteCategory(string categoryCode)
        {
            //autocomplete for AddCategoryRepository search text box
            List<string> categoryList = libraryobject.AutoSuggestForCategories(categoryCode);
            int countCategory = categoryList.Count();
            if (countCategory >= 1)
            {

                return Json(categoryList);
            }
            else
            {
                ViewBag.categoryList = "Category not found";

                return Json(categoryList);
            }


        }

        /// <summary>
        /// To display the results of acronyms
        /// </summary>
        /// <param name="acronym"></param>
        /// <param name="categoryFilter"></param>
        /// <param name="dateFilter"></param>
        /// <param name="pageNumber"></param>
        /// <returns></returns>
        public ActionResult SearchResult(string acronym, string categoryFilter, int dateFilter, int pageNumber)
        {

            string procedure = null;
            List<AcronymDisplayRepository> acronymRepositoryList = new List<AcronymDisplayRepository>();
            acronymRepositoryList = libraryobject.searchAcronym(procedure, acronym, dateFilter, categoryFilter, pageNumber);
            ViewBag.numberOfResult = libraryobject.resultCount;
            ViewBag.acronymName = acronym;
            ViewBag.categoryName = categoryFilter;
          
            return PartialView("SearchResult", acronymRepositoryList);
        }

        /// <summary>
        /// For Editing existing Acronym
        /// </summary>
        /// <param name="acronymID"></param>
        /// <returns></returns>

        public ActionResult EditAcronymButtonClick(int acronymID)
        {
            AcronymDBManipulationRepository manipulatingDBObject = libraryobject.SearchOnAcronymID(acronymID);
            return PartialView("EditAcronymForm", manipulatingDBObject);
        }

        /// <summary>
        /// Add a new acronym 
        /// </summary>
        /// <param name="acronymID"></param>
        /// <returns></returns>
        public ActionResult AddAcronymButtonClick(string acronymID)
        {
            return PartialView("CreateAcronymForm");
        }

        /// <summary>
        /// For pagination based on number of results
        /// </summary>
        /// <param name="acronym"></param>
        /// <param name="categoryFilter"></param>
        /// <param name="dateFilter"></param>
        /// <param name="pageNumber"></param>
        /// <returns></returns>
        public ActionResult Paginationclick(string acronym, string categoryFilter, int dateFilter, int pageNumber)
        {
            string procedure = null;
            List<AcronymDisplayRepository> acronymRepositoryList = new List<AcronymDisplayRepository>();
            acronymRepositoryList = libraryobject.searchAcronym(procedure, acronym, dateFilter, categoryFilter, pageNumber);
            ViewBag.numberOfResult = libraryobject.resultCount;
            return PartialView("PaginationResult", acronymRepositoryList);
        }


        public ActionResult CheckAcronymDefinition(string acronymDefinition) 
        {
            return Json(libraryobject.CheckOldAcronym(acronymDefinition));
        }

        public ActionResult MoreInfoClick(int acronymID)
        {
            //AcronymInformationRepository acronymDetails = new AcronymInformationRepository() { acronymID = 1, acronymDefinition = "", acronym = "", categoryName = new List<string> {"IN"}, comments = "", createdDate = "", modifiedDate = "" };
            return PartialView("MoreInfoPage",libraryobject.SearchOnAcronymIDForInfo(acronymID));
        }

    }
}
