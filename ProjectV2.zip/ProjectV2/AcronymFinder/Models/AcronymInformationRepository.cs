﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AcronymFinder.Models
{
    public class AcronymInformationRepository
    {
        public int acronymID { get; set; }
        public string acronym { get; set; }
        public string acronymDefinition { get; set; }
        public string comments { get; set; }
        public string createdDate { get; set; }
        public string modifiedDate { get; set; }
        public List<string> categoryName { get; set; }
    }
}