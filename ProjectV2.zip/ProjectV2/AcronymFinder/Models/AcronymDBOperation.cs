﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using AcronymFinder.Models;
using System.Collections;
using System.Configuration;

namespace AcronymFinder.Models
{
    public class AcronymFinderLibrary
    {
        SqlConnection connectionobject;
        SqlCommand commandobject;
        string connectionstring;
        DataTable dataTableObject = new DataTable();
        DataSet datasetObject = new DataSet();
        DataTable secondDataTableObject = new DataTable();
        public int resultCount;
        public List<AcronymDisplayRepository> acronymDetails = new List<AcronymDisplayRepository>();

        /// <summary>
        /// To establish a connection with database
        /// </summary>
        public AcronymFinderLibrary()
        {
            connectionstring = ConfigurationManager.ConnectionStrings["AcronymDBConnection"].ConnectionString;
            connectionobject = new SqlConnection(connectionstring);

            commandobject = connectionobject.CreateCommand();
            commandobject.CommandType = CommandType.StoredProcedure;
        }

        /// <summary>
        /// Searching acronym using acronymId
        /// </summary>
        /// <param name="acronymId"></param>
        /// <returns></returns>
        public AcronymInformationRepository SearchOnAcronymIDForInfo(int acronymId)
        {
            commandobject.CommandText = "SearchOnAcroID";
            List<string> categories = new List<string>();



            AcronymInformationRepository acronymData = new AcronymInformationRepository();
            SqlParameter[] parameter = new SqlParameter[]{
            new SqlParameter("@acronymID",acronymId)
           
            };

            foreach (SqlParameter param in parameter)
            {
                commandobject.Parameters.Add(param);
            }
            SqlDataAdapter adapterobject = new SqlDataAdapter(commandobject);
            DataTable data = new DataTable();

            adapterobject.Fill(data);


            categories = (from DataRow category in data.AsEnumerable() where (int)category[0] == acronymId select (string)(category[4])).ToList();
            acronymData = (from DataRow acronymDetail in data.AsEnumerable()
                           where (int)(acronymDetail[0]) == acronymId
                           select (new AcronymInformationRepository()
                           {
                               acronymID = acronymId,
                               acronym = (acronymDetail[1].ToString()),
                               acronymDefinition = (acronymDetail[2].ToString()),
                               comments=(acronymDetail[3].ToString()),
                               createdDate=(acronymDetail[5].ToString()),
                               modifiedDate=acronymDetail[6].ToString(),
                               categoryName = categories
                           })).FirstOrDefault();


            return acronymData;
        }

        public AcronymDBManipulationRepository SearchOnAcronymID(int acronymId)
        {
            commandobject.CommandText = "SearchOnAcroID";
            List<string> categories = new List<string>();



            AcronymDBManipulationRepository acronymData = new AcronymDBManipulationRepository();
            SqlParameter[] parameter = new SqlParameter[]{
            new SqlParameter("@acronymID",acronymId)
           
            };

            foreach (SqlParameter param in parameter)
            {
                commandobject.Parameters.Add(param);
            }
            SqlDataAdapter adapterobject = new SqlDataAdapter(commandobject);
            DataTable data = new DataTable();

            adapterobject.Fill(data);


            categories = (from DataRow category in data.AsEnumerable() where (int)category[0] == acronymId select (string)(category[4])).ToList();
            acronymData = (from DataRow acronymDetail in data.AsEnumerable()
                           where (int)(acronymDetail[0]) == acronymId
                           select (new AcronymDBManipulationRepository()
                           {
                               acronymID = acronymId,
                               acronym = (acronymDetail[1].ToString()),
                               acronymDefinition = (acronymDetail[2].ToString()),
                               comments = (acronymDetail[3].ToString()),
                               categoryName = categories
                           })).FirstOrDefault();


            return acronymData;
        }


        /// <summary>
        /// Searching acronym and display its results
        /// </summary>
        /// <param name="procedure"></param>
        /// <param name="acronym"></param>
        /// <param name="numberOfdays"></param>
        /// <param name="categoryCode"></param>
        /// <param name="pageNumber"></param>
        /// <returns></returns>
        public List<AcronymDisplayRepository> searchAcronym(string procedure, string acronym, int numberOfdays, string categoryCode, int pageNumber)
        {
            procedure = "SearchAndCount";
            if (categoryCode == "")
            {
                categoryCode = null;
            }
            List<int> acronymId = new List<int>();
            AcronymDisplayRepository acronymData;
            List<string> categories = new List<string>();
            SqlCommand acronymCommandObject = connectionobject.CreateCommand();
            acronymCommandObject.CommandType = CommandType.StoredProcedure;
            acronymCommandObject.CommandText = procedure;

            SqlParameter[] acronymParameter = new SqlParameter[]{
                    new SqlParameter("@acronym",acronym),
                    new SqlParameter("@categoryCode",categoryCode),
                    new SqlParameter("@numberOfDays",numberOfdays),
                    new SqlParameter("@pageNumber",pageNumber),
                    new SqlParameter("@resultsCount",SqlDbType.Int){Direction=ParameterDirection.Output}
                    };

            foreach (SqlParameter param in acronymParameter)
            {
                acronymCommandObject.Parameters.Add(param);
            }
            SqlDataAdapter adapterobject = new SqlDataAdapter(acronymCommandObject);
            DataTable data = new DataTable();

            adapterobject.Fill(data);

            // resultCount = int.Parse(acronymParameter[4].Value.ToString());
            resultCount = (int)acronymParameter[4].Value;

            List<int> AcronymDBManipulationRepository = (from DataRow acronymID in data.Rows select (int)(acronymID[0])).ToList();
            acronymId = AcronymDBManipulationRepository.Distinct().ToList();
            acronymData = new AcronymDisplayRepository();

            foreach (int id in acronymId)
            {
                categories = (from DataRow AddCategoryRepository in data.AsEnumerable() where (int)AddCategoryRepository[0] == id select (string)(AddCategoryRepository[3])).ToList();


                acronymData = (from DataRow acronymDetail in data.AsEnumerable()
                               where (int)(acronymDetail[0]) == id
                               select (new AcronymDisplayRepository()
                               {
                                   acronymID = id,
                                   acronym = (acronymDetail[1].ToString()),
                                   acronymDefinition = (acronymDetail[2].ToString()),
                                   categoryName = categories
                               })).FirstOrDefault();
                acronymDetails.Add(acronymData);

            }


            return acronymDetails;
        }


        /// <summary>
        /// Adding a new acronym
        /// </summary>
        /// <param name="acronymData"></param>
        /// <returns></returns>
        public bool addAcronym(AcronymDBManipulationRepository acronymData)
        {

            commandobject = new SqlCommand();
            commandobject.CommandText = "AddAcronym";
            commandobject.Connection = connectionobject;
            commandobject.CommandType = CommandType.StoredProcedure;


            SqlParameter[] parameter = new SqlParameter[]{
            new SqlParameter("@acronym",acronymData.acronym),
            new SqlParameter("@acronymDefinition",acronymData.acronymDefinition),
            new SqlParameter("@comments",acronymData.comments)
            };

            commandobject.Parameters.AddRange
                (parameter);


            connectionobject.Open();
            int checkAddAcronym = commandobject.ExecuteNonQuery();
            connectionobject.Close();



            if (checkAddAcronym >= 1)
            {
                foreach (var categoryCode in acronymData.categoryName)
                {
                    {
                        SqlCommand categorycommandobject = connectionobject.CreateCommand();
                        categorycommandobject.CommandType = CommandType.StoredProcedure;
                        categorycommandobject.CommandText = "AddToMapping";
                        SqlParameter[] codeParameter = new SqlParameter[]{
                          new SqlParameter("@categoryCode", categoryCode),
                        };

                        foreach (SqlParameter param in codeParameter)
                        {
                            categorycommandobject.Parameters.Add(param);
                        }
                        connectionobject.Open();
                        int checkAddMapping = categorycommandobject.ExecuteNonQuery();
                        connectionobject.Close();
                        if (checkAddMapping < 1)
                        {
                            SqlCommand acronymCommandObject = connectionobject.CreateCommand();
                            acronymCommandObject.CommandType = CommandType.StoredProcedure;
                            acronymCommandObject.CommandText = "DeleteInsertedAcronym";
                            acronymCommandObject.Parameters.AddWithValue("@acronymID", acronymData.acronymID);
                            connectionobject.Open();
                            int checkDeleteAcronym = commandobject.ExecuteNonQuery();
                            connectionobject.Close();
                        }

                    }
                }

            }
            else
            {

                
                return false;
            }
            return true;
        }


        /// <summary>
        /// Adding new category
        /// </summary>
        /// <param name="categoryData"></param>
        /// <returns></returns>
        public bool addCategory(AddCategoryRepository categoryData)
        {
            commandobject.CommandText = "AddCategory";

            SqlParameter[] parameter = new SqlParameter[]{
            new SqlParameter("@categoryCode",categoryData.categoryCode),
            new SqlParameter("@categoryName",categoryData.categoryName)
            };

            foreach (SqlParameter param in parameter)
            {
                commandobject.Parameters.Add(param);
            }
            connectionobject.Open();
            int checkAddCategory = commandobject.ExecuteNonQuery();
            connectionobject.Close();
            if (checkAddCategory >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Deleting the acronym
        /// </summary>
        /// <param name="acronymId"></param>
        /// <returns></returns>
        public bool deleteAcronym(int acronymId)
        {
            commandobject.CommandText = "DeleteAcronym";
            commandobject.Parameters.AddWithValue("@acronymId", acronymId);
            connectionobject.Open();
            int checkDeleteAcronym = commandobject.ExecuteNonQuery();
            connectionobject.Close();

            if (checkDeleteAcronym >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Edit the existing acronym
        /// </summary>
        /// <param name="acronymData"></param>
        /// <returns></returns>
        public bool editAcronym(AcronymDBManipulationRepository acronymData)
        {
            commandobject.CommandText = "EditAcronym";

            SqlParameter[] parameter = new SqlParameter[]{
             new SqlParameter("@acronymID", acronymData.acronymID),
            new SqlParameter("@acronym",acronymData.acronym),
            new SqlParameter("@acronymDefinition",acronymData.acronymDefinition),
            new SqlParameter("@comments",acronymData.comments),       

            };

            foreach (SqlParameter param in parameter)
            {
                commandobject.Parameters.Add(param);
            }
            connectionobject.Open();
            int checkEditAcronym = commandobject.ExecuteNonQuery();
            connectionobject.Close();



            if (checkEditAcronym > 0)
            {
                SqlCommand deletecommandobject = connectionobject.CreateCommand();
                deletecommandobject.CommandType = CommandType.StoredProcedure;
                deletecommandobject.CommandText = "DeleteAcronymMapping";
                deletecommandobject.Parameters.AddWithValue("@acronymID", acronymData.acronymID);
                connectionobject.Open();
                int checkDeleteMapping = deletecommandobject.ExecuteNonQuery();
                connectionobject.Close();
                if (checkDeleteMapping > 0)
                {
                    foreach (var categoryCode in acronymData.categoryName)
                    {

                        {
                            SqlCommand categorycommandobject = connectionobject.CreateCommand();
                            categorycommandobject.CommandType = CommandType.StoredProcedure;
                            categorycommandobject.CommandText = "EditAcronymMapping";
                            //categorycommandobject.Parameters.AddWithValue("@categoryCode", s.categoryCode);
                            SqlParameter[] codeParameter = new SqlParameter[]{

                          new SqlParameter("@categoryCode", categoryCode),
                          new SqlParameter("@acronymID", acronymData.acronymID),
                        };

                            foreach (SqlParameter param in codeParameter)
                            {
                                categorycommandobject.Parameters.Add(param);
                            }
                            connectionobject.Open();
                            int checkEditMapping = categorycommandobject.ExecuteNonQuery();
                            connectionobject.Close();
                        }
                    }
                }


            }
            else
            {
                return false;
            }
            return true;
        }

        
        /// <summary>
        /// For autosuggesting the list of acronyms
        /// </summary>
        /// <param name="acronym"></param>
        /// <returns></returns>
        public List<string> AutoSuggestForAcronyms(string acronym)
        {
            commandobject.CommandText = "AcronymAutoSuggest";
            SqlParameter[] parameter = new SqlParameter[]{
            new SqlParameter("@acronym",acronym)      
            };

            foreach (SqlParameter param in parameter)
            {
                commandobject.Parameters.Add(param);
            }
            SqlDataAdapter adapterobject = new SqlDataAdapter(commandobject);
            DataTable data = new DataTable();

            adapterobject.Fill(data);

            List<string> acronymsList = (from DataRow listOfAcronyms in data.Rows select (listOfAcronyms[0].ToString())).ToList();
            return acronymsList;


        }

        /// <summary>
        /// For autosuggesting the list of categories
        /// </summary>
        /// <param name="categoryCode"></param>
        /// <returns></returns>
        public List<string> AutoSuggestForCategories(string categoryCode)
        {
            commandobject.CommandText = "CategoryAutoSuggest";
            SqlParameter[] parameter = new SqlParameter[]{
            new SqlParameter("@categoryCode",categoryCode)      
            };

            foreach (SqlParameter param in parameter)
            {
                commandobject.Parameters.Add(param);
            }
            SqlDataAdapter adapterobject = new SqlDataAdapter(commandobject);
            DataTable data = new DataTable();

            adapterobject.Fill(data);

            List<string> categoryList = (from DataRow listOfCategories in data.Rows select (listOfCategories[0].ToString())).ToList();
            return categoryList;


        }

        /// <summary>
        /// Displaying Number of results found
        /// </summary>
        /// <param name="acronym"></param>
        /// <returns></returns>
        //public int NumberOfResults(string acronym)
        //{
        //    commandobject.CommandText = "NumberOfResults";
        //    SqlParameter[] parameter = new SqlParameter[]{
        //    new SqlParameter("@acronym",acronym)      
        //    };

        //    foreach (SqlParameter param in parameter)
        //    {
        //        commandobject.Parameters.Add(param);
        //    }
        //    connectionobject.Open();
        //    int results = (int)(commandobject.ExecuteScalar());
        //    connectionobject.Close();
        //    return results;
        //}


        /// <summary>
        /// Checking the new acronym and its definition with existing one
        /// </summary>
        /// <param name="acronym"></param>
        /// <returns></returns>
        public bool CheckOldAcronym(string acronymDefinition)
        {
            commandobject.CommandText = "CheckOldAcronym";
            SqlParameter[] parameter = new SqlParameter[]{
            new SqlParameter("@acronym",acronymDefinition)      
            };

            foreach (SqlParameter param in parameter)
            {
                commandobject.Parameters.Add(param);
            }
            connectionobject.Open();
            string results = (string)commandobject.ExecuteScalar();
            connectionobject.Close();
            bool checkResult;
            if (results == null || results == String.Empty)
            {
                checkResult = false;
            }
            else
            {
                checkResult = true;
            }
            return checkResult;
        }


    }
}