﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AcronymFinder.Models
{
    /// <summary>
    /// For adding new category in database
    /// </summary>
    public class AddCategoryRepository
    {
        public string categoryCode { get; set; }
        public string categoryName { get; set; }
    }
}