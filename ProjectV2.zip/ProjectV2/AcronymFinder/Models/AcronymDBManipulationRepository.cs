﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AcronymFinder.Models
{
    /// <summary>
    /// For database manipulation function
    /// </summary>
    public class AcronymDBManipulationRepository
    {

        public int acronymID { get; set; }
        public string acronym { get; set; }
        public string acronymDefinition { get; set; }
        public string comments { get; set; }
        public List<string> categoryName { get; set; }

    }
}