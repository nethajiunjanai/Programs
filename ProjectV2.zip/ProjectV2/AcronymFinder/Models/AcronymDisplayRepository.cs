﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AcronymFinder.Models
{
    /// <summary>
    /// For Displaying values fetched from database
    /// </summary>
    public class AcronymDisplayRepository
    {
        public int acronymID { get; set; }
        public string acronym { get; set; }
        public string acronymDefinition { get; set; }
        public List<string> categoryName { get; set; }
    }
}