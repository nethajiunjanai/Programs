﻿$(document).ready(function () {
    //This script is used to pass parameter values from ui to the controller and to fetch the acronym results
    var acronymSearch = function (acronymEntered, categoryFilterSelected, dateFilterSelected, pageNumberSelected) {

        var sendData = { acronym: acronymEntered.trim(), categoryFilter: categoryFilterSelected.trim(), dateFilter: dateFilterSelected.trim(), pageNumber: pageNumberSelected };
        $.ajax({
            url: "Home/SearchResult",
            type: "POST",
            data: JSON.stringify(sendData),
            contentType: "application/json; charset=utf-8",
            datatype: "html",
            success: function (response) {
                $("#RenderingPage").html(response);
            },
            error: function (xhr, textStatus, thrownError) {
                console.log(textStatus);
            }
        })


    };

    //This script is used to pass value of acronymId to ui to edit the existing acronym
    $(".EditAcronym").click(function (event) {
        event.preventDefault();
        $.ajax({
            url: "Home/EditAcronymButtonClick",
            type: "POST",
            data: "{'acronymID':'" + $(this).data("value") + "'}",
            contentType: "application/json; charset=utf-8",
            datatype: "html",
            success: function (response) {
                $("#AcronymForm").html(response);
                $("#AcronymFormModal").modal("show");
            },
            error: function (xhr, textStatus, thrownError) {
                console.log(textStatus);
            }
        })
    });

    //This script is used to pass value of acronymId to ui to delete the existing acronym
    $(".DeleteAcronym").click(function (event) {
        event.preventDefault();
        $("#deleteAcronymButton").val($(this).data("value"));

        $("#deleteAcronymButton").click(function (event) {


            $.ajax({
                url: "DatabaseManipulation/DeleteAcronymInDataBase",
                type: "POST",
                data: "{'acronymID':'" + $(this).val() + "'}",
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                success: function (response) {
                    if (response == true) {
                        $.toaster({ priority: 'success', title: 'Delete Acronym', message: 'The Acronym is Deleted Successfully' });
                        $("#DeleteModal").modal('hide');

                        setTimeout(function () {
                            acronymSearch($("#AcronymSearchTextBox").val(), $("#CategorySearchTextBox").val(), $("#dateFilterDropDown").val(), 0);
                        }, 500);

                    }
                    else {
                        $.toaster({ priority: 'danger', title: 'Delete Acronym', message: 'Some Error Occured' });
                    }

                },
                error: function (xhr, textStatus, thrownError) {
                    console.log(textStatus);
                    $.toaster({ priority: 'danger', title: 'Delete Acronym', message: 'Some Error Occured' });
                }
            })
        });

    });

    $(".MoreInfo").click(function (event) {
        event.preventDefault();
        $.ajax({
            url: "Home/MoreInfoClick",
            type: "POST",
            data: "{'acronymID':'" + $(this).data("value") + "'}",
            contentType: "application/json; charset=utf-8",
            datatype: "html",
            success: function (response) {
                $("#MoreInfoModal").html(response);
                $("#MoreInfoModal").modal("show");
            },
            error: function (xhr, textStatus, thrownError) {
                console.log(textStatus);
            }
        })
    });

        $('[data-toggle="popover"]').popover();
        $('.popover-dismiss').popover({
            trigger: 'focus'
        });

});