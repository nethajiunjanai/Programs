﻿var selectedCategory = [];
var availableCategory = [];

//This script is for removing already tagged category
var addToTaggedCategoryList = function (addCategory, addElement) {
    selectedCategory.push(addCategory.trim());

    $(addElement).parentsUntil("ul").remove();
    $("#TaggedCategoryList").append('<li class="list-inline-item" ><h4 ><span class="label categoryLabel"><a class="glyphicon glyphicon-remove RemoveSelectedCategory" data-value=' + addCategory + '></a>' + addCategory + '</span></h4></li>');
};
var removeFromTaggedCategoryList = function (removeCategory, removeElement) {

    selectedCategory.splice(selectedCategory.indexOf(removeCategory), 1);
    $(removeElement).parentsUntil("ul").remove();
    $.each(availableCategory, function (index, value) {
        if (value == removeCategory) {
            $("#AvailableCategoryList").append('<li class="list-inline-item" ><h4 ><span class="label categoryLabel"><a class="glyphicon glyphicon-plus AddSelectedCategory" data-value=' + value + '></a>' + value + '</span></h4></li>');
        }
    })
};

//This script is for searching acronym 
$(document).ready(function () {
    var acronymNotExists = false;
    $("#TaggedCategoryList").empty();
    var suggestionResult = [];

    var checkOldAcronym = function (acronymDefinition) {
        
        var sendData = { acronymDefinition: acronymDefinition };
        $.ajax({
            url: "Home/CheckAcronymDefinition",
            type: "POST",
            data: JSON.stringify(sendData),
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            success: function (response) {
                if (response == true) {
                    $("#OldAcronymFullFormValidation").css({ "display": "block" });
                    acronymNotExists = false;
                }
                else {
                    $("#OldAcronymFullFormValidation").css({ "display": "none" });
                    acronymNotExists = true;
                }
            },
            error: function (xhr, textStatus, thrownError) {
                console.log(textStatus);
                $.toaster({ priority: 'danger', title: 'Add Acronym', message: 'Some Error Happened' });
            }
        })
    }

    var acronymSearch = function (acronymEntered, categoryFilterSelected, dateFilterSelected, pageNumberSelected) {
        var sendData = { acronym: acronymEntered.trim(), categoryFilter: categoryFilterSelected.trim(), dateFilter: dateFilterSelected.trim(), pageNumber: pageNumberSelected };
            $.ajax({
                url: "Home/SearchResult",
                type: "POST",
                data: JSON.stringify(sendData),
                contentType: "application/json; charset=utf-8",
                datatype: "html",
                success: function (response) {
                    $("#RenderingPage").html(response);
                },
                error: function (xhr, textStatus, thrownError) {
                    console.log(textStatus);
                }
            })       
    }

    $('.TagDiv').unbind('click');
    $('.TagDiv').unbind('click');

    //This script is for add selected category as label in UI
    $.each(selectedCategory, function (index, value) {
        $("#TaggedCategoryList").append('<li class="list-inline-item" ><h4 ><span class="label categoryLabel"><a class="glyphicon glyphicon-remove RemoveSelectedCategory" data-value=' + value + '></a>' + value + '</span></h4></li>');
    })


    var addCategoryToList = function (itemValue) {

        var enteredValue = itemValue;
        var splitedTextValue = enteredValue.split(/[;,]/g);
        var idx = splitedTextValue.indexOf("");
        var checkValue = 0;
        if (idx > -1) {
            splitedTextValue.splice(idx, 1);
        }

        $.each(splitedTextValue, function (index, value) {
            $.each(selectedCategory, function (selectedCategoryIndex, selectedCategoryValue) {
                if (value.toUpperCase().trim() == selectedCategoryValue.toUpperCase()) {
                    checkValue++;
                }
            });
            if (checkValue == 0) {
                selectedCategory.push(value.trim());
                $("#TaggedCategoryList").append('<li class="list-inline-item" ><h4 ><span class="label categoryLabel"><a class="glyphicon glyphicon-remove RemoveSelectedCategory" data-value=' + value.toUpperCase() + '></a>' + value.toUpperCase() + '</span></h4></li>');
            }
            else {
                $.toaster({ priority: 'danger', title: 'Add Category', message: 'The Entered Category ' + value + ' is already tagged.' });
                checkValue = 0;
            }
        });



        setTimeout(function () { $("#CategorySuggestionTextBox").val(""); }, 250);
    };

    //This script is for auto suggesting list of category 
    $("#CategorySuggestionTextBox").autocomplete({

        source: function (request, response) {
            //var category=request.term;
            $.ajax({
                url: "/Home/AutoCompleteCategory",
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: "{ 'categoryCode':'" + request.term + "'}",
                success: function (data) {
                    suggestionResult = data;

                    if (data.length == 0) {


                    }

                    else {
                        response($.map(data, function (category) {
                            return [{ label: category, value: category }];
                        }));
                    }

                },
                error: function (XHR, textStatus, errorThrown) {
                    console.log(textStatus);
                }
            })
        },
        select: function (event, ui) {


            if (ui.item.value != '') {
                var checkCategory = 0;
                $.each(suggestionResult, function (index, value) {

                    if (value.toUpperCase() == ui.item.value.toUpperCase()) {
                        checkCategory++;
                    }
                });
                if (checkCategory == 0) {
                    $.toaster({ priority: 'danger', title: 'Add Category', message: ui.item.value + ' Category is not in our Database. Please add it using the category add button.' });
                }
                else {
                    addCategoryToList(ui.item.value);
                }

            }

        }
    });

    //This script is for selecting values from the autosuggested list of category
    $("#CategorySuggestionAddButton").click(
        function () {
            if ($("#CategorySuggestionTextBox").val().trim() != '') {
                var checkCategory = 0;
                $.each(suggestionResult, function (index, value) {

                    if (value.toUpperCase() == $("#CategorySuggestionTextBox").val().toUpperCase().trim()) {
                        addCategoryToList($("#CategorySuggestionTextBox").val().trim());
                        checkCategory++;
                    }

                });
                if (checkCategory == 0) {
                    $.toaster({ priority: 'danger', title: 'Add Category', message: $("#CategorySuggestionTextBox").val() + ' Category is not in our Database. Please add it using the category add button.' });
                }

            }

        }
        );

    //This script is for removing already selected category while creating a new acronym
    $(".TagDiv").on('click', '.RemoveSelectedCategory', function () {


        var removeCategory = $(this).data("value");

        removeFromTaggedCategoryList(removeCategory, this);
    })

    //This script is for adding a selected category while creating a new acronym
    $(".TagDiv").on('click', '.AddSelectedCategory', function () {

        var addCategory = $(this).data("value");
        addToTaggedCategoryList(addCategory, this);
    })
    $("#AcronymFullformTextBox").keyup(function () {
        if ($("#AcronymFullformTextBox").val().trim().length > 5) {
            checkOldAcronym($("#AcronymFullformTextBox").val().trim());
        }
    })

    //This script is for creating a new acronym 
    $("#CreateAcronymButton").click(function () {
        if ($("#AcronymTextBox").val().trim() == "") {
            $("#AcronymValidation").css({ "display": "block" });
        }
        else {
            $("#AcronymValidation").css({ "display": "none" });
        }
        if ($("#AcronymFullformTextBox").val().trim() == "") {
            $("#AcronymFullFormValidation").css({ "display": "block" });
        }
        else {
            $("#AcronymFullFormValidation").css({ "display": "none" });
        }
        if (selectedCategory.length == 0) {
            $("#TaggedCategoryValidation").css({ "display": "block" });
        }
        else {
            $("#TaggedCategoryValidation").css({ "display": "none" });
        }
        if ($("#AcronymTextBox").val().trim() == "" || $("#AcronymFullformTextBox").val().trim() == "" || selectedCategory.length == 0 || acronymNotExists) {
            return false;
        }

        var sendData = { acronymID: $(this).val(), categoryCode: selectedCategory, acronym: $("#AcronymTextBox").val(), acronymDefiniton: $("#AcronymFullformTextBox").val(), comments: $("#CommentsTextBox").val() };

        $.ajax({
            url: "DatabaseManipulation/CreateAcronymInDataBase",
            type: "POST",
            data: JSON.stringify(sendData),
            //data: sendData,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            success: function (response) {
                if (response == true) {
                    $("#AcronymFormModal").modal('hide');
                    $.toaster({ priority: 'success', title: 'Add Acronym', message: 'The Acronym is Created Successfully' });
                    acronymSearch($("#AcronymSearchTextBox").val().trim(), $("#CategorySearchTextBox").val().trim(), $("#dateFilterDropDown").val(), 0);
                }
                else {
                    $.toaster({ priority: 'danger', title: 'Add Acronym', message: 'The Acronym already exist in our database' });
                }
            },
            error: function (xhr, textStatus, thrownError) {
                console.log(textStatus);
                $.toaster({ priority: 'danger', title: 'Add Acronym', message: 'Some Error Happened' });
            }
        })
    })


    //This script is for creating a new category

    $("#CategoryCreateButton").click(function () {
        if ($("#CategorySuggestionTextBox").val().trim() != '') {
            var checkCategory = 0
            $.each(suggestionResult, function (index, value) {
                if (value.toUpperCase() == $("#CategorySuggestionTextBox").val().toUpperCase().trim()) {
                    checkCategory++;
                }
            })
            if (checkCategory > 0) {
                $.toaster({ priority: 'danger', title: 'Add Category', message: $("#CategorySuggestionTextBox").val() + ' Category is already in our Database.' });
            }
            else {

                var sendData = { categoryCode: $("#CategorySuggestionTextBox").val() };
                //alert(JSON.stringify(sendData.categoryCode));

                $.ajax({
                    url: "DatabaseManipulation/AddCategory",
                    type: "POST",
                    data: JSON.stringify(sendData),
                    contentType: "application/json; charset=utf-8",
                    datatype: "json",
                    success: function (response) {
                        $.toaster({ priority: 'success', title: 'Add Category', message: $("#CategorySuggestionTextBox").val() + ' Category is added in our Database.' });
                        $("#CategorySuggestionTextBox").val("");
                        $("#TaggedCategoryList").append('<li class="list-inline-item" ><h4 ><span class="label categoryLabel"><a class="glyphicon glyphicon-remove RemoveSelectedCategory" data-value=' + sendData.categoryCode + '></a>' + sendData.categoryCode + '</span></h4></li>');
                        selectedCategory.push(sendData.categoryCode);
                    },
                    error: function (xhr, textStatus, thrownError) {
                        console.log(textStatus);
                    }
                });
            }
        }
        else {
            $.toaster({ priority: 'danger', title: 'Add Category', message: 'Category is empty.' });
        }
    });

    //This script is for closing the acronym form
    $("#CloseAcronymButton").click(function () {
        $("#AcronymFormModal").modal('hide');
    });

});
