﻿

$(document).ready(function () {

    //This script is used to pass parameter values from ui to the controller and to fetch the acronym results
    var suggestionResultForAdd = [];
    $("#AddAcronymLink").unbind("click");
    var acronymSearch = function (acronymEntered, categoryFilterSelected, dateFilterSelected, pageNumberSelected) {
        var sendData = { acronym: acronymEntered.trim(), categoryFilter: categoryFilterSelected.trim(), dateFilter: dateFilterSelected.trim(), pageNumber: pageNumberSelected };
            $.ajax({
                url: "Home/SearchResult",
                type: "POST",
                data: JSON.stringify(sendData),
                contentType: "application/json; charset=utf-8",
                datatype: "html",
                success: function (response) {
                    $("#RenderingPage").html(response);
                },
                error: function (xhr, textStatus, thrownError) {
                    console.log(textStatus);
                }
            })


    }
      
   //This script is used for auto suggesting the list of acronyms based on keyword
    $("#AcronymSearchTextBox").autocomplete({
        select: function (event, ui) {
            acronymSearch(ui.item.value, $("#CategorySearchTextBox").val(), $("#dateFilterDropDown").val(), 0); 
                    },
        source: function (request, response) {
            $.ajax({
                url: "/Home/AutoCompleteAcronym",
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: "{ 'acronym':'" + request.term + "'}",
                success: function (data) {
                    response($.map(data, function (acronym) {
                        if (data.indexOf(acronym) === -1) {
                            return
                            {
                                label: "No results"

                            }
                        }
                        else {
                            return { label: acronym, value: acronym };
                        }
                    }))

                },
                error: function (XHR, textStatus, errorThrown) {
                    console.log(textStatus);
                }
            })
        },
    });

    //This script is used for auto suggesting the list of category based on keyword
    $("#CategorySearchTextBox").autocomplete({
        select: function (event, ui) {
            acronymSearch($("#AcronymSearchTextBox").val(),ui.item.value, $("#dateFilterDropDown").val(), 0);
        },
        source: function (request, response) {
            $.ajax({
                url: "/Home/AutoCompleteCategory",
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: "{ 'categoryCode':'" + request.term + "'}",
                success: function (data) {
                    suggestionResultForAdd = data;
                    response($.map(data, function (category) {
                        if (data.indexOf(category) === -1) {
                            return
                            {
                                label: "No results"

                            }
                        }
                        else {
                            return { label: category, value: category };
                        }
                    }))

                },
                error: function (XHR, textStatus, errorThrown) {
                    console.log(textStatus);
                }
            })
        },
    });


    //This script is used for passing acronym,category and time filter values from ui to controller
    $("#AcronymSearchButton").click(function () {
        if (!($("#AcronymSearchTextBox").val().trim() == "" && $("#CategorySearchTextBox").val().trim() == "" && $("#dateFilterDropDown").val() == 0)) {
            acronymSearch($("#AcronymSearchTextBox").val(), $("#CategorySearchTextBox").val(), $("#dateFilterDropDown").val(), 0);
        }
        else {
            $("#RenderingPage").html("<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>No Results Found </b> </span>");             
        }
    });


    //This script is used for passing acronym,category and time filter values from ui to controller
    $("#CategoryFilterButton").click(function () {
        acronymSearch($("#AcronymSearchTextBox").val(), $("#CategorySearchTextBox").val(), $("#dateFilterDropDown").val(), 0);
    });

    //This script is used for passing acronym,category and time filter values from ui to controller
    $("#dateFilterDropDown").change(function () {
        acronymSearch($("#AcronymSearchTextBox").val(), $("#CategorySearchTextBox").val(), $("#dateFilterDropDown").val(), 0);
    });

    //This script is used for adding category
    $("#CategoryAddButton").click(function () {
        if ($("#CategorySearchTextBox").val().trim() != '') {
            var checkCategory = 0
            $.each(suggestionResultForAdd, function (index, value) {
                if (value.toUpperCase() == $("#CategorySearchTextBox").val().toUpperCase()) {
                    checkCategory++;
                }
            })
            if (checkCategory > 0) {
                $.toaster({ priority: 'danger', title: 'Add Category', message: $("#CategorySearchTextBox").val() + ' Category is already in our Database.' });
            }
            else {
                
                var sendData = { categoryCode: $("#CategorySearchTextBox").val() };
                $.ajax({
                    url: "DatabaseManipulation/AddCategory",
                    type: "POST",
                    data: JSON.stringify(sendData),
                    contentType: "application/json; charset=utf-8",
                    datatype: "json",
                    success: function (response) {
                        $.toaster({ priority: 'success', title: 'Add Category', message: $("#CategorySearchTextBox").val() + ' Category is added in our Database.' });
                    },
                    error: function (xhr, textStatus, thrownError) {
                        console.log(textStatus);

                    }
                });
            }
        }
        else {
            $.toaster({ priority: 'danger', title: 'Add Category', message: 'Category is empty.' });
        }
    });


    //This script is for Enterkey press event in  acronym search box
    $("#AcronymSearchTextBox").keyup(function (event) {
        var keycode = (event.keyCode ? event.keyCode : ev.which);
        
        if (keycode == 13) {
            if (!($("#AcronymSearchTextBox").val().trim() == "" && $("#CategorySearchTextBox").val().trim() == "" && $("#dateFilterDropDown").val()==0)) {
                acronymSearch($("#AcronymSearchTextBox").val(), $("#CategorySearchTextBox").val(), $("#dateFilterDropDown").val(), 0);
            }
            else {
                $("#RenderingPage").html("<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>No Results Found </b> </span>");
            }
        }
    });

    //This script is for Enterkey press event in category search box
    $("#CategorySearchTextBox").keyup(function (event) {
        var keycode = (event.keyCode ? event.keyCode : ev.which);
        
        if (keycode == 13 ) {
            if ($("#CategorySearchTextBox").val().trim() != '') {  
                acronymSearch($("#AcronymSearchTextBox").val(), $("#CategorySearchTextBox").val(), $("#dateFilterDropDown").val(), 0);
            }
            if ($("#AcronymSearchTextBox").val().trim() == "" && $("#CategorySearchTextBox").val().trim() == "" && $("#dateFilterDropDown").val() == 0) {
                $("#RenderingPage").html("<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>No Results Found </b> </span>");
            }
        } 
    });

    $('[data-toggle="popover"]').popover();
})

function AddAcronymButton() {
    $.ajax({
        url: "Home/AddAcronymButtonClick",
        type: "GET",
        datatype: "html",
        success: function (response) {
            $("#AcronymForm").html(response);
            $("#AcronymFormModal").modal("show");
        },
        error: function (xhr, textStatus, thrownError) {
            console.log(textStatus);
        }
    }
    )
};