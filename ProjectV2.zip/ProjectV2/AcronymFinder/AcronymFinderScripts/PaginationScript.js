﻿$(document).ready(function () {

    //This script is used for pagination when we have more than six results for the searched acronym
    var acronymSearch = function (acronymEntered, categoryFilterSelected, dateFilterSelected, pageNumberSelected) {
        
        var sendData = { acronym: acronymEntered.trim(), categoryFilter: categoryFilterSelected.trim(), dateFilter: dateFilterSelected.trim(), pageNumber: pageNumberSelected };
            $.ajax({
                url: "Home/PaginationClick",//change here
                type: "POST",
                data: JSON.stringify(sendData),
                contentType: "application/json; charset=utf-8",
                datatype: "html",
                success: function (response) {
                    $("#PaginationContent").html(response);
                },
                error: function (xhr, textStatus, thrownError) {
                    console.log(xhr.statusText);
                }
            });
        
    }
    // This is for selecting the prefered page
    $('#PageSelection').bootpag({
        total: Math.ceil(($("#NumberOfResult").val() / 6)),
        maxVisible: 5
    }).on("page", function (event, num) {
        acronymSearch($("#AcronymSearchTextBox").val(), $("#CategorySearchTextBox").val(), $("#dateFilterDropDown").val(), num - 1);

    });
});