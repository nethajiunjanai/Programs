-- =============================================
-- Author:		Vignesh Prakash
-- Create date: 17-08-2017
-- Description:	Procedure for validation of existing Acronyms in the acronym table
-- =============================================
ALTER PROCEDURE CheckOldAcronym
	 @acronym VARCHAR(5000)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT(AcronymDefinition) FROM AcronymDetails 
	WHERE AcronymDefinition=@acronym

END
GO
