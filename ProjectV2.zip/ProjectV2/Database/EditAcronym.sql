-- =============================================
-- Author:		Vignesh Prakash
-- Create date: 12-08-2017
-- Description:	Query for editing the records in the acronym table
-- =============================================
ALTER PROCEDURE EditAcronym 
	@acronymID INT,
	@acronym VARCHAR(20),
	@acronymDefinition VARCHAR(5000),
	@comments VARCHAR(500)
	AS
BEGIN
	
	UPDATE AcronymDetails SET Acronym=@acronym,AcronymDefinition=@acronymDefinition,Comments=@comments,
	ModifiedDateTime=GETDATE() WHERE AcronymID=@acronymID

END

GO
