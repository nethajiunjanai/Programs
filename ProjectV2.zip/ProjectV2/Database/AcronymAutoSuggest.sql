-- =============================================
-- Author:		Vignesh Prakash
-- Create date: 16-08-2017
-- Description:	Procedure for Auto Suggest feature in Acronym Search Table
-- =============================================
ALTER PROCEDURE AcronymAutoSuggest 
	@acronym VARCHAR(20)
AS

BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT(Acronym) FROM AcronymDetails WITH(NOLOCK) 
	WHERE AcronymDetails.Acronym LIKE (@acronym+'%')
	
END
GO
