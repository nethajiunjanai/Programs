-- =============================================
-- Author:		Nethaji T
-- Create date: 11-08-2017
-- Description:	Query for inserting records into Acronym Table
-- =============================================
ALTER PROCEDURE AddAcronym 
	@acronym VARCHAR(20),
	@acronymDefinition VARCHAR(5000),
	@comments VARCHAR(500)
	AS
BEGIN
	
	INSERT INTO AcronymDetails VALUES(@acronym,@acronymDefinition,@comments,
	GETDATE(),GETDATE())

    END
GO
