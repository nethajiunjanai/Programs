-- =============================================
-- Author:		Nethaji T
-- Create date: 17-08-2017
-- Description:	Procedure for displaying the number of results found after search
-- =============================================
ALTER PROCEDURE SearchAndCount
	@acronym VARCHAR(20),
	@categoryCode VARCHAR(20)=NULL,
	@numberOfDays INT=0,
	@pageNumber INT=0,
	@resultsCount INT OUTPUT
AS

BEGIN
	SET NOCOUNT ON;

		DECLARE @count  INT;
	
	    IF((@acronym='')AND(@categoryCode IS NULL)AND(@pageNumber=0))
		BEGIN
		EXEC SearchAcronym @acronym,@categoryCode,@numberOfDays,@pageNumber,@resultsCount
		SET @resultsCount=(
        SELECT COUNT(DISTINCT(AcronymDetails.AcronymID)) AS results FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
        ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN CategoryDetails WITH(NOLOCK) 
		ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
        WHERE AcronymDetails.CreatedDateTime IN 
		(SELECT�CreatedDateTime
		FROM�AcronymDetails
		WHERE CreatedDateTime�>=�DATEADD(day,-(@numberOfDays),�GETDATE())))
		END

		ELSE IF((@categoryCode is null)AND(@numberOfDays=0) AND (@pageNumber=0))
		BEGIN 
		EXEC SearchAcronym @acronym,@categoryCode,@numberOfDays,@pageNumber,@resultsCount
		SET @resultsCount=(
        SELECT COUNT(DISTINCT(AcronymDetails.AcronymID)) AS results FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
        ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID
        WHERE Acronym=@acronym)
		
		END
		
		ELSE IF((@acronym='')AND(@numberOfDays=0) AND (@pageNumber=0))
		BEGIN 
		EXEC SearchAcronym @acronym,@categoryCode,@numberOfDays,@pageNumber,@resultsCount
		SET @resultsCount=(
        SELECT COUNT(DISTINCT(AcronymDetails.AcronymID)) AS results FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
        ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN CategoryDetails WITH(NOLOCK) 
		ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
        WHERE CategoryDetails.CategoryCode=@categoryCode)
		
		END
		
		ELSE IF((@pageNumber=0)AND (@numberOfDays=0))
		BEGIN
		EXEC SearchAcronym @acronym,@categoryCode,@numberOfDays,@pageNumber,@resultsCount
		SET @resultsCount=(
        SELECT COUNT(DISTINCT(AcronymDetails.AcronymID)) AS results FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
        ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN CategoryDetails WITH(NOLOCK) 
		ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID 
        WHERE (AcronymDetails.Acronym=@acronym) AND (CategoryDetails.CategoryCode=@categoryCode))
		END
		
		ELSE IF((@acronym='')AND (@pageNumber=0))
		BEGIN
		EXEC SearchAcronym @acronym,@categoryCode,@numberOfDays,@pageNumber,@resultsCount
		SET @resultsCount=(
        SELECT COUNT(DISTINCT(AcronymDetails.AcronymID)) AS results FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
        ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN CategoryDetails WITH(NOLOCK) 
		ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
        WHERE (CategoryDetails.CategoryCode=@categoryCode) 
        AND (AcronymDetails.CreatedDateTime IN 
		(SELECT�CreatedDateTime
		FROM�AcronymDetails
		WHERE CreatedDateTime�>=�DATEADD(day,-(@numberOfDays),�GETDATE()))))
		END

		ELSE IF((@categoryCode IS NULL)AND (@pageNumber=0))
		BEGIN
		EXEC SearchAcronym @acronym,@categoryCode,@numberOfDays,@pageNumber,@resultsCount
		SET @resultsCount=(
        SELECT COUNT(DISTINCT(AcronymDetails.AcronymID)) AS results FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
        ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN CategoryDetails WITH(NOLOCK) 
		ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
        WHERE (AcronymDetails.Acronym=@acronym) 
        AND (AcronymDetails.CreatedDateTime IN 
		(SELECT�CreatedDateTime
		FROM�AcronymDetails
		WHERE CreatedDateTime�>=�DATEADD(day,-(@numberOfDays),�GETDATE()))))
		END
		
		ELSE
		BEGIN
		EXEC SearchAcronym @acronym,@categoryCode,@numberOfDays,@pageNumber,@resultsCount
		SET @resultsCount=(
        SELECT COUNT(DISTINCT(AcronymDetails.AcronymID)) AS results FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
        ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN CategoryDetails
		ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID 
        WHERE (AcronymDetails.Acronym=@acronym)AND(CategoryDetails.CategoryCode=@categoryCode)
		 AND (AcronymDetails.CreatedDateTime IN 
		(SELECT�CreatedDateTime
		FROM�AcronymDetails
		WHERE CreatedDateTime�>=�DATEADD(day,-(@numberOfDays),�GETDATE()))))
		END
END
GO

declare @a int
exec SearchAndCount'GSD',NULL,10,0,@a out

PRINT @a

/*ELSE
		BEGIN
		EXEC SearchAcronym @acronym,@categoryCode,@numberOfDays,@pageNumber,@resultsCount
		SELECT  @resultsCount=@@ROWCOUNT;
		END*/