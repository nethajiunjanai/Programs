-- =============================================
-- Author:		Vignesh Prakash
-- Create date: 11-08-2017
-- Description:	Query for searching and displying the required records based on the required parameters
-- =============================================

ALTER PROCEDURE SearchAcronym
	@acronym VARCHAR(20),
	@categoryCode VARCHAR(20)=NULL,
	@numberOfDays INT=0,
	@pageNumber INT=0,
	@resultCount INT OUTPUT
AS
BEGIN
	
	SET NOCOUNT ON;

		 IF((@acronym='') AND (@categoryCode IS NULL))
		(
			SELECT AcronymTable.AcronymID,AcronymTable.Acronym,AcronymTable.AcronymDefinition,AcronymTable.CategoryCode FROM
			(SELECT AcronymDetails.AcronymID,Acronym,AcronymDefinition,CategoryCode,
			 DENSE_RANK() OVER(ORDER BY AcronymDetails.AcronymID ASC) AS rownumber 
			FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
			ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN 
			CategoryDetails WITH(NOLOCK) ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
			WHERE AcronymDetails.CreatedDateTime IN 
			(SELECT�CreatedDateTime
			FROM�AcronymDetails
			WHERE CreatedDateTime�>=�DATEADD(day,-(@numberOfDays),�GETDATE()))) 
			AS AcronymTable WHERE rownumber > (@pageNumber*6) AND rownumber <= ((@pageNumber*6)+6)
		)
		
		ELSE IF((@categoryCode IS NULL) AND (@numberOfDays=0))
		(
			SELECT AcronymTable.AcronymID,AcronymTable.Acronym,AcronymTable.AcronymDefinition,AcronymTable.CategoryCode FROM
			(SELECT AcronymDetails.AcronymID,Acronym,AcronymDefinition,CategoryCode,
				DENSE_RANK() OVER(ORDER BY AcronymDetails.AcronymID ASC) AS rownumber
			FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
			ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN 
			CategoryDetails WITH(NOLOCK) ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
			WHERE AcronymDetails.Acronym=@acronym)
			AS AcronymTable WHERE rownumber > (@pageNumber*6) AND rownumber <= ((@pageNumber*6)+6)
		)


		ELSE IF((@acronym='') AND (@numberOfDays=0))
		(
			SELECT AcronymTable.AcronymID,AcronymTable.Acronym,AcronymTable.AcronymDefinition,AcronymTable.CategoryCode FROM
			(SELECT AcronymDetails.AcronymID,Acronym,AcronymDefinition,CategoryCode,
			 DENSE_RANK() OVER(ORDER BY AcronymDetails.AcronymID ASC) AS rownumber 
			FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
			ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN 
			CategoryDetails WITH(NOLOCK) ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
			WHERE CategoryDetails.CategoryCode=@categoryCode) 
			AS AcronymTable WHERE rownumber > (@pageNumber*6) AND rownumber <= ((@pageNumber*6)+6)
		)

		
				
		ELSE IF(@acronym='')
		(
			SELECT AcronymTable.AcronymID,AcronymTable.Acronym,AcronymTable.AcronymDefinition,AcronymTable.CategoryCode FROM
			(SELECT AcronymDetails.AcronymID,Acronym,AcronymDefinition,CategoryCode,
			 DENSE_RANK() OVER(ORDER BY AcronymDetails.AcronymID ASC) AS rownumber  
			FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
			ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN 
			CategoryDetails WITH(NOLOCK) ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
			WHERE CategoryDetails.CategoryCode=@categoryCode AND AcronymDetails.CreatedDateTime IN 
			(SELECT�CreatedDateTime
			FROM�AcronymDetails
			WHERE CreatedDateTime�>=�DATEADD(day,-(@numberOfDays),�GETDATE())))
			AS AcronymTable WHERE rownumber > (@pageNumber*6) AND rownumber <= ((@pageNumber*6)+6)
		)
	
		ELSE IF(@categoryCode IS NULL)
		(
			SELECT AcronymTable.AcronymID,AcronymTable.Acronym,AcronymTable.AcronymDefinition,AcronymTable.CategoryCode FROM
			(SELECT AcronymDetails.AcronymID,Acronym,AcronymDefinition,CategoryCode,
			 DENSE_RANK() OVER(ORDER BY AcronymDetails.AcronymID ASC) AS rownumber  
			FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
			ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN 
			CategoryDetails WITH(NOLOCK) ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
			WHERE AcronymDetails.Acronym=@acronym AND AcronymDetails.CreatedDateTime IN 
			(SELECT�CreatedDateTime
			FROM�AcronymDetails
			WHERE CreatedDateTime�>=�DATEADD(day,-(@numberOfDays),�GETDATE())))
			AS AcronymTable WHERE rownumber > (@pageNumber*6) AND rownumber <= ((@pageNumber*6)+6)
		)

		ELSE IF(@numberOfDays=0) 
		(
			SELECT AcronymTable.AcronymID,AcronymTable.Acronym,AcronymTable.AcronymDefinition,AcronymTable.CategoryCode FROM
			(SELECT AcronymDetails.AcronymID,Acronym,AcronymDefinition,CategoryCode,
			DENSE_RANK() OVER(ORDER BY AcronymDetails.AcronymID ASC) AS rownumber   
			FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
			ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN 
			CategoryDetails WITH(NOLOCK) ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
			WHERE AcronymDetails.Acronym=@acronym AND CategoryDetails.CategoryCode=@categoryCode)
			AS AcronymTable WHERE rownumber > (@pageNumber*6) AND rownumber <= ((@pageNumber*6)+6)
		)

		--ELSE IF((@acronym='') AND (@categoryCode IS NULL))
		--(
		--	SELECT AcronymTable.AcronymID,AcronymTable.Acronym,AcronymTable.AcronymDefinition,AcronymTable.CategoryCode FROM
		--	(SELECT AcronymDetails.AcronymID,Acronym,AcronymDefinition,CategoryCode,
		--	DENSE_RANK() OVER(ORDER BY AcronymDetails.AcronymID ASC) AS rownumber   
		--	FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
		--	ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN 
		--	CategoryDetails WITH(NOLOCK) ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
		--	WHERE AcronymDetails.CreatedDateTime IN
		--	(SELECT�CreatedDateTime
		--	FROM�AcronymDetails
		--	WHERE CreatedDateTime�>=�DATEADD(day,-(@numberOfDays),�GETDATE())))
		--	AS AcronymTable WHERE rownumber > (@pageNumber*6) AND rownumber <= ((@pageNumber*6)+6)
		--)
				
		ELSE
		(
			SELECT AcronymTable.AcronymID,AcronymTable.Acronym,AcronymTable.AcronymDefinition,AcronymTable.CategoryCode FROM
			(SELECT AcronymDetails.AcronymID,Acronym,AcronymDefinition,CategoryCode,
			DENSE_RANK() OVER(ORDER BY AcronymDetails.AcronymID ASC) AS rownumber    
			FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK)
			ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN 
			CategoryDetails WITH(NOLOCK) ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID
			WHERE AcronymDetails.Acronym=@acronym AND CategoryDetails.CategoryCode=@categoryCode AND
			AcronymDetails.CreatedDateTime IN 
			(SELECT�CreatedDateTime
			FROM�AcronymDetails
			WHERE CreatedDateTime�>=�DATEADD(day,-(@numberOfDays),�GETDATE())))
			AS AcronymTable WHERE rownumber > (@pageNumber*6) AND rownumber <= ((@pageNumber*6)+6)
		)
    END
GO



