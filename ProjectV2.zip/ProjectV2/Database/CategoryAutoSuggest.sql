-- =============================================
-- Author:		Vignesh P
-- Create date: 16-08-2017
-- Description:	Procedure for Auto Suggest Feature during the search in Category Table
-- =============================================
ALTER PROCEDURE CategoryAutoSuggest 
	@categoryCode VARCHAR(20)
	
AS

BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT(CategoryCode) FROM CategoryDetails WITH(NOLOCK) 
	WHERE CategoryDetails.CategoryCode LIKE (@categoryCode+'%')
	
END
GO
