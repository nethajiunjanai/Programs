-- =============================================
-- Author:		Nethaji T
-- Create date: 11-08-2017
-- Description:	Query for inserting records into Category Mapping Table
-- =============================================
ALTER PROCEDURE AddToMapping 
	@categoryCode VARCHAR(20)
	AS
BEGIN

	DECLARE @acronymID INT;
	DECLARE @categoryID INT;
	SELECT @acronymId=MAX(AcronymID) FROM AcronymDetails 
	SELECT @categoryId=CategoryID FROM CategoryDetails WHERE CategoryCode=@categoryCode
	INSERT INTO AcronymCategoryMapping VALUES(@acronymID,@categoryID);

END

GO
