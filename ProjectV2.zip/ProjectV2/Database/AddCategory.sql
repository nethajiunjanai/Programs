-- =============================================
-- Author:		Nethaji T
-- Create date: 11-08-2017
-- Description:	Query for inserting records into Category table
-- =============================================
ALTER PROCEDURE AddCategory 
	-- Add the parameters for the stored procedure here
	@categoryCode VARCHAR(20),
	@categoryName VARCHAR(500)=NULL
	AS
BEGIN

	INSERT INTO CategoryDetails VALUES(@categoryCode,@categoryName)

	END
GO
