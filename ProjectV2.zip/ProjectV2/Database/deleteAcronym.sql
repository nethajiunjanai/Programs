-- =============================================
-- Author:		Nethaji T
-- Create date: 11-08-2017
-- Description:	Procedure  for deleting the records in the Acronym table
-- =============================================
ALTER PROCEDURE deleteAcronym 
	 @acronymID INT 
AS
	DECLARE @rowNumber INT;
	SET @rowNumber=(SELECT COUNT(CategoryID) FROM AcronymCategoryMapping WHERE AcronymID=@acronymID)
	BEGIN
    
	DECLARE @categoryID INT;

	DECLARE @rowCount INT=1;
	
	WHILE(@rowCount<=@rowNumber)
	BEGIN
	SELECT @categoryID=CategoryID from (SELECT ROW_NUMBER() OVER(ORDER BY MappingID) AS rowNum,CategoryID FROM AcronymCategoryMapping WHERE AcronymID=@acronymID ) AS CategoryIdLists where rowNum=1
	IF((SELECT COUNT(AcronymID) FROM AcronymCategoryMapping WHERE CategoryID=@categoryID)=1)
	BEGIN
	DELETE FROM AcronymCategoryMapping WHERE AcronymCategoryMapping.AcronymID=@acronymID AND CategoryID=@categoryID
	DELETE FROM CategoryDetails WHERE CategoryID=@categoryID
	END
	ELSE
	BEGIN
	DELETE FROM AcronymCategoryMapping WHERE AcronymCategoryMapping.AcronymID=@acronymID AND CategoryID=@categoryID
	END
	SET @rowCount=@rowCount+1;
	END	
	DELETE FROM AcronymDetails WHERE AcronymID=@acronymID;
	END
GO





