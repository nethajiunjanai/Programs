-- =============================================
-- Author:		Nethaji T
-- Create date: 18-08-2017
-- Description:	Query for updating the records in the Category Mapping Table
-- =============================================
ALTER PROCEDURE EditAcronymMapping 
	@categoryCode VARCHAR(20),
	@acronymID  INT
	AS
BEGIN
	
	DECLARE @categoryID INT;
	SELECT @categoryID=CategoryID FROM CategoryDetails WHERE CategoryCode=@categoryCode
	INSERT INTO AcronymCategoryMapping VALUES(@acronymID,@categoryID);
		
END

GO
