-- =============================================
-- Author:		Kavin N
-- Create date: 11-08-2017
-- Description:	Query for deleting the records from Category Mapping Table
-- =============================================
ALTER PROCEDURE DeleteAcronymMapping
	@acronymID INT
AS

BEGIN

DELETE FROM AcronymCategoryMapping WHERE 
AcronymCategoryMapping.AcronymID=@acronymID;

END
GO
