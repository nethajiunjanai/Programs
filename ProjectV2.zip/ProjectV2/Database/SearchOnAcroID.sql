-- =============================================
-- Author:		Nethaji T
-- Create date: 17-08-2017
-- Description:	Search based on AcroID for editing the acronyms
-- =============================================
ALTER PROCEDURE SearchOnAcroID
	@acronymID INT
AS

BEGIN
	
	SET NOCOUNT ON;
	SELECT AcronymDetails.AcronymID,Acronym,AcronymDefinition,Comments,categoryCode 
	FROM AcronymDetails WITH(NOLOCK) JOIN AcronymCategoryMapping WITH(NOLOCK) 
	ON AcronymDetails.AcronymID=AcronymCategoryMapping.AcronymID JOIN
	CategoryDetails WITH(NOLOCK) ON CategoryDetails.CategoryID=AcronymCategoryMapping.CategoryID 
	WHERE AcronymDetails.AcronymID=@acronymID 
	
END
GO
