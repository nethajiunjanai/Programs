﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ipl_casestudy
//{
//    class Class1
//    {
//        public static void Main()
//        {
//            int[] a = new int[] { 1, 2, 3, 4, -6, -5 };
//            int count = 1;
//            for (int i = 0; i < 5; i++)
//            {
//                if ((a[i + 1] - a[i] == 1) &&(a[i]>0))
//                {
//                    count++;
                    
//                }
//                //else
//                //{
//                //    count = 0;
//                //}

//            }
//          //  Console.WriteLine(count);
//            Console.WriteLine(count);
//        }
//    }
//}

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//namespace Hello_Word
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            int val = 5;
//            int i, k;
//            for (i = 1; i <= val; i++)
//            {
               
//                for (k = 1; k <= i; k++)
//                {
//                    Console.Write("3");
//                }
//                 Console.WriteLine("");
//            }
            
//        }
//    }
//}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Program
{
    class Program
    {
        public static void Main(string[] args)
        {
            int num1, num2, i;
            int hcf = 0;
            Console.Write("\nEnter the First Number : ");
            num1 = int.Parse(Console.ReadLine());
            Console.Write("\nEnter the Second Number : ");
            num2 = int.Parse(Console.ReadLine());
            for (i = 1; i <= num1 || i <= num2; i++)
            {
                if (num1 % i == 0 && num2 % i == 0)
                {
                    hcf = i;
                }
            }
            Console.Write("\nCommon Factor is : ");
            Console.WriteLine(hcf);
            Console.Read();
        }
    }
}