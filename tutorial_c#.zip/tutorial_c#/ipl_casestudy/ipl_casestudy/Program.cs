﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ipl_casestudy
//{
//    class ipl
//    {
//        public void options()
//        {
//            Console.WriteLine("Enter your Option\n1.Add Match Details\n2.Modify Match Details\n3.Search Match\n4.Delete Match\n5.Dispaly All matchces\n6.Exit");

//        }
//    }
//    class operation
//    {
//        static void Main(string[] args)
//        {
//        }
//    }
//}
