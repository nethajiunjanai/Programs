﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;

//namespace iplcase
//{
//    class match
//    {
//        public string mid;
//        public string team1;
//        public string team2;
//        public string uname;
//        public string result;
//    }
//    class add
//    {
//        public static List<match> mat = new List<match>();
//        public static void Main()
//        {

//            match m;
//            int i;
//            int number = int.Parse(Console.ReadLine());
//            for (i = 0; i < number; i++)
//            {
//                m = null;
//                m = new match();
//                Console.WriteLine("Matchid");
//                m.mid = (Console.ReadLine());
//                Console.WriteLine("team1");
//                m.team1 = Console.ReadLine();
//                Console.WriteLine("team2");
//                m.team2 = Console.ReadLine();
//                Console.WriteLine("umpires");
//                m.uname = Console.ReadLine();
//                Console.WriteLine("result");
//                m.result = Console.ReadLine();
//                mat.Add(m);
//            }
//            //FileStream fs1 = new FileStream(@"D:\file\case.txt", FileMode.Append, FileAccess.Write);
//            //StreamWriter sw = new StreamWriter(fs1);
//            //foreach (var v in mat)
//            //{
//            //    sw.WriteLine(v.mid);
//            //    sw.WriteLine(v.team1);
//            //    sw.WriteLine(v.team2);
//            //    sw.WriteLine(v.uname);
//            //    sw.WriteLine(v.result);
//            //}
//            //  sw.Close();
              
//              Console.WriteLine("enter the match id");
//              string id =(Console.ReadLine());
//              foreach (var v in mat)
//              {
//                  if (id == v.mid)
//                  {
//                      Console.WriteLine(v.mid);
//                      Console.WriteLine(v.team1);
//                      Console.WriteLine(v.team2);
//                      Console.WriteLine(v.uname);
//                      Console.WriteLine(v.result);
//                  }
//              }
//            //StreamReader sr = new StreamReader(fs1);
//            //string s;
//            //Console.WriteLine("enter the id");
//            //int id = int.Parse(Console.ReadLine());
//            //while ((s = sr.ReadLine()) != null)
//            //{
//            //    if
//            //    Console.WriteLine(s);
//            //}
//            //   add a = new add();
//            //  a.show();
//        }
//    }
//}
