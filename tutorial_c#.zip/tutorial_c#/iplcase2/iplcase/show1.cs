﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;

//namespace iplcase
//{
//    class show1
//    {
//        public void show()
//        {
//            FileStream fs1 = new FileStream(@"D:\file\case.txt", FileMode.Open, FileAccess.Read);
//            FileStream fs2 = new FileStream(@"D:\file\case1.txt", FileMode.Append, FileAccess.Write);
//            StreamWriter sw1 = new StreamWriter(fs2);
//            StreamReader sr = new StreamReader(fs1);
//            string s;
//            //search modify try
//            //while ((s = sr.ReadLine()) != null)
//                //Console.WriteLine(s);
//            Console.WriteLine("enter the search keyword");
//            var key = Console.ReadLine();
            

////search
//            while ((s = sr.ReadLine()) != null)
//            {
//            if(s == key)
            
//            {

//                Console.WriteLine(key);
//                sw1.WriteLine(s);
//                Console.WriteLine("Match found");
                
//            }
//            }
            
            
//            sr.Close();
//            sw1.Close();
//        }
//    }
//}
