﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Collections;
//using System.IO;

//namespace iplcase
//{
//    class add
//    {
//        public static void Main()
//        {
//            int n = 2;
//            for (int i = 0; i <= n; i++)
//            {
//                Console.WriteLine("Enter the match number:");
//                string match = Console.ReadLine();
//                Console.WriteLine("Enter the team1:");
//                string team1 = Console.ReadLine();
//                Console.WriteLine("Enter the team2:");
//                string team2 = Console.ReadLine();
//                Console.WriteLine("Enter the result:");
//                string result = Console.ReadLine();
//                Console.WriteLine("Enter the umpires:");
//                string umpires = Console.ReadLine();
//                ArrayList l = new ArrayList();

//                l.Add("Match number" + match);
//                l.Add("Team1:" + team1);
//                l.Add("Team2:" + team2);
//                l.Add("Result:" + result);
//                l.Add("Umpire:" + umpires);
//                FileStream fs1 = new FileStream(@"D:\file\demo.txt", FileMode.Append, FileAccess.Write);
//                StreamWriter sw = new StreamWriter(fs1);
//                foreach (string s1 in l)
//                    sw.WriteLine(s1);
//                sw.Close();
//                //    FileStream fs = new FileStream(@"D:\file\demo.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.None);
//                //    StreamReader sr = new StreamReader(fs);
//                //    string s = sr.ReadLine();
//                //    while ((s = sr.ReadLine()) != null)
//                //    {
//                //        Console.WriteLine(s);
//                //    }
//                //    sr.Close();
//                //}
//                ////foreach (object o in l)
//                ////{
//                ////    Console.WriteLine(sw);
//                ////}
//            }
//        }
//    }
//}
