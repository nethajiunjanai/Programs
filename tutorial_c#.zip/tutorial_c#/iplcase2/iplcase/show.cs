﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;
//using System.Collections;

//namespace iplcase
//{
//    class show
//    {
//        public static void Main()
//        {
//            FileStream fs = new FileStream(@"D:\file\demo.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.None);
//            StreamReader sr = new StreamReader(fs);
//            string s = sr.ReadLine();

//            while ((s = sr.ReadLine()) != null)
//            {
//                Console.WriteLine(s);
//            }
//            sr.Close();
//            //to delete a file
//            //File.Delete(@"D:\file\demo.txt");
//            //to show specific  data
           
//            //while ((s = sr.ReadLine()) != null)
            
//            //{
//            //    if (s.Contains("1"))
//            //    {
//            //        //Console.WriteLine(s); 
//            //        s = File.ReadLines(@"D:\file\demo.txt").Skip(14).Take(1).First();
//            //    }
//            //}
//            //s = File.ReadLines(@"D:\file\demo.txt").Skip(14).Take(1).First();
//            //Console.WriteLine(s); 
             
//        }
        
        
//    }
//}
