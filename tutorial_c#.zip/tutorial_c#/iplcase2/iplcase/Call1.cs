﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace iplcase
{
    class operation : functions
    {

        public void valid()
        {

            if (select == 1)
            {
                add();
                choice();
                valid();

            }
            else if (select == 2)
            {
                modify();
                Console.WriteLine("task completed");
                choice();
                valid();

            }
            else if (select == 3)
            {
                show();
                choice();
                valid();
            }
            else if (select == 4)
            {
                delete();
                choice();
                valid();
            }
            else if (select == 5)
            {
                search();
                choice();
                valid();
            }
            else if (select == 6)
            {
                exit();
            }
            else
            {
                Console.WriteLine("Enter the valid option");
                choice();
            }
        }
        public static void Main(string[] args)
        {
            operation f = new operation();
            f.choice();
            f.valid();


        }
    }

}
