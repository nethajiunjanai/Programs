﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;

//namespace iplcase
//{
//    class data
//    {
//        public string modi;
//    }
//    class modify

//    { 

//        public static List<data> mod=new List<data>();
//        public static void Main()
//        {
//            FileStream fs1 = new FileStream(@"D:\file\case.txt", FileMode.Open, FileAccess.Read);
//            StreamReader srm = new StreamReader(fs1);
//            string s;
//            FileStream fw = new FileStream((@"D:\file\case2.txt"), FileMode.Create, FileAccess.Write);
//            StreamWriter swm = new StreamWriter(fw);
//            Console.WriteLine("Enter the text which has to be modified:");
//            var modify = Console.ReadLine();
//            while ((s = srm.ReadLine()) != null)
//            {
//                if (s != modify)
//                {
//                    Console.WriteLine(s);
//                    data d = new data();
//                    d.modi = s;
//                    mod.Add(d);
//                }
//                else
//                {
//                    Console.WriteLine("Enter the modified text:");
//                    var text = Console.ReadLine();
//                    s = text;
//                    data d = new data();
//                    d.modi = s;
//                    mod.Add(d);
//                }
//            }
//            foreach (var m in mod)
//            {
//                swm.WriteLine(m.modi);
//            }
//            srm.Close();
//            swm.Close();           
//        }
//    }
//}
