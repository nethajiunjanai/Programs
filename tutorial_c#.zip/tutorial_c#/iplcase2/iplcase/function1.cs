﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace iplcase
{
    class match
    {
        public int mid;
        public string team1;
        public string team2;
        public string uname;
        public string result;
    }
    //class nmatch
    //{
    //    public int nmid;
    //    public string nteam1;
    //    public string nteam2;
    //    public string nuname;
    //    public string nresult;
    //}

    class data
    {
        public string modi;
    }
    class functions : option
    {
        public static List<match> mat = new List<match>();
        public static List<data> mod = new List<data>();
        //  public static List<nmatch> nmat = new List<nmatch>();
        public void add()
        {
            match m;
            int i;
            Console.WriteLine("enter the number of matches you want to add:");
            int number = int.Parse(Console.ReadLine());
            for (i = 0; i < number; i++)
            {
                m = null;
                m = new match();
                Console.WriteLine("Matchid");
                m.mid = int.Parse(Console.ReadLine());
                Console.WriteLine("team1");
                m.team1 = Console.ReadLine();
                Console.WriteLine("team2");
                m.team2 = Console.ReadLine();
                Console.WriteLine("umpires");
                m.uname = Console.ReadLine();
                Console.WriteLine("result");
                m.result = Console.ReadLine();
                mat.Add(m);
            }
            FileStream fs1 = new FileStream(@"D:\file\case.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs1);
            
            foreach (var v in mat)
            {
                string[] store = new string[] { v.mid.ToString(), v.team1, v.team2, v.result };
                string display = string.Join(",", store);
                sw.WriteLine(display);
                //sw.WriteLine(v.mid);
                //sw.WriteLine(v.team1);
                //sw.WriteLine(v.team2);
                //sw.WriteLine(v.uname);
                //sw.WriteLine(v.result);
            }
            sw.Close();
            Console.WriteLine("Data added successully");
            //    add a = new add();
            //    a.show();
            //}

        }
        public void modify()
        {
            FileStream fs1 = new FileStream(@"D:\file\case.txt", FileMode.Open, FileAccess.Read);
            StreamReader srm = new StreamReader(fs1);
            string s;
            FileStream fw = new FileStream((@"D:\file\modify.txt"), FileMode.Create, FileAccess.Write);
            StreamWriter swm = new StreamWriter(fw);
            Console.WriteLine("Enter the text which has to be modified:");
            var modify = Console.ReadLine();
            while ((s = srm.ReadLine()) != null)
            {
                if(!s.Contains(modify))
              // if (s != modify)
                {
                    Console.WriteLine(s);
                    data d = new data();
                    d.modi = s;
                    mod.Add(d);
                }
                else
                {
                    Console.WriteLine("Enter the modified text:");
                    var text = Console.ReadLine();
                    s = text;
                    data d = new data();
                    d.modi = s;
                    mod.Add(d);
                }
            }
            foreach (var m in mod)
            {
                swm.WriteLine(m.modi);
            }
            srm.Close();
            swm.Close();
        }
        public void delete()
        {

        }
        public void show()
        {
            FileStream fs1 = new FileStream(@"D:\file\case.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs1);
            string s;
            //search modify try
            while ((s = sr.ReadLine()) != null)
            {
                Console.WriteLine(s);
            }
        }
        public void exit()
        {
            Console.WriteLine("wait for sometime.....");
            Console.WriteLine("Thanks for using");
        }
        public void search()
        {
            FileStream fs1 = new FileStream(@"D:\file\case.txt", FileMode.Open, FileAccess.Read);
            StreamReader srm = new StreamReader(fs1);
            FileStream fw = new FileStream((@"D:\file\search.txt"), FileMode.Create, FileAccess.Write);
            StreamWriter swm = new StreamWriter(fw);
            string s;
            while ((s = srm.ReadLine()) != null)
            {
               // Console.WriteLine(s);
                data d = new data();
                d.modi = s;
                mod.Add(d);

            }
            Console.WriteLine("enter the match id");
            string id = (Console.ReadLine());
            int i;
            foreach (var v in mod)
            {
                if (v.modi.Contains(id))
                {
                    Console.WriteLine("Match found");
                    Console.WriteLine(v.modi);
                    swm.WriteLine(v.modi);
                }
            }
            srm.Close();
            swm.Close();
        }
    }
}

