﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test
{
    class Class1
    {
        public static void Main()
        {
            int x;
            x = int.Parse(Console.ReadLine());
            string[] s = new string[x];
            for (int i = 0; i < x; i++)
            {
                s[i]=Console.ReadLine();
            }
            foreach (string v in s)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine(s[1]);
            string s1 = "nethaji";
            string s2 = s1.Substring(0, 3);
            Console.WriteLine(s2);
            string s3 = string.Concat(s1,s2);
            
            Console.WriteLine(s3);
        }
    }
}
