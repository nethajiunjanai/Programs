﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Globalization;

//namespace test
//{
//    class Program
//    {
//        static void Main()
//        {
//            string[] s = new string[5] { "5", "10-sep-2015", "10/09/2015", "15-nov-2015", "10-september-2015" };
//            // string date;
//            //  date = Console.ReadLine();          
//            DateTime dt;

//            //if (DateTime.TryParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture,
//            //    DateTimeStyles.None, out dt))
//            //{
//            //    Console.WriteLine(dt.ToShortDateString());
//            //}
//            //else
//            //{
//            //    Console.WriteLine("Enter valid date");
//            //}
//            string s1;
//            s[1]=String.Format("dd/MM/yyyy");
//            Console.WriteLine(s[1]);
//            for (int i = 0; i <= 4; i++)
//            {
//                if (DateTime.TryParseExact(s[i], "dd/MM/yyyy", CultureInfo.InvariantCulture,
//                    DateTimeStyles.None, out dt))
//                {
//                    Console.WriteLine(dt.ToShortDateString());
//                }
//                else
//                {
//                    Console.WriteLine("Enter valid date");
//                }
//            }
                
//        }
//    }
//}
