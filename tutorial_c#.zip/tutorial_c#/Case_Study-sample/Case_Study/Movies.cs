﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Case_Study
{

    // Movie Variables

    class Movies
    {
            public string movie_name;
            public string dir_name;
            public string act_name;
            //public string language;
            //public string Country;
            //public int duration;
        
    }
}
