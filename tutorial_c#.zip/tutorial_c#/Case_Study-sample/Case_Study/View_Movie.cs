﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Case_Study
{
    class View_Movie:Main_Pgm
    {
        public void view_all()
        {
            //View all Movie lists

            foreach (var val in li)
            {
                Console.WriteLine("Movie Name : "+val.movie_name);
                Console.WriteLine("Director name : "+val.dir_name);
                Console.WriteLine("Actor Name : "+val.act_name);
            }
        }

        public void viewamovie()
        {

            //View a single movie based on search

            string mvname;
            Console.WriteLine("Enter the movie name");
            mvname = Console.ReadLine();
            foreach (var val in li)
            {
                if (mvname == val.movie_name)
                {
                    Console.WriteLine("Movie Name : " + val.movie_name);
                    Console.WriteLine("Director name : " + val.dir_name);
                    Console.WriteLine("Actor Name : " + val.act_name);
                }
            }
        }
    }
}
