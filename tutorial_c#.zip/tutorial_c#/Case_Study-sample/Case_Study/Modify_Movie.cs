﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Case_Study
{
    class Modify_Movie:Main_Pgm
    {
        public Modify_Movie()
        {

            //Modify a movie detail

            string mvname;
            int no;
            
            Console.WriteLine("Enter a movie to modify");
            mvname = Console.ReadLine();

            foreach (var val in li)
            {
                if (mvname == val.movie_name)
                {
                    Console.WriteLine("1. Movie Name : " + val.movie_name);
                    Console.WriteLine("2. Director name : " + val.dir_name);
                    Console.WriteLine("3. Actor Name : " + val.act_name);
                    Console.Write("Enter the number to modify : ");
                    no = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the data");

                    if (no == 1)
                    {
                        val.movie_name = Console.ReadLine();
                    }

                    if (no == 2)
                    {
                        val.dir_name = Console.ReadLine();
                    }

                    if (no == 3)
                    {
                        val.act_name = Console.ReadLine();
                    }
                }
                
            }
            Console.WriteLine("Modified succesfully");
        }
    }
}
