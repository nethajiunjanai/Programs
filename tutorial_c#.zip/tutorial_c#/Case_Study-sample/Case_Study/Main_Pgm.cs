﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Case_Study
{
    class Main_Pgm
    {
        public static List<Movies> li = new List<Movies>();     
        
        public static void Main()
        {
            add_movie am = new add_movie();
            View_Movie vm = new View_Movie();
            
            string cw;
            Console.WriteLine("1.Add a Movie");
            Console.WriteLine("2.View all movies");
            Console.WriteLine("3.View a Movie"); 
            Console.WriteLine("4.Delete a movie");
            Console.WriteLine("5.Modify");

            do
            {
                int option;
                Console.WriteLine("Select an Option");
                option = int.Parse(Console.ReadLine());

                if (option == 1)
                { 
                    am.addition();
                }

                else if (option == 2)
                {   
                    vm.view_all();
                }

                else if (option == 3)
                {
                    vm.viewamovie();
                }

                else if (option == 4)
                {
                    Remove_movie rm = new Remove_movie();
                }

                else if (option == 5)
                {
                    Modify_Movie mm = new Modify_Movie();
                }
                else
                {
                    Console.WriteLine("Enter a valid option");
                }

                Console.WriteLine("Press any key to continue and N to close");
                cw = Console.ReadLine();
            } while (cw != "N");
        }
    }
}
