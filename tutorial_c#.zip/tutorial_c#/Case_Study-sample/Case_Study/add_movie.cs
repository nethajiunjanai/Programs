﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Case_Study
{
    class add_movie:Main_Pgm
    {
        //Adding Movies to list

        public void addition()
        {
            Movies m;
            int no;
            Console.WriteLine("Enter the number of movies to be added");
            no = int.Parse(Console.ReadLine());
            for (int i = 0; i < no; i++)
            {
                m = null;
                m = new Movies();
                Console.Write("Enter the movie name : ");
                m.movie_name = Console.ReadLine();
                Console.Write("Enter Director name : ");
                m.dir_name = Console.ReadLine();
                Console.Write("Enter Actor name : ");
                m.act_name = Console.ReadLine();
                li.Add(m);
            }

            Console.WriteLine("Movie Succesfully added");
            
            
        }

    }
}


            