﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Case_Study
{
    class Remove_movie:Main_Pgm
    {
        // Delete a movie from the list


        public Remove_movie()
        {
            string mvname;
            int count = 0;
            int count1 = 0;
            Console.WriteLine("Enter the movies to be deleted");
            mvname = Console.ReadLine();

            foreach (var val in li)
            {                
                if (mvname == val.movie_name)
                {
                    count1 = count;
                }
                count++;
            }
            li.RemoveAt(count1);
            Console.WriteLine("Movie removed successfully");
        }
    }
}
