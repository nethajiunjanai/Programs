﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//{
//    class ipl
//    {
//        string mat, t1, t2;
//        public void match()
//        {
//            Console.WriteLine("enter the match number");
//            mat = (Console.ReadLine());
//            t1 = (Console.ReadLine());
//            t2 = (Console.ReadLine());
//            if (mat == "1")
//            {
//                Console.WriteLine("match");
//                show();
//            }
//            else if (mat == "2")
//            {
//                Console.WriteLine("match");
//                show();
//            }
//            else if (mat == "3")
//            {
//                Console.WriteLine("match");
//                show();
//            }
//        }
//        public void show()
//        {
//            Console.WriteLine("{0} vs {1}", t1, t2);
//        }
//    }
//    class resu : ipl
//    {
//        public void res()
//        {
//            Console.WriteLine("kkr wins the match");
//        }
//        public static void Main()
//        {
//            resu d = new resu();
//            d.match();
//            d.res();
//        }
//    }
//}
