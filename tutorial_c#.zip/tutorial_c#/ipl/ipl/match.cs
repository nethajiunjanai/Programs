﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ipl
//{
//    class match
//    {
//        public int option;
//        public void select()
//        {         
//            Console.WriteLine("WELCOME\n1.Add Match Details\n2.Modify Match Details\n3.Search Match\n4.Delete Match\n5.Display Match Details\n6.Exit");            
//            Console.WriteLine("Enter your option:");
//             option = int.Parse(Console.ReadLine());          
//        }       
//    }
//    class valid:match
//    {
//        public void operation()
//        {
//            if (option == 1)
//            {
//                add();
//            }
//            if (option == 2)
//            {
//                modify();
//            }
//            if (option == 3)
//            {
//                search();
//            }
//            if (option == 4)
//            {
//                delete();
//            }
//            if (option == 5)
//            {
//                dispaly();
//            }
//            if (option == 6)
//            {
//                exit();
//            }
//            else
//            {
//                Console.WriteLine("Enter the valid option");
//            }
//        }
        public static void Main()
        {
            valid v = new valid();
            v.select();
            v.operation();
        }
//    }
//}
