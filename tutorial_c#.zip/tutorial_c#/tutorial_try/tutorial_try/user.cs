﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//{
//    class user
//    {
//        private int uid;
//        private string uname;
//        private DateTime doj;
//        public int UID { get; set; }
//        public string UNAME { get; set; }
//        public DateTime DOJ { get; set; }
//        public user(int UID, string UNAME, DateTime DOJ)
//    {
//        this.UID=UID;
//        this.UNAME=UNAME;
//        this.DOJ=DOJ;
//    }
//    }
//}
