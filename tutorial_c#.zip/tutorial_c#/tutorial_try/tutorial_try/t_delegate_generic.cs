﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;

//namespace tutorial_try
// //   delegate generic
//{
//    public delegate void del<T1, T2>(T1 a, T2 b);
//    class gendel
//    {
//        public void add(int a, int b)
//        {
//            Console.WriteLine(a + b);
//        }
//        public void mul(int a, int b)
//        {
//            Console.WriteLine(a * b);
//        }
//        public static void Main()
//        {
//            gendel g = new gendel();
//            //  g.add(1, 2);
//            //  g.mul(2, 3);
//            del<int, int> g1 = new del<int, int>(g.add);
//            g1(1, 2);
//            g1 += new del<int, int>(g.mul);
//            g1(2, 3);
//        }
//    }
    
//}
