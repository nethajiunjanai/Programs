﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//    //user defined exception
//{
//    public class vote:Exception
//    {
//        public string diserror()
//        {
//            return "you are not eligible for voting";
//        }
        
//    }
//    public class userdef
//    {
//        int age;       
//        void verifyage()
//        {
//            if (age < 18)
//            {
//                throw new vote();
//            }
//            else
//            {
//                Console.WriteLine("eligible");
//            }
//        }
//        public static void Main()
//        {
//            userdef ud = new userdef();
//            ud.age = int.Parse(Console.ReadLine());
//            try
//            {
//                ud.verifyage();
//            }
//            catch (vote v)
//            {
//                Console.WriteLine(v.diserror());
//            }
//        }
//    }
//}
     