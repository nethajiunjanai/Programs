﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
////exception Handling
//{
//    class excptn
//    {


//        public static void Main()
//        {
//            int z = 0, x = 0, y = 0;


//            try
//            {
//                x = int.Parse(Console.ReadLine());
//                y = int.Parse(Console.ReadLine());
//                z = x / y;
//                Console.WriteLine("value " + z);
//            }

//            catch (DivideByZeroException e)
//            {
//                Console.WriteLine("plz provide non zero value");

//                x = int.Parse(Console.ReadLine());
//                y = int.Parse(Console.ReadLine());
//                z = x / y;
//                Console.WriteLine("value " + z);
//                //try
//                //{
//                //    x = int.Parse(Console.ReadLine());
//                //    y = int.Parse(Console.ReadLine());
//                //    z = x / y;
//                //    Console.WriteLine("value " + z);
//                //}
//                //catch (DivideByZeroException g)
//                //{
//                //    Console.WriteLine("plz provide non zero value");

//                //    x = int.Parse(Console.ReadLine());
//                //    y = int.Parse(Console.ReadLine());
//                //    z = x / y;
//                //    Console.WriteLine("value " + z);

//                //Console.WriteLine(e.Message);
//                //Console.WriteLine(e.TargetSite);
//                //Console.WriteLine(e.HelpLink);
//                // Console.WriteLine(e.StackTrace);
//                //Console.WriteLine(e.Source);
//            }
//            catch (FormatException f)
//            {
//                Console.WriteLine("enter the  integer " + f.Message);
//            }
//            catch (Exception m)
//            {
//                Console.WriteLine(m.Message);
//            }
//            finally
//            {
//                try
//                {
//                    x = int.Parse(Console.ReadLine());
//                    y = int.Parse(Console.ReadLine());
//                    z = x / y;
//                    Console.WriteLine(" sec value " + z);
//                }
//                catch (DivideByZeroException g)
//                {
//                    Console.WriteLine("plz provide non zero value");

//                    x = int.Parse(Console.ReadLine());
//                    y = int.Parse(Console.ReadLine());
//                    z = x / y;
//                    Console.WriteLine("value " + z);

//                    //Console.WriteLine(e.Message);
//                    //Console.WriteLine(e.TargetSite);
//                    //Console.WriteLine(e.HelpLink);
//                    // Console.WriteLine(e.StackTrace);
//                    //Console.WriteLine(e.Source);
//                }
//                Console.WriteLine("thanks");
//            }
//        }
//    }
//}

