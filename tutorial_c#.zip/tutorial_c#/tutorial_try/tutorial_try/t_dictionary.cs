﻿////using System;
////using System.Collections.Generic;
////using System.Linq;
////using System.Text;

////namespace tutorial_try
//////dictionary
////{
////    class dic
////    {
////        public static void Main()
////        {
////            Dictionary<int, string> d = new Dictionary<int, string>();
////            d.Add(5, "arun");
////            d.Add(1, "raj");
////            d.Add(2, "siva");
////            Console.WriteLine(d.Count);
////            Console.WriteLine(d[1]);

////            foreach (KeyValuePair<int, string> kvp in d)
////            {
////                Console.WriteLine(kvp.Key + kvp.Value);
////            }
////            //sorted list and sorted dictionary is similar to this but it will shows in ascending order
////            //sorted list is faster than sorted dictionary
////        }
////    }
////    //class sorli
////    //{
////    //    public static void Main()
////    //    {
////    //        SortedList<int, string> s = new SortedList<int, string>();
////    //        s.Add(5, "arun");
////    //        s.Add(1, "raj");
////    //        s.Add(2, "siva");
////    //        Console.WriteLine(s.Count);
////    //        Console.WriteLine(s[1]);
////    //        //foreach (KeyValuePair<int, string> kvp in s)
////    //        //{
////    //        //    Console.WriteLine(kvp.Key + kvp.Value);
////    //        //}
////    //        List<int> l = new List<int>(s.Keys);
////    //        foreach (int i in l)
////    //        {
////    //            Console.WriteLine(i
////    //            + s[i]);
////    //        }

////    //    }
////    //}
////}
