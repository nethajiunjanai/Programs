﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Collections;

//namespace tutorial_try
//    //collection-queue
//{
//    class que
//    {
//        public static void Main()
//        {
//        Queue q = new Queue();
//        q.Enqueue("wel");
//        q.Enqueue(20);
//        Console.WriteLine(q.Peek());
//        q.Dequeue();
//        foreach (object ob in q)
//        {
//            Console.WriteLine(ob);
//        }
//        }
//    }
//}
