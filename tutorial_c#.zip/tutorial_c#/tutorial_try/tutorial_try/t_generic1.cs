﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//namespace ConsoleApplication1
//{
//    //GENERIC METHOD FOR CLASS


//    public class gen2<U>
//    {
//        public U data1;

//        //constructor


//        public gen2(U data1)
//        {
//            this.data1 = data1;
//        }
//        public void display()
//        {
//            Console.WriteLine("the output is :{0}",data1);
//        }
        
//    }
//    public class gen3
//    {
//        public static void Main()
//        {
//            gen2<int> g1 = new gen2<int>(5);
//            g1.display();
//            gen2<string> g2 = new gen2<string>("gen");
//            g2.display();
//        }
//    }
//} 
