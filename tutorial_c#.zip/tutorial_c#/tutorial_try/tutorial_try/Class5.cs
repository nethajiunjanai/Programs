﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//    //structure
//{
//    public struct match
//    { 
//      public  string team1;
//      public string team2;
//      public string umpires;
//      public string result;
//    };
     
//    class strctr 
//    {
//        public static void Main()
//        {
//            match m1;
//            m1.team1 = "kkr";
//            m1.team2 = "rr";
//            m1.umpires = "bowden,dar";
//            m1.result = "kkr won";
//            Console.WriteLine("team1 is",m1.team1);
//            Console.WriteLine(m1.team2);
//            Console.WriteLine(m1.umpires);
//            Console.WriteLine(m1.result);
//            match m2;
//            m2.team1 = "mi";
//            m2.team2 = "csk";
//            m2.umpires = "bowden,dar";
//            m2.result = "csk won";
//            Console.WriteLine(m2.team1);
//            Console.WriteLine(m2.team2);
//            Console.WriteLine(m2.umpires);
//            Console.WriteLine(m2.result);
        
        

//        }
    
        
//    }
//}

