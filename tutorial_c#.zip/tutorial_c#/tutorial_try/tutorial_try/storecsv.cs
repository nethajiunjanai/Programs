﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;
//using System.Globalization;

//namespace tutorial_try
//{
//    class storecsv
//    {
//        List<user> us;
//        public storecsv()
//        {
//            us = new List<user>();
//        }

//        public void storedata()
//        {
//            if (us == null)
//            {
//                Console.WriteLine("enter the user details");
//                Console.WriteLine("enter the uid");
//                int id = int.Parse(Console.ReadLine());
//                Console.WriteLine("enter the name");
//                string name = Console.ReadLine();
//                DateTime dt;
//                while (1 == 1)
//                {
//                    Console.WriteLine("enter the doj in the form dd/mm/yyyy");
//                    string data = Console.ReadLine();

//                    bool b = DateTime.TryParseExact(data, "d/M/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt);
//                    if (b == true)
//                    {
//                        break;
//                    }
//                    else
//                    {
//                        Console.WriteLine("invalid");
//                    }
//                }

//                //  us.Add(new user(id, name, dt));
//                user ui = new user(id, name, dt);
//                us.Add(ui);
//            }
//        }
//        public void save()
//        {
//            FileStream fs;
//            StreamWriter sw;
//            if (!File.Exists(@"D:\netha\user.csv"))
//            {
//                fs = new FileStream(@"D:\netha\user.csv", FileMode.CreateNew, FileAccess.Write, FileShare.None);
//                sw = new StreamWriter(fs);
//                sw.WriteLine("uid,uname,doj");
//            }
//            else
//            {
//                fs = new FileStream(@"D:\netha\user.csv", FileMode.Append, FileAccess.Write);
//                sw = new StreamWriter(fs);
//            }
//            foreach (user u in us)
//            {
//                string[] values = new string[3] { u.UID.ToString(), u.UNAME, u.DOJ.ToShortDateString() };
//                string lastdata = string.Join(",", values);
//                sw.WriteLine(lastdata);
//            }
//            sw.Close();
//            us = null;
//        }
//            public static void Main()
//            {
//                storecsv s=new storecsv();
//                s.storedata();
//                s.storedata();
//                s.save();
//            }
//        }
        
//    }

