﻿//using System;

//namespace Delegates
//{
//    public delegate void handle();

//    class Program
//    {
//        public static event handle add;

//        static void Main(string[] args)
//        {
//            add += new handle(USA);
//            //   add += new handle(India);
//            //   add += new handle(England);
//            //use this function .invoke

//            add.Invoke();

//            Console.ReadLine();
//        }
//        static void USA()
//        {
//            Console.WriteLine("USA");
//        }

//        //static void India()
//        //{
//        //    Console.WriteLine("India");
//        //}

//        //static void England()
//        //{
//        //    Console.WriteLine("England");
//        //}
//    }
//}