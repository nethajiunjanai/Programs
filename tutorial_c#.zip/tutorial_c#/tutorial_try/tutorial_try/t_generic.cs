﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
////generic example
//{
//    class gen
//    {
//        public void show<T>(T data)
//        {
//            Console.WriteLine("value is" + data);
//        }
//        public static void Main()
//        {
//            gen g = new gen();
//            g.show(2);
//            g.show("ne");
//            g.show(true);
//            g.show('c');
//            g.show(10.32);
//        }
//    }
//}
