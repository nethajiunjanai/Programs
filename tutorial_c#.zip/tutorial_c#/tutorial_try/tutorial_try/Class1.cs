﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace tutorial_try
{
    class Class1
    {
        public static void Main()
        {
            string str;
            str = "B009";
            
            string str1 = str.Substring(3, 1);
            int i = int.Parse(str1);
            if (i < 9)
            {       
               i = i + 1;
                string s1 = i.ToString();
                s1 = string.Concat("B00", s1);
                Console.WriteLine(s1);
            }
            else if(i>=9)
            {
                i = i + 1;
                string s1 = i.ToString();
                s1 = string.Concat("B0", s1);
                Console.WriteLine(s1);
            }
            else if (i > 99)
            {
                i = i + 1;
                string s1 = i.ToString();
                s1 = string.Concat("B", s1);
                Console.WriteLine(s1);
            }
            Console.WriteLine(str);
          ///  textBox1.Text = s1;
            //textBox1.Enabled = false;
        }
    }
}
