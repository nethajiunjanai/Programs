﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
////inheritance and interface
////interfaces--->mulitple inheritance cannot be used in c# so we go for interface
//{

//    class iface
//    {
//        public int hei;
//        public int wid;
//        public int ar;
//        public int r;
//        public void data(int h, int w)
//        {
//            hei = h;
//            wid = w;
//        }
//    }
//    public interface ifac
//    //empty method.we can create many methods and use it in same name
//    {
//        void a1();
//    }
//    class area : iface, ifac
//    {
//        public void a()
//        {
//            ar = (hei * wid);

//        }
//        public  virtual void a1()
//        {
//            r = 10;
//        }
//    }
//    class rr : area//virtual overriding 
//    {
//        public  override void a1()
//        {
//            r = 12;
//        }
//    }
//    class neww:rr
//    {
//        public override void a1()        
//       {
//        r = 14;
//       }
    

//        public static void Main()
//        {
//            area ob = new area(); 
//            rr ob1 = new rr();
//            neww ob2 = new neww();   
//           // ob1 = new area();
                   
//            ob.data(2, 3);
//            ob.a();
//            ob.a1();
//            ob1.a1();
//            ob2.a1();
//            Console.WriteLine(+ob.ar);
//            Console.WriteLine(+ob.r);
//            Console.WriteLine(+ob1.r);
//            Console.WriteLine(+ob2.r);
//        }
//    }

//}
  
