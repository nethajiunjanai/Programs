﻿//using System;
//namespace StringApplication
//{
//    class StringProg
//    {
//        static void Main(string[] args)
//        {
//            string str;
//            Console.WriteLine("string");
//            str = Console.ReadLine();
//            Console.WriteLine("key");
//            string t;
//            t = Console.ReadLine();

//            if (str.Contains(t))
//            {
//                Console.WriteLine("The sequence was found.");
//            }
//            else
//            {
//                Console.WriteLine("The sequence was not found.");
//                string sub = str.Substring(2);
//                Console.WriteLine( sub);
//            }
//            Console.ReadKey();
//        }
//    }
//}