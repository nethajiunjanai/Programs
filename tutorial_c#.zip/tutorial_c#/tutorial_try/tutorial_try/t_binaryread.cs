﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;

//namespace tutorial_try
//    //binary reader
//{
//    class binread
//    {
//        public static void Main()
//        {
//            FileStream fs = new FileStream(@"D:\netha\demo1.txt", FileMode.Open, FileAccess.Read, FileShare.None);
//            BinaryReader br = new BinaryReader(fs);
//            string name = br.ReadString();
//          //  Console.WriteLine(name);
//            int agee = br.ReadInt32();
//          Console.WriteLine(agee);
//            string job = br.ReadString();
//            //Console.WriteLine(job);
//           // br.Close();
//        }
//    }
//}
