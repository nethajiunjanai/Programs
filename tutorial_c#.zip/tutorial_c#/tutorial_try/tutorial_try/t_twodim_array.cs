﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//namespace tutorial_try
    //array and a
//{
  //  single dimension array
//class arry
//{
//    int[] arr = new int[4] { 1, 2, 3, 4 };
     
//    //arr[0]=10;
//    //arr[1]=20;
//    public static void Main()
//    {
//        int i;
//        arry a = new arry();
       
//        for (i = 0; i < 4; i++)
//        {
//            Console.WriteLine(+a.arr[i]);
//        }
//        //Array.Reverse(a.arr);
//        Array.Sort(a.arr);
//        for (i = 0; i < 4; i++)
//        {
//            Console.WriteLine(+a.arr[i]);
//        }
//        Console.WriteLine();
//    }

    //}
    //class twod
    //{
    //    int[,] arr = new int[2, 3] { { 1, 2, 3 }, { 4, 5, 6 } };
    //    public static void Main()
    //    {
    //        twod a = new twod();
    //        Console.WriteLine(a.arr[1,2]);//will access  2nd set's 3rd element
    //    }

    //}
    //two dimension array

    //class arry
    //{
    //    int[,] arr = new int[2, 3] { { 1, 2, 3 }, { 4, 5, 6 } };
    //    int i;

    //    public static void Main()
    //    {
    //        int j = 0,k=1;
    //        arry a = new arry();
    //        for (a.i = 0; a.i <= a.arr.GetUpperBound(1); a.i++)
    //        {
    //            Console.WriteLine(+a.arr[j, a.i]);              
    //            Console.WriteLine(+a.arr[k, a.i]);
               
    //        }
    //    }
    //}
//    class arry
//    {
//        public static void Main()
//        {
//            int[,] arr = new int[2, 3] { { 1, 2, 3 }, { 4, 5, 6 } };
//            int i;
//            int j;
//            for(i=0;i<2;i++)
//            {
//                for (j = 0; j <3; j++)
//                {
//                    Console.WriteLine(+arr[i, j]);
//                }
//            }
//        }
//    }
//}
