﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Collections;

//namespace tutorial_try
//    //collection-hashtable
//{
//    class hash
//    {
//        public static void Main()
//        {
//            Hashtable h = new Hashtable();
//            h.Add("hi", "welcome");
//            h.Add(622150, "nethaji");
//            h.Add("nethaji", "be");
//            h.Add("hii", "dup");
//            Console.WriteLine(h.Count);
//           // h.Clear();
//           // Console.WriteLine(h.Count);
//            Console.WriteLine(h.ContainsKey("hi"));
//            Console.WriteLine(h.ContainsValue("be"));
//            Console.WriteLine(h.ContainsValue("bee"));
//            Console.WriteLine(h[622150]);
//            ICollection ic = h.Keys;
//            foreach (object o in ic)
//            {
//                Console.WriteLine(h[o]);
//            }
//        }
//    }
//}
