﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//{
//    class rectangle
//    {
//        int x,y,z;
//        public void accept()
//        {
//            x=int.Parse(Console.ReadLine());
//            y = int.Parse(Console.ReadLine());
//            //x=20;
//           // y = 21;
//        }s
//        public void area()
//        {
//            z = x * y;
//            Console.WriteLine(+z);
//        }
//        static void Main(string[] args)
//        {
//            rectangle r = new rectangle();
//            r.accept();
//            r.area();
//        }
//    }
//}
