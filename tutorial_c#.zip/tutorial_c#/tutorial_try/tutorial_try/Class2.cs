﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//{
//    class maxno
//    {
//        int a, b,r;
        
//        public void res()
//        {
//            a=int.Parse(Console.ReadLine());
//            b=int.Parse(Console.ReadLine());
//            if (a > b)
//                r = a;
//            else
//                r = b;
//            Console.WriteLine(+r);
//        }
//    //}
//    // class new_cl
//    //{
//        public static void Main()
//        {
//            maxno m = new maxno();
//            m.res();
//        }
     
//    }
//}
