﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//    //generic in class
//{
//    public class gencls<u>
//    {
//        public u data1;
//        public gencls(u data1)
//        {
//            this.data1 = data1;
//        }
//        public void display()
//        {
//            Console.WriteLine("output is"+data1);
//        }
//    }
//    public class anot
//    {
//        public static void Main()
//        {
//            gencls<int> g = new gencls<int>(5);
//            g.display();
//            gencls<string> h = new gencls<string>("s5");
//            h.display();
//        }
//    }
//}
