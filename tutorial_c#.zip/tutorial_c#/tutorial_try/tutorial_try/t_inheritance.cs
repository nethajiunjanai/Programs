﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//    //this is for inheritance
//{
//    class inher
//    {
//        public int w;
//        public int h;
//        public int ar;
//        public void data()
//        {
//            w = 5;
//            h = 2;
            
//        }
//        public void res()
//        {
//            ar = h * w;
//            //return ar;
//            Console.WriteLine(+ar);
//        }

//    }
//    class rel : inher
//    {
//        public static void Main()
//        {
//            inher i = new inher();
//            i.data();
//            i.res();
            
            
//            Console.WriteLine(+i.ar);
//        }
//    }
//}
