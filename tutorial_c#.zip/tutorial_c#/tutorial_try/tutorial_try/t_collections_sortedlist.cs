﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Collections;

//namespace tutorial_try
////collection-sortedlsit
//{
//    class sortl
//    {
//        public static void Main()
//        {
//            SortedList l = new SortedList();
//            l.Add("hi", "welcome");
//            l.Add("150", "nethaji");
//            l.Add("nethaji", "be");
//            l.Add("hii", "dup");
//            Console.WriteLine(l.Count);
//            // h.Clear();
//            // Console.WriteLine(h.Count);
//            Console.WriteLine(l.ContainsKey("hi"));
//            Console.WriteLine(l.ContainsValue("be"));
//            Console.WriteLine(l.ContainsValue("bee"));
//            Console.WriteLine(l["150"]);
//            ICollection ic = l.Keys;
//            foreach (object o in ic)
//            {
//                Console.WriteLine(l[o]);
//            }
//        }
//    }
//}
