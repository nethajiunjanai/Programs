﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Collections;

//namespace tutorial_try
//    //collections stack
//{
//    class stck
//    {
//        public static void Main()
//        {
//            Stack s = new Stack();
//            s.Push("welcome");
//            s.Push(20);
//            s.Push("end");
//            Console.WriteLine(s.Count);     
//            object res = s.Pop();
//            Console.WriteLine(res);
//            Console.WriteLine(s.Peek());
//            foreach (object o in s)
//            {
//                Console.WriteLine(o);
//            }
//        }
//    }
//}
