﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace tutorial_try
{
    class typecast
    {
    
        //public static void Main()
        //{
        //char[] chars = { 'a', ' ','s','t','r','i','n','g' };
        //string s = string.Join("",chars);
        //Console.WriteLine(s);
        //    string[] sa=new string[]{"Wea","cas"};
        //    string ss = string.Join("",sa);
        //    Console.WriteLine(ss);
        //}
    }
}
