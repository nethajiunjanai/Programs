﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;


//namespace tutorial_try
//    //generic collections
//{
//    class emp
//    {
//        public int eid;
//        public string ename;
//        public double sal;
//    }
//    class gencol
//    {
//        public static void Main()
//        {
//            List<int> l = new List<int>();
//            l.Add(1);
//            l.Add(2);
//            l.Add(3);
//            Console.WriteLine(l.Count);
//         //   foreach (object o in l)
//           foreach (int  i in l)
//            {
//                Console.WriteLine("number is:"+i);
//            }
//           emp e1 = new emp();
//           e1.eid = 1;
//           e1.ename = "Nethaji";
//           e1.sal = 2000.23;
//           emp e2 = new emp();
//           e2.eid = 2;
//           e2.ename = "Netha";
//           e2.sal = 4000.23;
//           emp e3 = new emp();
//           e3.eid = 3;
//           e3.ename = "vikky";
//           e3.sal = 4000.33;
//           List<emp> l1 = new List<emp>();
//           l1.Add(e1);
//           l1.Add(e2);
//           l1.Add(e3);
//           foreach (emp e in l1)
//           {
//               Console.WriteLine("eid:{0},ename {1},esal {2}",e.eid,e.ename,e.sal);
//           }
//        }
        
//    }
//}
