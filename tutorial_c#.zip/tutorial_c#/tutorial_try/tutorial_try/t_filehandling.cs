﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;

//namespace tutorial_try
//    //file handling---->drives-->create folders using c#
//{
//    class file
//    {
//        public static void Main()
//        {
//            //DriveInfo[] di = DriveInfo.GetDrives();
//            //foreach (DriveInfo d in di)
//            //{
//            //    Console.WriteLine(d.Name);
//            //   // Console.WriteLine(d.AvailableFreeSpace);
//            //    DirectoryInfo d1 = new DirectoryInfo("D:\\netha");
//            //    //DirectoryInfo d1 = new DirectoryInfo(@"D:\nethaji");
//            //    d1.Create();
//            //}


//             FileStream fs = new FileStream(@"D:\netha\demo.txt", FileMode.Append, FileAccess.Write, FileShare.None);
//             StreamWriter sw = new StreamWriter(fs);
//             StreamReader sr = new StreamReader(fs);
//             sr.ReadLine();
//             Console.WriteLin
//             string  s = Console.ReadLine();
//             if (s == "data")
//             {
//                 string s1;
//                 s1 = Console.ReadLine();
//                 sw.WriteLine("first line date");
//                 sw.WriteLine(s1);
//                 sw.Close();
                 
//             }
//             else
//             {
//                 sw.WriteLine("else");
//                 sw.WriteLine("part");
//                 sw.Close();
//             }
//            //fs.Close();
          


//        }
//    }
//}
