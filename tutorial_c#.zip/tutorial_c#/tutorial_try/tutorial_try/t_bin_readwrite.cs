﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;

//namespace tutorial_try
//    //binary reader and writer
//{
//    class binr
//    {
//        public static void Main()
//        {
//            FileStream fs=new FileStream(@"D:\netha\demo1.txt", FileMode.Open,FileAccess.ReadWrite, FileShare.None);
//            string ename="karthi";
//            int age=65;
//            string designation="HR";
//            BinaryWriter bw=new BinaryWriter(fs);
//            bw.Write(ename);
//            bw.Write(age);
//            bw.Write(designation);
//            bw.Close();

//        }

//    }
//}
