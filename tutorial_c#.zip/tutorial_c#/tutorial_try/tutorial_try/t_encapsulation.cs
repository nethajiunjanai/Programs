﻿
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
////This is encapsulation sample.
////See two different classes are used and variables are accessed as they are public in nature.
////If we remove key "public" from any one of the methods..error will be displayed due to security of variable.
//namespace tutorial_try
//{
//    class rectangle
//    {
//        int x,y,z;
//        public void accept()
//        {
//            x=int.Parse(Console.ReadLine());
//            y = int.Parse(Console.ReadLine());
//            //x=20;
//           // y = 21;
//        }
//      public   void area()
//        {
//            z = x * y;
//            Console.WriteLine(+z);
//        }
//    }
//    class rect_result
//    {
//        static void Main(string[] args)
//        {
//            rectangle r = new rectangle();
//            r.accept();
//            r.area();
//        }
//    }
//}

