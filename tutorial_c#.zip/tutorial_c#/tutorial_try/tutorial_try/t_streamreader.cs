﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;

//namespace tutorial_try
//{
//    class ant
//    {public static void Main()
//    {
//        FileStream fs = new FileStream(@"D:\netha\demo.txt", FileMode.Open, FileAccess.Read, FileShare.None);
            
//             StreamReader sr = new StreamReader(fs);
//            string s= sr.ReadLine();
//            while ((s = sr.ReadLine()) != null)
//            {

//                Console.WriteLine(s);
//            }
        
//    }
//    }
//}
