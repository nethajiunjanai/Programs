﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
////main purpose of delegate is associated with events when we call events it will call delegate and it will call method.
////events cannot work without delegate
////delegates event needs atleast two classes(not mandatory)
//{

//    public delegate void winprice();
//    //this is the publisher class
//    class publish
//    {
//        static int count;
//        //declaring the event
//        public event winprice vuser;//we can use this event for calling.
//        public void purchase()
//        {
//            count++;
//            Console.WriteLine("Thanks for purchasing the product");
//            if (count % 3 == 0)
//            {
//                vuser.Invoke();
//                //invoke is a inbuilt option for invoking-Raise the event
//            }
//        }

//    }
//    class shopping
//    {
//        public static void greeting()
//        {
//            Console.WriteLine("lucky man");
//        }
//        public static void Main()
//        {
//            int choice;
//            publish p = new publish();
//            p.vuser += new winprice(greeting);
//            do
//            {
//                p.purchase();
//                Console.WriteLine("do u want to continue? yes-1 2-no");
//                choice = int.Parse(Console.ReadLine());
//            } while (choice == 1);
//        }
//    }
//}
