﻿using System;

//class Program
//{
//    static void Main()
//    {
//        //DateTime time = DateTime.Now;             // Use current time.
//        //string format = "MMM ddd d HH:mm yyyy";   // Use this format.
//        //Console.WriteLine(time.ToString(format));
//        //Console.WriteLine(time.ToString("d"));
//            // Write to console.
//        //MMM-month name
//        //M-month in num
//        //ddd-day name of the week
//        //d-day of month
        //different types of formatting
        //  DateTime now = DateTime.Now;
        //Console.WriteLine(now.ToString("d"));
        //Console.WriteLine(now.ToString("D"));
        //Console.WriteLine(now.ToString("f"));
        //Console.WriteLine(now.ToString("F"));
        //Console.WriteLine(now.ToString("g"));
        //Console.WriteLine(now.ToString("G"));
        //Console.WriteLine(now.ToString("m"));
        //Console.WriteLine(now.ToString("M"));
        //Console.WriteLine(now.ToString("o"));
        //Console.WriteLine(now.ToString("O"));
        //Console.WriteLine(now.ToString("s"));
        //Console.WriteLine(now.ToString("t"));
        //Console.WriteLine(now.ToString("T"));
        //Console.WriteLine(now.ToString("u"));
        //Console.WriteLine(now.ToString("U"));
        //Console.WriteLine(now.ToString("y"));
        //Console.WriteLine(now.ToString("Y"));
//        DateTime fromDateValue;
        
//        string s = "15/07/2012";
//        var formats = new[] { "dd/MM/yyyy", "yyyy-MM-dd" };
//        if (DateTime.TryParseExact(s, formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out fromDateValue))
//        {
//            // do for valid date
//            Console.WriteLine("a");
//        }
//        else
//        {
//            // do for invalid date
//            Console.WriteLine("b");
//        }

//    }
//}

