﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.IO;
//namespace tutorial_try
//{
//    //delegate
//    //want to show op without using that method name(showoutput)-we are using delegate
//    //can declare any where outside or inside of the class
//    //cannot refer delegate through object
//    public delegate void call();
//     public delegate void compute(int val1,int val2);
//    class delg
//    { 
//        public void showoutput()
//        {
//            Console.WriteLine("this is from op method");

//        }
//        public void add(int x, int y)
//        {
//            Console.WriteLine(x+y);
//        }
//        public void multiply(int a, int b)
//       {
//        Console.WriteLine(a*b);
//       }
        
//        public static void Main()
//        {
//            delg d = new delg();
//         //   d.showoutput();
//            //calling using delegate object
//            call c1 = new call(d.showoutput);
//            c1 += new call(d.showoutput);
//            c1 += new call(d.showoutput);
//            c1();
//           // d.add(2, 3);
//            compute c = new compute(d.add);
//            c(5, 10);
//            c = new compute(d.multiply);
//            c(2, 3);
//            //stores the previous address also(+=)
//            c += new compute(d.multiply);
//            c(3, 4);
            
//        }
//    }
//}
