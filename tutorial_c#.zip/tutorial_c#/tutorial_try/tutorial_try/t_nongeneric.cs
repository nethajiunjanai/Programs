﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//    //nongeneric example
//{
//    class nongen
//    {
//        public void show( int data)
//        {
//            Console.WriteLine("value is"+data);

//        }
//        public void show(string str)
//        {
//            Console.WriteLine("value is" +str);
//        }
//        public static void Main()
//        {
//            nongen o = new nongen();
//            o.show(12);
//            o.show("net");
//        }

//    }
//}
