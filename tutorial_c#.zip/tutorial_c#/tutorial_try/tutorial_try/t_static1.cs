﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace tutorial_try
//    //this is for static variable-statickeyword
//{
//    class stat
//    {
//        static int info;
//        public int another;
//        public void change()
//        {
//            info++;
//            another++;
//        }
//        public void disp()
//        {
//            Console.WriteLine("info"+info);
//            Console.WriteLine("another"+another);
//        }
//        public static void Main()
//        {
//            stat s1 = new stat();
//            stat s2 = new stat();
//            //static var cannot be called using object and we have to use  class name for accessing.
//            s1.change();
//            s2.change();
//            s1.change();           
//            s1.disp();
//            s2.disp();
//        }
//    }
//}
