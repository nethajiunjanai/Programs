﻿

//using System;
//namespace PolymorphismApplication
//{
//    abstract class Shape
//    {
//        public abstract void area();
//    }
//    class Rectangle : Shape
//    {
//        private int length;
//        private int width;
//        public int re;
//        public void Rect()
//        {
//            length = 10;
//            width = 3;

//        }
//        public override void area()
//        {
//            Console.WriteLine("Rectangle class area :");
//            re = length * width;
//        }

//    }
//    class another : Shape
//    {
//        public override void area()
//        {
//            Console.WriteLine("Rectangle class  :");

//        }


//        static void Main(string[] args)
//        {
//            Rectangle r = new Rectangle();
//            r.Rect();
//            r.area();
//            another d = new another();
//            d.area();
//            Console.WriteLine("Area: {0}", r.re);
//            Console.ReadKey();
//        }
//    }
//}