﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace iplcase
//{
//    class match
//    {
//        public int mid;
//        public string team1;
//        public string team2;
//        public string uname;
//        public string result;

//    }
//    class action
//    {
//        public static List<match> mat = new List<match>();
//        public static void Main()
//        {

//            match m;
//            // m.mid = 1;
//            int i;

//            for (i = 0; i <= 1; i++)
//            {
//                m = null;
//                m = new match();
//                Console.WriteLine("Matchid");
//                m.mid = int.Parse(Console.ReadLine());
//                Console.WriteLine("team1");
//                m.team1 = Console.ReadLine();
//                Console.WriteLine("team2");
//                m.team2 = Console.ReadLine();
//                Console.WriteLine("umpires");
//                m.uname = Console.ReadLine();
//                Console.WriteLine("result");
//                m.result = Console.ReadLine();
//                mat.Add(m);
//            }
//            Console.WriteLine("added");
//            Console.WriteLine("id");
//            int id = int.Parse(Console.ReadLine());
//            //modify           
//            foreach (var v in mat)
//            {


//                if (id == v.mid)
//                {
//                    Console.WriteLine("Enter the modified details");
//                    Console.WriteLine("Matchid");
//                    v.mid = int.Parse(Console.ReadLine());
//                    Console.WriteLine("team1");
//                    v.team1 = Console.ReadLine();
//                    Console.WriteLine("team2");
//                    v.team2 = Console.ReadLine();
//                    Console.WriteLine("umpires");
//                    v.uname = Console.ReadLine();
//                    Console.WriteLine("result");
//                    v.result = Console.ReadLine();
//                    Console.WriteLine("modified");
//                }
//            }
//            //show
//            foreach (var v in mat)
//            {
//                Console.WriteLine("Matchid:" + v.mid);
//                Console.WriteLine("team1:" + v.team1);
//                Console.WriteLine("team2:" + v.team2);
//                Console.WriteLine("umpires:" + v.uname);
//                Console.WriteLine("result:" + v.result);
//            }
//            //delete
//            int del = int.Parse(Console.ReadLine());
//            int count = 0;
//            int count1 = 0;
//            foreach (var a in mat)
//            {
//                if (del == a.mid)
//                {
//                    count1 = count;
//                }
//                count++;
//                mat.RemoveAt(count1);
//            }
        
//        }
//    }
//}
