﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace ipl
{
    class option
    {
        public int select;
        public void choice()
        {

            Console.WriteLine("Choose from your option\n1.Add match details\n2.Modify match details\n3.Show all matches\n4.Delete Match\n5.Exit");
            Console.WriteLine("Enter your choice:");
            select = int.Parse(Console.ReadLine());
        }
    }
}