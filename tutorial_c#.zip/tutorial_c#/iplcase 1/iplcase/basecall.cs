﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace ipl
{
    class operation : functions
    {

        public void valid()
        {

            if (select == 1)
            {
                add();
                choice();
            }
            if (select == 2)
            {
                modify();
                choice();


            }
            if (select == 3)
            {
                show();
                choice();

            }
            if (select == 4)
            {
                delete();
                choice();
            }
            if (select == 5)
            {
                exit();
            }
            else
            {
                Console.WriteLine("Enter the valid option");
                add();
            }
        }
        public static void Main(string[] args)
        {
            operation f = new operation();
            f.choice();
            f.valid();


        }
    }

}
