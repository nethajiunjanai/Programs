﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Collections;
namespace ipl
{
    class functions : option
    {
        ArrayList l = new ArrayList();
        public void add()
        {
            Console.WriteLine("Enter the Number of matches");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter the match number:");
                string match = Console.ReadLine();
                Console.WriteLine("Enter the team1:");
                string team1 = Console.ReadLine();
                Console.WriteLine("Enter the team2:");
                string team2 = Console.ReadLine();
                Console.WriteLine("Enter the result:");
                string result = Console.ReadLine();
                Console.WriteLine("Enter the umpires:");
                string umpires = Console.ReadLine();
                //   ArrayList l = new ArrayList();

                l.Add("Match number" + match);
                l.Add("Team1:" + team1);
                l.Add("Team2:" + team2);
                l.Add("Result:" + result);
                l.Add("Umpire:" + umpires);
                foreach (object o in l)
                {
                    Console.WriteLine(o);
                }

                //            string matchno, team1, team2;
                //            Console.WriteLine("Enter the match number:");
                //            matchno = Console.ReadLine();
                //            Console.WriteLine("Enter the team1:");
                //            team1 = Console.ReadLine();
                //            Console.WriteLine("Enter the team2:");
                //            team2 = Console.ReadLine();
                //            Console.WriteLine("Match details are added");
            }
        }
        public void modify()
        {
            Console.WriteLine("Enter the match number:");
            int number =int.Parse(Console.ReadLine());
          //  Console.WriteLine("Which one do you want to modify?\n1.Team1\n2.Team2");
          //  Console.WriteLine("option:");
          //  string opt = Console.ReadLine();
            Console.WriteLine("Enter the modified details");
            add();
            Console.WriteLine("Match details are modified");

        }
        public void delete()
        {
            int delete;
            Console.WriteLine("Enter the match number to be deleted:");
            delete = int.Parse(Console.ReadLine());
            Console.WriteLine("Match {0} details were deleted", delete);

        }
        public void show()
        {
            Console.WriteLine("Enter the match number you want to see:");
            foreach (object v in l)
            {
                Console.WriteLine(v);
            }
            int shownum = int.Parse(Console.ReadLine());

        }
        public void exit()
        {
            Console.WriteLine("wait for sometime.....");
            Console.WriteLine("Thanks for using");
        }
    }

}
