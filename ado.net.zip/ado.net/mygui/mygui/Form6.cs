﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace mygui
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
            String qry = "Select * from Dream_Home.registration where clientNo=@cno";//dynamic query..@ symbol..changed accroding to the condition
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            //dynamic query dont use new keyword
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;//if its stored proc use proc name
            SqlParameter p1 = cmd.Parameters.Add("@cno",SqlDbType.VarChar,20);
            p1.Value = textBox1.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "client");
            if (ds.Tables[0].Rows.Count == 1)
            {
                textBox2.DataBindings.Add("Text", ds, "client.branchno");
                textBox3.DataBindings.Add("Text", ds, "client.staffNo");
                textBox4.DataBindings.Add("Text", ds, "client.datejoined");
                textBox1.DataBindings.Clear();
                textBox2.DataBindings.Clear();
                textBox3.DataBindings.Clear();
                textBox4.DataBindings.Clear();

            }
            else
            {
                MessageBox.Show("no such clientnumber");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //textBox1.Text = string.Empty;
            //textBox2.Text = string.Empty;
            //textBox3.Text = string.Empty;
            //textBox4.Text = string.Empty;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            

        }
    }
}
