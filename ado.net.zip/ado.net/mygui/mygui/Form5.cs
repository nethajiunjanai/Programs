﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace mygui
{
    public partial class Form5 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;
        public Form5()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
            String qry = "select * from Dream_Home.branch";
             con = new SqlConnection(constring);
            con.Open();
             cmd = new SqlCommand(qry, con);
             da = new SqlDataAdapter(cmd);
             ds = new DataSet();
            da.Fill(ds, "branch"); 
            textBox1.DataBindings.Add("Text", ds, "branch.branchNo");
            textBox2.DataBindings.Add("Text", ds, "branch.street");
            textBox3.DataBindings.Add("Text", ds, "branch.city");
            textBox4.DataBindings.Add("Text", ds, "branch.postcode");

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position++;
            
            
           // this.BindingContext

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position--;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            this.BindingContext[ds, "branch"].Position = this.BindingContext[ds, "branch"].Count - 1;
        }
    }
}
