﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
//data table
//string to datatable
namespace mygui
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void dataGrid1_Navigate(object sender, NavigateEventArgs ne)
        {

        }

        private void Form13_Load(object sender, EventArgs e)
        {
            string[] arr = new string[] { "s1", "s2", "s3", "s4" };
            int[] iarr = new int[] { 1, 2, 3, 4, 5 };
            DataTable dt = new DataTable();
           // dt.Columns.Add("sno1", Type.GetType("System.String"));
            dt.Columns.Add("sno",Type.GetType("System.Int32"));
            foreach (string s in arr)
            {
                dt.Rows.Add(s);
            }
            foreach(int i in iarr)
            {
                dt.Rows.Add(i);
            }
           // dataGrid1.DataSource = dt;

            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            dataGrid1.DataSource = ds;

        }
    }
}
