﻿namespace mygui
{
    partial class bt_val
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_user = new System.Windows.Forms.Label();
            this.lb_password = new System.Windows.Forms.Label();
            this.tx_uname = new System.Windows.Forms.TextBox();
            this.tx_passwd = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_user
            // 
            this.lb_user.AutoSize = true;
            this.lb_user.Location = new System.Drawing.Point(12, 35);
            this.lb_user.Name = "lb_user";
            this.lb_user.Size = new System.Drawing.Size(53, 13);
            this.lb_user.TabIndex = 0;
            this.lb_user.Text = "username";
            // 
            // lb_password
            // 
            this.lb_password.AutoSize = true;
            this.lb_password.Location = new System.Drawing.Point(12, 69);
            this.lb_password.Name = "lb_password";
            this.lb_password.Size = new System.Drawing.Size(52, 13);
            this.lb_password.TabIndex = 1;
            this.lb_password.Text = "password";
            // 
            // tx_uname
            // 
            this.tx_uname.Location = new System.Drawing.Point(110, 35);
            this.tx_uname.Name = "tx_uname";
            this.tx_uname.Size = new System.Drawing.Size(100, 20);
            this.tx_uname.TabIndex = 2;
            this.tx_uname.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // tx_passwd
            // 
            this.tx_passwd.Location = new System.Drawing.Point(110, 69);
            this.tx_passwd.Name = "tx_passwd";
            this.tx_passwd.PasswordChar = '*';
            this.tx_passwd.Size = new System.Drawing.Size(100, 20);
            this.tx_passwd.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 107);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bt_val
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 476);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tx_passwd);
            this.Controls.Add(this.tx_uname);
            this.Controls.Add(this.lb_password);
            this.Controls.Add(this.lb_user);
            this.Name = "bt_val";
            this.Text = "mygui";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_user;
        private System.Windows.Forms.Label lb_password;
        private System.Windows.Forms.TextBox tx_uname;
        private System.Windows.Forms.TextBox tx_passwd;
        private System.Windows.Forms.Button button1;
    }
}

