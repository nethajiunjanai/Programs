﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace mygui
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        //procedure and query implementation
        private void Form4_Load(object sender, EventArgs e)
        {
            string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
           // String qry = "select * from Dream_Home.CLIENT";
            String qry = "exec pr2 'SA9'";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
           da.Fill(ds,"Client");
      //      da.Fill(ds);
    //        dataGrid1.DataSource = ds;
         //   dataGrid1.DataSource = ds.Tables[0];
           dataGrid1.DataSource = ds.Tables["Client"];
                
                
            
        }
    }
}
