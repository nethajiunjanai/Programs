﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
//stored procedure using output key word in sql
namespace mygui
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "pr3";

            SqlParameter p1 = cmd.Parameters.Add("@pno", SqlDbType.VarChar, 20);
            p1.Value = textBox1.Text;
            SqlParameter p2 = cmd.Parameters.Add("@city", SqlDbType.VarChar, 20);
            p2.Direction = ParameterDirection.Output;
            SqlParameter p3 = cmd.Parameters.Add("@rent", SqlDbType.Decimal);
            p3.Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();  
            if(p3.Value!=DBNull.Value && p2.Value!=DBNull.Value)
            {
              
              textBox2.Text = p2.Value.ToString();
              textBox3.Text = p3.Value.ToString();
            }
            else
            {
                MessageBox.Show("invalid");
            }
          //  SqlDataReader dr = cmd.ExecuteReader();
          
            
        }

        private void Form12_Load(object sender, EventArgs e)
        {

        }
    }
}
