﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
//datagrid and xml code
namespace mygui
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
            String qry = "select * from Dream_Home.staff";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry,con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "staff");
            dataGrid1.DataSource = ds;
            //getting xml format 
           // richTextBox1.Text = ds.GetXml();
            //to find typed or untyped dataset
            richTextBox1.Text = ds.GetXmlSchema();
            
        }
    }
}
