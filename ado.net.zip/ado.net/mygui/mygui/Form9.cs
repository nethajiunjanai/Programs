﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
//combobox or dropdown
namespace mygui
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
          //  string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
            string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
        //    String qry = "select distinct addres from customer";
            String qry = "select staffNo from Dream_Home.staff";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
           SqlCommand cmd = new SqlCommand(qry, con);
           SqlDataReader dr = cmd.ExecuteReader();
           while (dr.Read())
           {
               comboBox1.Items.Add(dr[0].ToString());
           }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           // string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
            string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
          //  String qry = "select * from customer where addres=@add";//dynamic query..@ symbol..changed accroding to the condition
            String qry = "exec pr2 @staff";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;//if its stored proc use proc name
           // SqlParameter p1 = cmd.Parameters.Add("@add", SqlDbType.VarChar, 20);
            SqlParameter p1 = cmd.Parameters.Add("@staff", SqlDbType.VarChar, 20);
            p1.Value = comboBox1.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds=new DataSet();
            da.Fill(ds,"staff");
            dataGrid1.DataSource = ds;
        }
    }
}
