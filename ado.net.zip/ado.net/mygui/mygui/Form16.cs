﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace mygui
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
            String qry="delete from dup where prod_id=@id";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            
            SqlParameter p1 = cmd.Parameters.Add("@id", SqlDbType.Int);
            p1.Value = textBox1.Text;
        //    cmd.ExecuteNonQuery();//dml manipulation and it returns integer 
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                MessageBox.Show("data deleted");
             
            }
            else
            {
                MessageBox.Show("invalid id");
            }
        }
    }
}
