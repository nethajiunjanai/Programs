﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;
//populating differnet types of data in datagrid
namespace mygui
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            
            //object intializer--giving values to object when they are created
            //untyped dataset
            //grid view required collection of data source
            //anonymous
            var info=new[]
            {
                new{id=1,name="ram"},
                new{id=2,name="arun"},
                new{id=3,name="krish"},

            };
            //ArrayList al = new ArrayList(info.ToList());
            //dataGrid1.DataSource = al;
            //we r having two columns so try this
            DataTable dt = new DataTable();
            dt.Columns.Add("uid",Type.GetType("System.Int32"));
             dt.Columns.Add("uname",Type.GetType("System.String"));
             UniqueConstraint uc = new UniqueConstraint("uc1",dt.Columns[0]);
             dt.Constraints.Add(uc);
             foreach (var data in info)
             {
                 DataRow dr = dt.NewRow();
                 dr[0] = data.id;
                 dr[1] = data.name;
                 dt.Rows.Add(dr);
             }
             dataGrid1.DataSource = dt;
        }
    }
}
