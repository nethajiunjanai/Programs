﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace mygui
{
    public partial class Form15 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;
        SqlCommandBuilder scb;
        public Form15()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form15_Load(object sender, EventArgs e)
        {
            string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
            String qry = "select * from Dream_Home.branch";
            con = new SqlConnection(constring);
            con.Open();
            cmd = new SqlCommand(qry, con);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds, "branch");
            textBox1.DataBindings.Add("Text", ds, "branch.branchNo");
            textBox2.DataBindings.Add("Text", ds, "branch.street");
            textBox3.DataBindings.Add("Text", ds, "branch.city");
            textBox4.DataBindings.Add("Text", ds, "branch.postcode");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position++;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position--;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, "branch"].Position = this.BindingContext[ds, "branch"].Count - 1;
        }

        private void button5_Click(object sender, EventArgs e)
        {

            //string str;
            //str = textBox1.Text;
            //string str1 = str.Substring(2,4);
            //int i = int.Parse(str1);
            //i = i + 1;
            //string s1 = i.ToString();
            //s1 = string.Concat("B", s1);
            //textBox1.Text = s1;
            //textBox1.Enabled = false;
            this.BindingContext[ds, "branch"].Position = this.BindingContext[ds, "branch"].Count - 1;
            string str;
            str = textBox1.Text;

            string str1 = str.Substring(1, 3);
            int i = int.Parse(str1);
            if (i < 9)
            {
                i = i + 1;
                string s1 = i.ToString();
                s1 = string.Concat("B00", s1);
                textBox1.Text = s1;
                textBox1.Enabled = false;
            }
            else if (i >= 9)
            {
                i = i + 1;
                string s1 = i.ToString();
                s1 = string.Concat("B0", s1);
                Console.WriteLine(s1);
                textBox1.Text = s1;
                textBox1.Enabled = false;
            }
            else if (i > 99)
            {
                i = i + 1;
                string s1 = i.ToString();
                s1 = string.Concat("B", s1);
                Console.WriteLine(s1);
                textBox1.Text = s1;
                textBox1.Enabled = false;
            }
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
            //SqlConnection con = new SqlConnection(constring);
            //con.Open();
            //SqlCommand cmd = con.CreateCommand();
            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.CommandText = "pr4";
            //SqlParameter p1 = cmd.Parameters.Add("@branchno", SqlDbType.VarChar, 20);
            //p1.Value = textBox1.Text;
            //SqlParameter p2 = cmd.Parameters.Add("@street", SqlDbType.VarChar, 20);
            //p2.Value = textBox2.Text;
            //SqlParameter p3 = cmd.Parameters.Add("@city", SqlDbType.VarChar, 20);
            //p3.Value = textBox3.Text;
            //SqlParameter p4 = cmd.Parameters.Add("@postcode", SqlDbType.VarChar, 20);
            //p4.Value = textBox4.Text;
            //cmd.ExecuteNonQuery();//dml manipulation and it returns integer 
            //MessageBox.Show("data inserted");

            scb = new SqlCommandBuilder(da);//cmd builder executes insert query
            DataRow dr = ds.Tables["branch"].NewRow();
            dr[0] = textBox1.Text;
            dr[1] = textBox2.Text;
            dr[2] = textBox3.Text;
            dr[3] = textBox4.Text;
            ds.Tables["branch"].Rows.Add(dr);
          //  ds.Tables["branch"].Rows.clear(dr);
            
            da.Update(ds.Tables["branch"]); 
            MessageBox.Show("inserted successfully");
           
        }
    }
}
