﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linq_tutorial
{
    class sample
    {
        public class employee
        {
            public int eid { get; set; }
            public string ename { get; set; }
            public string city { get; set; }
        }
        public static void Main()
        {
            List<employee> emp = new List<employee>()
            {
                new employee{eid=1,ename="raja",city="chennai"},
                new employee{eid=2,ename="kumar",city="coimbatore"},
                new employee{eid=3,ename="gupta",city="chennai"},
                new employee{eid=4,ename="ram",city="pune"},
                new employee{eid=5,ename="prasanna",city="chennai"},
                new employee{eid=6,ename="rajan",city="coimbatore"},
                new employee{eid=7,ename="siva",city="pune"},
                new employee{eid=8,ename="mano",city="pune"},
                new employee{eid=9,ename="vikyy",city="coimbatore"},
                new employee{eid=10,ename="dev",city="chennai"},
                new employee{eid=11,ename="kavin",city="coimbatore"},
                new employee{eid=12,ename="anto",city="chennai"} ,    
                new employee{eid=12,ename="ajay",city="bangalore"}         
            };
            //display uname,city where id>4
           // var v = from a in emp where a.eid < 4 select a;
           // var v = emp.Where(c => c.eid < 4);

            //employees in each city
           // var v=from a in emp group a.city by a.city into res select new{city=res.Key,num=res.Count()};

            //display city and emp names
            var v = (from a in emp select a.city).Distinct();
            
            
         //  var 
            foreach (var y in v)
            {
              Console.WriteLine(y);  
                foreach(var a in emp)
                {
                    if(y==a.city)
                    {
                        Console.WriteLine(a.ename);
                    }
                }
            }
            Console.ReadLine();
                //foreach (var z in x)
                //{
                //    Console.WriteLine(z);
                //}
            }
    
        }
    }
    
     
