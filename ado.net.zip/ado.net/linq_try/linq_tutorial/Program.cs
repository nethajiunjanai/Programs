﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
////linq tutorial 
//namespace linq_tutorial
//{
//    class Program
//    {
      
//        static void Main(string[] args)
//        {
//           // int[] arr = { 1, 3, 4, 2, 8, 9, 6, 5, 7, 1, 3 };
//            //foreach (int i in arr)
//            //{
//            //    Console.WriteLine(i);
//            //}
//            //if(i>5)
//            //{
//            //    Console.WriteLine(i);
//            //}
//            //IEnumerable<int> il = from a in arr where a>5
//            //                      select a;//we can replace ienumerable by var

//            //using condition
//            //var v = from a in arr where a>5                 
//            //        select a;
//            //for distinct values
//            //var v = (from a in arr
//            //        where a > 5
//            //        select a).Distinct();

//            //all odd elements in array greater than 5
//            //var v = from a in arr
//            //        where a > 5 && a%2!=0
//            //        select a;

//            //using lambda operator
//            //var v = arr.Where(c => c > 5 && c % 2 != 0);
           

//            //ordering array
//            //Array.Sort(arr);
//            //var v = arr.Reverse();
//           // var v=   Array.Reverse(arr);
//            //var v = from a in arr orderby a   descending           
//            //        select a;
//            //var v = arr.OrderBy(c =>c);

//            //counting number of distinct integer in array
//            //var v = arr.Distinct().Count();
//            //Console.WriteLine(v);

//            //disp avg of elements greater than 5
//            //var v = (from a in arr where a>5                 
//            //        select a).Average();
//            //Console.WriteLine(v);
//            //Console.WriteLine("using linq");

//            //ordering by string length and alphabet

//           // string[]  arr = { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten" };
            
//           // var v=(from a in arr orderby a.Length,a select a);
//           // var v = arr.OrderBy(c => c.Length).ThenBy(c => c);
            
//            //contains o in string
//            //   var v = (from a in arr where a.Contains("o") select a);
//            //var v=arr.Where(c=> c.Contains("i"));

//            //select top 3 highest value
//            int[] arr = { 1, 3, 4, 2, 8, 9, 6, 5, 7, 1, 3 };
//            //var v = (from a in arr orderby a descending select a).Take(3);

//            //select 2 and 3rd highest
//           // var v = (from a in arr orderby a descending select a).Take(3).Skip(1);
//            //var v = arr.OrderByDescending(c => c).Take(3).Skip(1);
//            //display 3rd element wihtout skip and take
//            //var v = (from a in arr orderby a descending select a).ElementAt(2);
//            //var v = (from a in arr orderby a descending select a).ElementAtOrDefault(2);
//            //Console.WriteLine(v);

//            //object array
//            //object[] ob = { 1, "dog", 'k', 12.12, "bull", 21, 'n', 12.32, "jinesh", 2, 'v' };
//            //var v = ob.OfType<double>();

//            //display elements present how many time
//            //var v = from a in arr orderby a group a by a into res select new { data = res.Key, total = res.Count() };

//            //display duplicate
//            //var v = from a in arr orderby a 
//            //        group a by a into res 
//            //        where res.Count() > 1
//            //        select new { data = res.Key, total = res.Count() };

//            var v=arr.GroupBy(a=>a).Where(b=>b.Count()>1).Select(c=>new {data=c.Key,total=c.Count()});
//            foreach (var y in v)
//            {
//                Console.WriteLine("{0} present {1} times",y.data,y.total);
                  
//            }
           
//        }
//    }
//}
