﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace first_application
{
    class newclass
    {
        public static void Main()
        {
          //  int a, b, c;
          //// a = 10;
          // // b = 20;
          //  Console.WriteLine(" first value is");
          //  a= int.Parse(Console.ReadLine());
          //  Console.WriteLine("second value is ");
          //  b = int.Parse(Console.ReadLine()); 
          //  c = a + b;
          //  Console.WriteLine("the total is:" +c);
          //  Console.WriteLine("the total of {0} and {1} is {2}",a,b,c);
            Console.WriteLine("thanks");
        }
    }
}
