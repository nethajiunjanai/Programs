﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class power
    {
        //public static void Main()
        //{
        //    Console.WriteLine("enter the number:");
        //  double num;
        //    num=double.Parse(Console.ReadLine());
        //    Console.WriteLine("enter the power:");
        //  double p;
        //    p=double.Parse(Console.ReadLine());
        //    num = Math.Pow(num, p);
           
            

        //    Console.WriteLine("result is:"+num);
        //    Console.ReadLine();
        //}
    }

}
