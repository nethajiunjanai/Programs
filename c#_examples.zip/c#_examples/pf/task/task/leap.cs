﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class leap
    {
        //public static void Main()
        //{
        //    Console.WriteLine("enter the year");
        //    int y;
        //    y = int.Parse(Console.ReadLine());
        //    if (y % 400 == 0)
        //        Console.WriteLine("leap year");
        //    else if (y % 100 == 0)
        //        Console.WriteLine("non leap year");
        //    else if (y % 4 == 0)
        //        Console.WriteLine("leap year");
        //    else
        //        Console.WriteLine("non leap year");
        //}            
    }
}
