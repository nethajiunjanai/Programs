﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class days
    {
        //public static void Main()
        //{
        //    Console.WriteLine("days");
        //    double days, year, week;
        //    days = double.Parse(Console.ReadLine());
        //    year = days / 365;
        //    week = days / 7;
        //    Console.WriteLine("year:" + year);
        //    Console.WriteLine("week:" + week);
        //}

        
    }
}
