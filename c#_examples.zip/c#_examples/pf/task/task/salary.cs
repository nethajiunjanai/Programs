﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class salary
    {
        //public static void Main()
        //{
        //    Console.WriteLine("enter the salary");
        //    double sal,hra,da;
        //    sal=double.Parse(Console.ReadLine());
        //    if (sal>=10000)
        //    {
        //        hra=sal*.20;
        //        da=sal*.80;
        //        sal=hra+da+sal;
        //    Console.WriteLine("gross salary:"+sal);
        //    }
        //    else if (sal >= 20000)
        //    {
        //        hra = sal * .25;
        //        da = sal * .90;
        //        sal = hra + da+sal;
        //        Console.WriteLine("gross salary:" + sal);
        //    }
        //    else
        //    {
        //        hra = sal * .30;
        //        da = sal * .95;
        //        sal = hra + da + sal;
        //        Console.WriteLine("gross salary:" + sal);
        //    }
        //}
        
        }
}
