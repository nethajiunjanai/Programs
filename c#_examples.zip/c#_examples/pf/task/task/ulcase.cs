﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class ulcase
    {
        //public static void Main()
        //{
            //Console.WriteLine("enter the character");
            //char inp;
            //inp=char.Parse(Console.ReadLine());
            
            //{
            //    if (char.IsLower(inp))
            //        Console.WriteLine("lower case");
            //    else if (char.IsUpper(inp))
            //        Console.WriteLine("upper case");
            //}
            //Console.ReadLine();
        //}
    }
}
