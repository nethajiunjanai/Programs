﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class factorial
    {
    //    static void Main()
    //{
    //    int num, fact = 1;
    //    Console.WriteLine("enter the number");
    //        num= int.Parse(Console.ReadLine());
    //        for (int i = 1; i <= num; i++)
    //        {
    //            fact = fact * i;
    //        }
    //        Console.WriteLine("factorial is:"+fact);
    //    }   
    }
}
