﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class Program
    {
       // static void Main(string[] args)
            //{
            //    Console.Write("Enter a Number : ");
            //    int num;
            //    num = int.Parse(Console.ReadLine());
            //    int k;
            //    k = 0;
            //    for (int i = 1; i <= num; i++)
            //    {
            //        if (num % i == 0)
            //        {
            //            k++;
            //        }
            //    }
            //    if (k == 2)
            //    {
            //        Console.WriteLine(" Number is a Prime Number", num);
            //    }
            //    else
            //    {
            //        Console.WriteLine("Not a Prime Number");
            //    }
            //    Console.ReadLine();
            //}        
    }
}
