﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class count
    {
        //static void Main()
        //{
        //    int n, i = 1;
        //    Console.WriteLine("enter the number");
        //    n = int.Parse(Console.ReadLine());
        //    while (n > 0)
        //    {
        //            n = n / 10;
        //            if (n !=0)
        //                i = i + 1;
                         
        //    }
        //    Console.WriteLine("count of digits is:" + i);


       //}
    }

}