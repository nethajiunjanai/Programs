﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class reverse
    {
        //public static void Main()
        //{
        //    Console.WriteLine("number is:");
        //    int num, rev = 0, rem;
        //    num = int.Parse(Console.ReadLine());
        //    while (num > 0)
        //    {
        //        rem = num % 10;
        //        rev = (rev * 10) + rem;
        //        num = num / 10;
        //    }
        //    Console.WriteLine("reverse num is:"+rev);
        //    Console.ReadLine();
        //}
    }
}
