﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class sumofdigits
    {
        //public static void Main()
        //{
        //    Console.WriteLine("number is :");
        //    int num;
        //    int sum = 0;
        //    int rem;
        //    num = int.Parse(Console.ReadLine());
        //    while (num != 0)
        //    {
        //        rem = num % 10;
        //        num = num / 10;
        //        sum = sum + rem;
        //    }
        //        Console.WriteLine("sum is:"+sum);
        //        Console.ReadLine();                         
        //}
    }
}
