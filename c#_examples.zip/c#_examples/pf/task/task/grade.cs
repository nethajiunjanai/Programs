﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class grade
    {
        //public static void Main()
        //{
        //    Console.WriteLine("enter the marks ");
        //    int[] input = new int[5];
        //    for (int i = 0; i < 5; i++)
        //    {
        //        input[i] = int.Parse(Console.ReadLine());
        //        if (input[i] > 90)
        //            Console.WriteLine("A grade");
        //        else if (input[i] > 80)
        //            Console.WriteLine("b grade");
        //        else if (input[i] > 70)
        //            Console.WriteLine("c grade");
        //        else if (input[i] > 60)
        //            Console.WriteLine("d grade");
        //        else if (input[i] > 40)
        //            Console.WriteLine("e grade");
        //        else
        //            Console.WriteLine("f grade");
        //    }
        //}
    }
}
