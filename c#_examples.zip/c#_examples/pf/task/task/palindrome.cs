﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class palindrome
    {
        //public static void Main()
        //{
        //    Console.WriteLine("enter the no:");
        //    int num, rem, temp, reverse = 0;
        //    num = int.Parse(Console.ReadLine());
        //    temp = num;
        //    while (num > 0)
        //    {
        //        rem = num % 10;
        //        reverse = reverse * 10 + rem;
        //        num = num / 10;
        //    }
        //    if (temp == reverse)
        //        Console.WriteLine("palindrome");
        //    else
        //        Console.WriteLine("not palindrome");
        //}
    }
}
