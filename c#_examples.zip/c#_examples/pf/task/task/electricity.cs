﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class electricity
    {
       // public static void Main()
        //{

            //Console.WriteLine("no of units");
            //double unit, amt, i;
            //unit = double.Parse(Console.ReadLine());
            //if (unit <= 50)
            //    amt = .5 * unit;
            //else if (unit <= 150)
            //{
            //    i = unit - 50;
            //    amt = i * .75 + 25;
            //}
            //else if (unit <= 250)
            //{
            //    i = unit - 150;
            //    amt = i * 1.2 + 62.5;
            //}
            //else
            //{
            //    amt = unit * 1.5;
            //}
            //amt = amt + (amt * .2);
            //Console.WriteLine("amount is:" + amt);
        //}

    
    }
}
