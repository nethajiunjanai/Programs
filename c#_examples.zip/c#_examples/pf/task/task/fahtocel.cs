﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task
{
    class fahtocel

    {
    //    public static void Main()
    //    {
    //        double celsius;
    //        Console.WriteLine("Enter Fahrenheit temperature : ");
    //        double fahrenheit = Double.Parse(Console.ReadLine());
    //        celsius = (fahrenheit - 32) * 5 / 9;
    //        Console.WriteLine("The converted Celsius temperature is" + celsius);
    //        Console.ReadLine();
    //    }
        
    }
}
