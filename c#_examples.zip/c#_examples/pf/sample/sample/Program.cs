﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sample
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    //int[] input = new int[5];
        //    int[] input;
        //    int n;
        //    n = Convert.ToInt32(Console.ReadLine());
        //    input = new int[n];
        //    for (int i = 0; i < n; i++)
        //    {
        //        input[i] = Convert.ToInt32(Console.ReadLine());
        //    }
        //    foreach (int item in input)
        //    {
        //        Console.WriteLine(item);
        //    }

        //}
    }
}
