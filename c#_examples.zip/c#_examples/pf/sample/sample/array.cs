﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace LineApplication
{
   class Line
   {
      private int lengt;   // Length of a line
      public Line()
      {
         Console.WriteLine("Object is being created");
      }

      public void setLe()
      {
         lengt =10 ;
      }
      
     

      static void Main(string[] args)
      {
         Line line = new Line();    
         
         // set line length
         line.setLe();
    
         
         Console.WriteLine("Length of line : {0}",line.lengt);
         Console.ReadKey();
      }
   }
}