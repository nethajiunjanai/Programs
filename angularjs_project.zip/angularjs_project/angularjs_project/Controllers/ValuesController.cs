﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using angularjs_project.Controllers;
using angularjs_project.Models;

namespace angularjs_project.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5

        [HttpGet]
        public bool Get(int Questionid, int Answerid)
        {
            AngularController controller_obj = new AngularController();
            bool b = controller_obj.Check_answer(Questionid, Answerid);
            return b;
        }

        public List<option_tab> option()
        {
            AngularController c = new AngularController();
            List<option_tab> li = c.option();
            return li;
        }
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}