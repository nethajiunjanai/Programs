﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using angularjs_project.Controllers;

namespace angularjs_project.Controllers
{
    public class ManipulationController : Controller
    {
        //
        // GET: /manipulation/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Index1()
        {
            return View();
        }

        public JsonResult value()
        {
            ValuesController v = new ValuesController();
             
            return Json(v.option(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult option()
        {
            return View();
        }
    }
}
