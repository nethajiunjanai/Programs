﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using angularjs_project.Controllers;
using angularjs_project.Models;

namespace angularjs_project.Controllers
{
    public class AngularController : ApiController
    {
        angularEntities entityobject = new angularEntities();
        angularEntities1 ent = new angularEntities1();
        [HttpGet]
        public bool Check_answer(int Question,int Selected_answer)
        {
            int answer = (from key in entityobject.answer_key where key.question_id == Question select key.answer).FirstOrDefault();
            if (Selected_answer == answer)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        [HttpGet]
        public List<option_tab> option()
        {
            List<option_tab> li = (from s in ent.option_tab select s).ToList();
            return li;
        }
    }
}
