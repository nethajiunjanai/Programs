﻿ t = 0;
$(document).ready(function () {
   
    
    $("#accordion").accordion({
        collapsible: true,
        active: false
    });
    
    debugger;
    $(".click").click(function () {
        $("#message").hide();
       //if ((t/2)!=0) {
       //     $("#message").hide();
       //     t++;
          
            
       // }
       // else {
       //     $("#message").show();
       //     t++;
       // }
    });

});

var app = angular.module('accord_app', []);
app.controller('accord_controller', function ($scope, $http) {
   
    $scope.Check_answer = function (key, Question_no) {

        
        if (key != undefined) {
            $http.get("/api/Angular/Check_answer?Question=" + Question_no + "&Selected_answer=" + key).then(function (response) {

               
                if (response.data == true) {
                    
                    $.toaster({ message: 'correct answer', title: 'Result', priority: 'success', settings: { timeout: 2000 } }),
                      function (response) { alert("error") };
                }
                else {
                   
                    $.toaster({ message: 'Wrong answer', title: 'Result', priority: 'danger', settings: { timeout: 2000 } }),
                    function (response) { alert("error") };;
                }

            });
        }
        else {

            $.toaster({ message: 'Please select any one option', title: 'Result', priority: 'info', settings: { timeout: 2000 } });
        }
    }




});